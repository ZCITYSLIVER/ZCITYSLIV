-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_skorpion.lua"

SWEP.Base = "homigrad_base"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "Šcorpion vz. 61"
SWEP.Author = "Česká zbrojovka"
SWEP.Instructions = "Pistol chambered in 7.65x17 mm\n\nRate of fire 900 rounds per minute"
SWEP.Category = "Weapons - Machine-Pistols"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/pwb/weapons/w_vz61.mdl"
SWEP.punchmul = 1.5
SWEP.punchspeed = 3
SWEP.WepSelectIcon2 = Material("pwb/sprites/vz61.png")
SWEP.IconOverride = "entities/weapon_pwb_vz61.png"
SWEP.weight = 1
SWEP.weaponInvCategory = 2
SWEP.ShellEject = "EjectBrass_9mm"
SWEP.Primary.ClipSize = 20
SWEP.Primary.DefaultClip = 20
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "7.65x17 mm"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 17
SWEP.Primary.Sound = {"hndg_beretta92fs/beretta92_fire1.wav", 75, 90, 100}
SWEP.Primary.Force = 17
SWEP.Primary.Wait = 0.066
SWEP.ReloadTime = 4.7
SWEP.ReloadSoundes = {
	"none",
	"none",
	"pwb/weapons/uzi/clipout.wav",
	"none",
	"none",
	"pwb/weapons/uzi/clipin.wav",
	"none",
	"none",
	"weapons/tfa_ins2/mp7/boltback.wav",
	"pwb2/weapons/vectorsmg/boltrelease.wav",
	"none",
	"none",
	"none",
	"none"
}
SWEP.DeploySnd = {"homigrad/weapons/draw_pistol.mp3", 55, 100, 110}
SWEP.HolsterSnd = {"homigrad/weapons/holster_pistol.mp3", 55, 100, 110}
SWEP.HoldType = "smg"
SWEP.ZoomPos = Vector(0.38, 0.05, 25)
SWEP.RHandPos = Vector(-13.5, -1, 3)
SWEP.LHandPos = false
SWEP.Spray = {}
for i = 1, 20 do
	SWEP.Spray[i] = Angle(-0.02 - math.cos(i) * 0.01, math.cos(i * i) * 0.01, 0) * 1
end

SWEP.LocalMuzzlePos = Vector(-0.192,0.003,7.878)
SWEP.LocalMuzzleAng = Angle(0,-0.021,90.244)
SWEP.WeaponEyeAngles = Angle(0,0,0)

SWEP.CustomShell = "45acp"
--SWEP.EjectPos = Vector(0,5,5)
--SWEP.EjectAng = Angle(-5,180,0)
SWEP.AnimShootHandMul = 0.01
SWEP.Ergonomics = 1.2
SWEP.Penetration = 1
SWEP.WorldPos = Vector(13, -1, 2.2)
SWEP.WorldAng = Angle(0, 0, 0)
SWEP.UseCustomWorldModel = true
SWEP.lengthSub = 20
SWEP.DistSound = "m9/m9_dist.wav"

SWEP.holsteredBone = "ValveBiped.Bip01_Spine2"
SWEP.holsteredPos = Vector(4, 8, -10)
SWEP.holsteredAng = Angle(210, 0, 180)

SWEP.attPos = Vector(-3,-1,0)
SWEP.attAng = Angle(0,0,0)

--local to head
SWEP.RHPos = Vector(6,-6.5,3.5)
SWEP.RHAng = Angle(0,-5,90)
--local to rh
SWEP.LHPos = Vector(6,-1,-2)
SWEP.LHAng = Angle(0,25,-80)

local finger1 = Angle(-15,0,5)
local finger2 = Angle(-15,45,-5)

function SWEP:AnimHoldPost(model)
	self:BoneSetAdd(1, "l_finger0", vector_zero, finger1)
    self:BoneSetAdd(1, "l_finger02", vector_zero, finger2)
end

--RELOAD ANIMS SMG????

SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(0,-2,-2),
	Vector(-15,5,-7),
	Vector(-15,5,-15),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	"fastreload",
	Vector(5,0,5),
	Vector(-2,1,5),
	Vector(-2,1,5),
	Vector(-2,1,5),
	Vector(0,0,0),
	"reloadend",
	Vector(0,0,0)
}
SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(-35,0,0),
	Angle(-55,0,0),
	Angle(-75,0,0),
	Angle(-75,0,45),
	Angle(-75,0,45),
	Angle(-25,0,45),
	Angle(0,0,0),
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0)
}
SWEP.ReloadAnimRHAng = {
	Angle(0,0,0)
}
SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(0,25,25),
	Angle(15,25,25),
	Angle(-15,25,25),
	Angle(0,0,-15),
	Angle(0,0,-25),
	Angle(-15,0,-25),
	Angle(-05,0,-15),
	Angle(0,0,0)
}

-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(15,15,15),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,7,24),
	Angle(10,3,-5),
	Angle(2,3,-15),
	Angle(0,4,-22),
	Angle(0,3,-45),
	Angle(0,3,-45),
	Angle(0,-2,-2),
	Angle(0,0,0)
}