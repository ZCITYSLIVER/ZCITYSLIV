-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_vector.lua"

SWEP.Base = "homigrad_base"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "KRISS Vector"
SWEP.Author = "Transformational Defense Industries, Inc"
SWEP.Instructions = "Submachine gun chambered in .45 ACP\n\nRate of fire 1500 rounds per minute"
SWEP.Category = "Weapons - Machine-Pistols"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/zcity/w_vectorsmg.mdl"

SWEP.WepSelectIcon2 = Material("pwb2/vgui/weapons/vectorsmg.png")
SWEP.IconOverride = "entities/weapon_pwb2_vectorsmg.png"

SWEP.LocalMuzzlePos = Vector(17.469,0.014,1.617)
SWEP.LocalMuzzleAng = Angle(0,-0.026,90.298)
SWEP.WeaponEyeAngles = Angle(0,0,0)

SWEP.weight = 2.5
SWEP.ScrappersSlot = "Primary"
SWEP.weaponInvCategory = 1
SWEP.CustomShell = "9x19"
SWEP.EjectPos = Vector(-4,0,-9)
SWEP.EjectAng = Angle(0,0,0)
SWEP.WorldPos = Vector(1, -0.8, 0)
SWEP.WorldAng = Angle(0, 0, 0)
SWEP.UseCustomWorldModel = true
SWEP.Primary.ClipSize = 33
SWEP.Primary.DefaultClip = 33
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = ".45 ACP"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 23
SWEP.Primary.Spread = 0
SWEP.Primary.Force = 23
SWEP.Primary.Sound = {"homigrad/weapons/pistols/p228-1.wav", 75, 120, 130}
SWEP.Primary.Wait = 0.04
SWEP.availableAttachments = {
	sight = {
		["mountType"] = "picatinny",
		["mount"] = Vector(-11, 2.8, -0.28),
		["empty"] = {
			"empty",
			{
				[8] = "pwb2/models/weapons/w_vectorsmg/sight"
			},
		},
		["removehuy"] = {
			[8] = "null"
		},
	},
	barrel = {
		[1] = {"supressor4", Vector(0,0,0), {}},
		[2] = {"supressor6", Vector(0,0,0), {}},
		["mount"] = Vector(-3.5 + 2,0.4 +0.65,1.3-1.45),
	}
}

SWEP.ReloadTime = 5.8
SWEP.ReloadSoundes = {
	"none",
	"none",
	"pwb2/weapons/vectorsmg/magout.wav",
	"none",
	"none",
	"pwb2/weapons/vectorsmg/magin.wav",
	"none",
	"weapons/tfa_ins2/mp7/boltback.wav",
	"pwb2/weapons/vectorsmg/boltrelease.wav",
	"none",
	"none",
	"none",
	"none"
}
SWEP.ReloadSound = "weapons/ar2/ar2_reload.wav"
SWEP.HoldType = "smg"
SWEP.ZoomPos = Vector(-4, 0.25, 22)
SWEP.RHandPos = Vector(-2, -2, 0)
SWEP.LHandPos = Vector(7, -2, -2)
SWEP.Spray = {}
for i = 1, 33 do
	SWEP.Spray[i] = Angle(-0.005 - math.cos(i) * 0.01, math.cos(i * i) * 0.07, 0) * 1
end

SWEP.Ergonomics = 1.1
SWEP.ShootAnimMul = 2

function SWEP:AnimHoldPost(model)
	self:BoneSetAdd(1, "l_finger0", Vector(0, 0, 0), Angle(-5, -10, 0))
	self:BoneSetAdd(1, "l_finger02", Vector(0, 0, 0), Angle(0, 25, 0))
	self:BoneSetAdd(1, "l_finger01", Vector(0, 0, 0), Angle(-25, 40, 0))
	self:BoneSetAdd(1, "l_finger1", Vector(0, 0, 0), Angle(-10, -40, 0))
	self:BoneSetAdd(1, "l_finger11", Vector(0, 0, 0), Angle(-10, -40, 0))
	self:BoneSetAdd(1, "l_finger2", Vector(0, 0, 0), Angle(-5, -50, 0))
	self:BoneSetAdd(1, "l_finger21", Vector(0, 0, 0), Angle(0, -10, 0))
end

function SWEP:DrawPost()
	local wep = self:GetWeaponEntity()
	if CLIENT and IsValid(wep) then
		self.shooanim = LerpFT(0.1,self.shooanim or 0,self:Clip1() > 0 and 0 or 0)
		wep:ManipulateBonePosition(2,Vector(0 ,0 ,-1.8*self.shooanim ),false)
		wep:ManipulateBonePosition(1,Vector(-0.5*self.ReloadSlideOffset ,0 ,0.1*self.ReloadSlideOffset),false)
	end
end

SWEP.Penetration = 7
SWEP.lengthSub = 31
SWEP.handsAng = Angle(0, 1, 0)
SWEP.DistSound = "mp5k/mp5k_dist.wav"

--local to head
SWEP.RHPos = Vector(3,-6,4)
SWEP.RHAng = Angle(0,-5,90)
--local to rh
SWEP.LHPos = Vector(13,-2,-3.5)
SWEP.LHAng = Angle(-40,0,-90)

--RELOAD ANIMS SMG????

SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(0,-5,-4),
	Vector(-15,5,-7),
	Vector(-15,5,-15),
	Vector(0,-5,-4),
	Vector(0,-5,-4),
	Vector(0,0,0),
	"fastreload",
	Vector(2,2,0),
	Vector(2,2,0),
	Vector(2,2,0),
	Vector(-4,2,0),
	Vector(0,0,0),
	"reloadend",
	Vector(0,0,0)
}

SWEP.ReloadSlideAnim = {
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5,
	5,
	5,
	0,
	0,
	0,
	0,
	0,
	0
}

SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(-35,0,0),
	Angle(-55,0,0),
	Angle(-75,0,0),
	Angle(-75,0,0),
	Angle(-75,0,0),
	Angle(-25,0,0),
	Angle(0,0,0),
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0)
}
SWEP.ReloadAnimRHAng = {
	Angle(0,0,0)
}
SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(0,25,25),
	Angle(5,25,25),
	Angle(-5,25,25),
	Angle(0,0,-15),
	Angle(0,0,-25),
	Angle(-25,0,-25),
	Angle(-15,0,-15),
	Angle(0,0,0)
}

-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(15,15,15),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,7,24),
	Angle(10,3,-5),
	Angle(2,3,-15),
	Angle(0,4,-22),
	Angle(0,3,-45),
	Angle(0,3,-45),
	Angle(0,-2,-2),
	Angle(0,0,0)
}