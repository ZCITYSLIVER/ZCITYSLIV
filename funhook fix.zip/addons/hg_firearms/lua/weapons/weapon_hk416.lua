-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_hk416.lua"

SWEP.Base = "homigrad_base"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "HK416"
SWEP.Author = "Heckler & Koch"
SWEP.Instructions = "Automatic rifle chambered in 5.56x45 mm\n\nRate of fire 850 rounds per minute"
SWEP.Category = "Weapons - Assault Rifles"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/zcity/w_hk416.mdl"

SWEP.WepSelectIcon2 = Material("pwb/sprites/hk416.png")
SWEP.IconOverride = "entities/weapon_pwb_hk416.png"

SWEP.CustomShell = "556x45"
--SWEP.EjectPos = Vector(-5,0,-5)
--SWEP.EjectAng = Angle(-45,-80,0)
SWEP.ShockMultiplier = 3

SWEP.weight = 3
SWEP.ScrappersSlot = "Primary"
SWEP.weaponInvCategory = 1
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "5.56x45 mm"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 44
SWEP.Primary.Spread = 0
SWEP.Primary.Force = 44
SWEP.Primary.Sound = {"zcitysnd/sound/weapons/firearms/mil_m16a4/m16_fire_01.wav", 75, 90, 100, 2}
SWEP.Primary.SoundEmpty = {"zcitysnd/sound/weapons/mk18/handling/mk18_empty.wav", 75, 105, 110, CHAN_WEAPON, 2}
SWEP.DistSound = "zcitysnd/sound/weapons/mk18/mk18_dist.wav"
SWEP.Primary.Wait = 0.063
SWEP.availableAttachments = {
	barrel = {
		[1] = {"supressor2", Vector(0,0,0), {}},
		[2] = {"supressor6", Vector(0,0,0), {}},
		["mount"] = Vector(-2,0.5,0.24),
	},
	sight = {
		["mount"] = { ironsight = Vector(-18.5, 1.58, 0.05), picatinny = Vector(-19, 1.51, 0.09)},
		["mountType"] = {"picatinny", "ironsight"},
		["empty"] = {
			"empty",
		},
	},
	grip = {
		["mount"] = Vector(4, 0.2, 0.1),
		["mountType"] = "picatinny"
	},
	underbarrel = {
		["mount"] = {["picatinny_small"] = Vector(5, -0.2, -2.15),["picatinny"] = Vector(8,.5,0.2)},
		["mountAngle"] = {["picatinny_small"] = Angle(0, 0, 180),["picatinny"] = Angle(0, 0, 0)},
		["mountType"] = {"picatinny_small","picatinny"},
		["noblock"] = true,
	}
}


SWEP.ReloadTime = 5.2
SWEP.ReloadSoundes = {
	"none",
	"none",
	"pwb2/weapons/m4a1/ru-556 clip out 1.wav",
	"none",
	"none",
	"pwb2/weapons/m4a1/ru-556 clip in 2.wav",
	"none",
	"none",
	"pwb2/weapons/m4a1/ru-556 bolt back.wav",
	"pwb2/weapons/m4a1/ru-556 bolt forward.wav",
	"none",
	"none",
	"none",
	"none"
}

SWEP.EjectPos = Vector(0,2.5,3)
SWEP.EjectAng = Angle(-45,-90,0)

SWEP.HoldType = "ar2"
SWEP.ZoomPos = Vector(-2.95, -0.05, 34)
--SWEP.RHandPos = Vector(-14,-3,3.5)
--SWEP.LHandPos = Vector(4,-4,-2)
SWEP.AimHands = Vector(0, 1, -4)
SWEP.RHandPos = Vector(-14, -1, 4)
SWEP.LHandPos = Vector(7, -2, -2)
--local to head
SWEP.RHPos = Vector(3,-7,3.5)
SWEP.RHAng = Angle(0,0,90)
--local to rh
SWEP.LHPos = Vector(12.5,1.9,-3)
SWEP.LHAng = Angle(-110,-180,0)

function SWEP:AnimationPost()
	self:BoneSetAdd(1, "l_finger0", Vector(0, 0, 0), Angle(-5, -31, 40))
	self:BoneSetAdd(1, "l_finger02", Vector(0, 0, 0), Angle(0, 15, 0))
	self:BoneSetAdd(1, "l_finger1", Vector(0, 0, 0), Angle(-10, -10, -10))
	self:BoneSetAdd(1, "l_finger2", Vector(0, 0, 0), Angle(-10, -40, 0))
	self:BoneSetAdd(1, "l_finger21", Vector(0, 0, 0), Angle(0, 35, 0))
end

SWEP.LocalMuzzlePos = Vector(22,0,3.25)
SWEP.LocalMuzzleAng = Angle(0,0,90)
SWEP.WeaponEyeAngles = Angle(0,0,0.002)

SWEP.attPos = Vector(0, -3.25, 22)
SWEP.attAng = Angle(0, 0, 0)

SWEP.StartAtt = {"ironsight1"}

SWEP.Spray = {}
for i = 1, 30 do
	SWEP.Spray[i] = Angle(-0.03 - math.cos(i) * 0.02, math.cos(i * i) * 0.04, 0) * 1.5
end

SWEP.Ergonomics = 1
SWEP.Penetration = 13
SWEP.WorldPos = Vector(5, -1, -1.5)
SWEP.WorldAng = Angle(0, 0, 0)
SWEP.UseCustomWorldModel = true
if CLIENT then end
--[[local rtmat = GetRenderTarget("pwb/models/weapons/v_hk416/glass", ScrW(), ScrH(), false)
    local mat = Material("pwb/models/weapons/v_hk416/glass")
    function SWEP:DrawHUDAdd()
        --self:DoHolo()
    end--]]
SWEP.lengthSub = 20
SWEP.handsAng = Angle(6, -1, 0)

function SWEP:DrawPost()
	local wep = self:GetWeaponEntity()
	local vec = vector_nasral
	if CLIENT and IsValid(wep) then
		self.shooanim = LerpFT(0.1,self.shooanim or 0,self:Clip1() > 0 and 0 or 0)
		vec[1] = 0
		vec[2] = 0
		vec[3] = -2*self.shooanim
		wep:ManipulateBonePosition(3,vec,false)
		vec[1] = -1*self.ReloadSlideOffset
		vec[2] = 0*self.ReloadSlideOffset
		vec[3] = 0*self.ReloadSlideOffset
		wep:ManipulateBonePosition(2,vec,false)
	end
end


-- RELOAD ANIM SR25/AR15
SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(-2,1,-6),
	Vector(-2,2,-6),
	Vector(-2,2,-6),
	Vector(2,7,-10),
	Vector(-15,5,-25),
	Vector(-15,15,-25),
	Vector(-5,15,-25),
	Vector(-2,4,-6),
	Vector(-2,2,-6),
	Vector(-2,2,-6),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	"fastreload",
	Vector(-3,1,-3),
	Vector(-3,2,-3),
	Vector(-3,3,-3),
	Vector(-9,3,-3),
	Vector(-9,3,-3),
	Vector(0,3,-3),
	"reloadend",
	Vector(0,0,0),
	Vector(0,0,0),
}

SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(-60,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
}

SWEP.ReloadAnimRHAng = {
	Angle(0,0,0),
}

SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(-15,25,-15),
	Angle(-15,25,-25),
	Angle(5,28,-25),
	Angle(5,25,-25),
	Angle(1,24,-22),
	Angle(2,25,-21),
	Angle(-5,24,-22),
	Angle(1,25,-21),
	Angle(0,24,-22),
	Angle(1,25,-32),
	Angle(-5,24,-25),
	Angle(0,25,-26),
	Angle(0,0,2),
	Angle(0,0,0),
}

SWEP.ReloadSlideAnim = {
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4,
	4,
	4,
	0,
	0,
	0,
	0
}
-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(15,15,15),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,7,24),
	Angle(10,3,-5),
	Angle(2,3,-15),
	Angle(0,4,-22),
	Angle(0,3,-45),
	Angle(0,3,-45),
	Angle(0,-2,-2),
	Angle(0,0,0)
}