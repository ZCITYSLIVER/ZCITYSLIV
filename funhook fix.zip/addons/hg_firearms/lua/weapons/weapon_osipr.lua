-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_osipr.lua"

SWEP.Base = "homigrad_base"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "Overwatch Standard Issue Pulse Rifle"
SWEP.Author = "Combine"
SWEP.Instructions = "O.S.I.P.R. is a Dark Energy/pulse-powered assault rifle.\n\nRate of fire 600 rounds per minute"
SWEP.Category = "Weapons - Assault Rifles"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/arccw/w_irifle.mdl"
SWEP.weaponInvCategory = 1
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "Pulse"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 50
SWEP.Primary.Spread = 0 
SWEP.Primary.Force = 50
SWEP.Primary.Sound = {"weapons/ar2/fire1.wav", 85, 90, 100}
SWEP.Primary.SoundEmpty = {"zcitysnd/sound/weapons/mk18/handling/mk18_empty.wav", 75, 100, 105, CHAN_WEAPON, 2}
SWEP.ShootEffect = 5
SWEP.ShellEject = true
SWEP.MuzzleEffectType = 0
SWEP.CustomShell = "Pulse"
SWEP.EjectPos = Vector(0,5,5)
SWEP.EjectAng = Angle(15,90,0)
SWEP.ScrappersSlot = "Primary"
SWEP.weight = 3.5

SWEP.punchmul = 0.5
SWEP.punchspeed = 1
--SWEP.podkid = 1.1

SWEP.PPSMuzzleEffect = "new_ar2_muzzle" -- shared in sh_effects.lu

SWEP.WepSelectIcon2 = Material("vgui/wep_jack_hmcd_ar2")
SWEP.IconOverride = "vgui/wep_jack_hmcd_ar2"

SWEP.availableAttachments = {
}

SWEP.Primary.Wait = 0.1
SWEP.ReloadTime = 4
SWEP.ReloadSoundes = {
	"none",
	"none",
	"none",
	"none",
	"weapons/ar2/ar2_magout.wav",
	"none",
	"none",
	"weapons/ar2/ar2_magin.wav",
	"none",
	"weapons/ar2/ar2_reload_rotate.wav",
	"none",
	"weapons/ar2/ar2_push.wav",
	"none",
	"none",
	"none",
	"none"
}

SWEP.HoldType = "ar2"
SWEP.ZoomPos = Vector(-0.03,-3.18,30)
SWEP.Spray = {}
for i = 1, 30 do
	SWEP.Spray[i] = Angle(-0.06 - math.cos(i) * 0.03, math.cos(i * i) * 0.04, 0) * 2
end

SWEP.DeploySnd = {"weapons/ar2/ar2_deploy.wav", 75, 100, 110}

SWEP.Ergonomics = 0.8
SWEP.HaveModel = "models/weapons/arccw/w_irifle.mdl"
SWEP.Penetration = 17
SWEP.WorldPos = Vector(15, -0.5, -1.5)
SWEP.WorldAng = Angle(0, 180, 0)
SWEP.UseCustomWorldModel = true
--https://youtu.be/I7TUHPn_W8c?list=RDEMAfyWQ8p5xUzfAWa3B6zoJg  wizards
SWEP.attPos = Vector(0, 0.7, 0)
SWEP.attAng = Angle(0.2, 0.7, 90)
SWEP.lengthSub = 20
SWEP.DistSound = "weapons/ar2/ar2_dist1.wav"

SWEP.LocalMuzzlePos = Vector(-9.963,-0.818,3.582)
SWEP.LocalMuzzleAng = Angle(0.207,179.943,-85.7)
SWEP.WeaponEyeAngles = Angle(0,180,0)

SWEP.rotatehuy = 180

--local to head
SWEP.RHPos = Vector(4,-8.5,5)
SWEP.RHAng = Angle(0,0,90)
--local to rh
SWEP.LHPos = Vector(10.5,-3,-9)
SWEP.LHAng = Angle(0-10,0,-90)

local finger1 = Angle(45,-25,50)

function SWEP:AnimHoldPost(model)
	self:BoneSetAdd(1, "l_finger0", vector_zero, finger1)
end

-- RELOAD ANIM AKM
SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(0,1,-2),
	Vector(0,2,-2),
	Vector(0,3,-2),
	Vector(0,3,-8),
	Vector(-8,15,-15),
	Vector(-15,20,-25),
	Vector(-13,12,-5),
	Vector(-6,6,-3),
	Vector(-1,5,-1),
	Vector(0,4,-1),
	"fastreload",
	Vector(0,3,-3),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	"reloadend",
	Vector(0,0,0),
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0)
}

SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
}

SWEP.ReloadAnimRHAng = {
	Angle(0,0,0),
}

SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(-25,15,-15),
	Angle(-25,15,-25),
	Angle(-10,15,-25),
	Angle(15,0,-25),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,-5),
	Angle(0,25,-40),
	Angle(0,25,-45),
	Angle(0,25,-25),
	Angle(0,25,-25),
	Angle(0,0,2),
	Angle(0,0,0),
}

-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(15,15,15),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,7,24),
	Angle(10,3,-5),
	Angle(2,3,-15),
	Angle(0,4,-22),
	Angle(0,3,-45),
	Angle(0,3,-45),
	Angle(0,-2,-2),
	Angle(0,0,0)
}