-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_remington870.lua"

--ents.Reg(nil,"weapon_m4super")
SWEP.Base = "weapon_m4super"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "Remington 870"
SWEP.Author = "Remington Arms"
SWEP.Instructions = "Pump-action shotgun chambered in 12/70 caliber"
SWEP.Category = "Weapons - Shotguns"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/zcity/w_shot_m3juper90.mdl"

SWEP.WepSelectIcon2 = Material("vgui/wep_jack_hmcd_shotgun.png")
SWEP.IconOverride = "vgui/wep_jack_hmcd_shotgun.png"

SWEP.LocalMuzzlePos = Vector(27.739,0.09,5.098)
SWEP.LocalMuzzleAng = Angle(0.4,-0.1,89.947)
SWEP.WeaponEyeAngles = Angle(-0.7,0.1,0)

SWEP.CustomShell = "12x70"
SWEP.EjectPos = Vector(-0,8,4)
SWEP.EjectAng = Angle(0,-90,0)
SWEP.ReloadSound = "weapons/remington_870/870_shell_in_1.wav"
SWEP.CockSound = "pwb2/weapons/ithaca37stakeout/pump.wav"
SWEP.weight = 4
SWEP.ScrappersSlot = "Primary"
SWEP.weaponInvCategory = 1
SWEP.ShellEject = "ShotgunShellEject"
SWEP.AutomaticDraw = false
SWEP.UseCustomWorldModel = false
SWEP.Primary.ClipSize = 6
SWEP.Primary.DefaultClip = 6
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "12/70 gauge"
SWEP.Primary.Cone = 0
SWEP.Primary.Spread = Vector(0.01, 0.01, 0.01)
SWEP.Primary.Sound = {"zcitysnd/sound/weapons/firearms/shtg_remington870/remington_fire_01.wav", 80, 90, 100}
SWEP.SupressedSound = {"toz_shotgun/toz_suppressed_fp.wav", 65, 90, 100}
SWEP.availableAttachments = {
	barrel = {
		[1] = {"supressor5", Vector(0,0,0), {}},
	},
	sight = {
		["mountType"] = "picatinny",
		["mount"] = Vector(-18, 1.15, 0),
	},
}

--models/weapons/tfa_ins2/upgrades/att_suppressor_12ga.mdl
SWEP.Primary.Wait = 0.25
SWEP.NumBullet = 8
SWEP.AnimShootMul = 3
SWEP.AnimShootHandMul = 10
SWEP.DeploySnd = {"homigrad/weapons/draw_hmg.mp3", 55, 100, 110}
SWEP.HolsterSnd = {"homigrad/weapons/hmg_holster.mp3", 55, 100, 110}
SWEP.HoldType = "ar2"
SWEP.ZoomPos = Vector(-1, 0.015, 32)
SWEP.RHandPos = Vector(0, 0, -1)
SWEP.LHandPos = Vector(7, 0, -2)
SWEP.Ergonomics = 0.9
SWEP.Penetration = 7
SWEP.WorldPos = Vector(1.5, -0.9, 1.5)
SWEP.WorldAng = Angle(0.7, -0.1, 0)
SWEP.UseCustomWorldModel = true
SWEP.attPos = Vector(0.4, -0.15, 0)
SWEP.attAng = Angle(0, -0, 0)
SWEP.lengthSub = 20

SWEP.holsteredBone = "ValveBiped.Bip01_Spine2"
SWEP.holsteredPos = Vector(4, 8, -6)
SWEP.holsteredAng = Angle(210, 0, 180)

--local to head
SWEP.RHPos = Vector(1,-5,3.4)
SWEP.RHAng = Angle(0,-15,90)
--local to rh
SWEP.LHPos = Vector(18,-0.8,-3.8)
SWEP.LHAng = Angle(-100,-180,0)

function SWEP:AnimHoldPost()
end
local ang1 = Angle(0, -20, 0)
local ang2 = Angle(0, -20, 0)
local ang3 = Angle(-2, -20, 0)
local ang4 = Angle(0, 20, 0)
local ang5 = Angle(0, -40, 10)
local ang6 = Angle(0, 50, 20)
local ang7 = Angle(0, 10, 20)
function SWEP:AnimationPost()
	self:BoneSetAdd(1, "l_finger0", nil, ang1)
	self:BoneSetAdd(1, "l_finger01", nil, ang2)
	self:BoneSetAdd(1, "l_finger1", nil, ang3)
	self:BoneSetAdd(1, "l_finger11", nil, ang4)
	self:BoneSetAdd(1, "l_finger2", nil, ang5)
	self:BoneSetAdd(1, "l_finger21", nil, ang6)
	self:BoneSetAdd(1, "l_finger02", nil, ang7)

	local animpos = math.Clamp(self:GetAnimPos_Draw(CurTime()),0,1)
	local sin = 1 - animpos
	if sin >= 0.5 then
		sin = 1 - sin
	else
		sin = sin * 1
	end
	sin = sin * 2
	--sin = math.ease.InOutExpo(sin)
	sin = math.ease.InOutSine(sin)

	if sin > 0 then
		self.LHPos[1] = 18 - sin * 6
		self.RHPos[1] = 1 - sin * 4
		self.inanim = true
	else
		self.inanim = nil
	end

	local wep = self:GetWeaponEntity()
	if CLIENT and IsValid(wep) then
		wep:ManipulateBonePosition(4,Vector(0,0,sin * -3),false)
	end
end

-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(-5,9,5),
	Angle(-5,9,14),
	Angle(-5,9,16),
	Angle(-6,10,15),
	Angle(-5,9,16),
	Angle(-10,15,-15),
	Angle(-2,22,-15),
	Angle(0,25,-32),
	Angle(0,24,-45),
	Angle(0,22,-55),
	Angle(0,20,-56),
	Angle(0,0,0)
}