-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_xm1014.lua"

--ents.Reg(nil,"weapon_m4super")
SWEP.Base = "weapon_m4super"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "XM-1014"
SWEP.Author = "Benelli Armi SPA"
SWEP.Instructions = "Semi-automatic shotgun chambered in 12/70"
SWEP.Category = "Weapons - Shotguns"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/tfa_ins2/w_m1014.mdl"
SWEP.ReloadSound = "weapons/tfa_ins2/m1014/toz_shell_insert_2.wav"
SWEP.WepSelectIcon2 = Material("pwb/sprites/xm1014.png")
SWEP.IconOverride = "entities/weapon_pwb_xm1014.png"


SWEP.availableAttachments = {
	sight = {
		["mountType"] = "picatinny",
		["mount"] = Vector(-23, 1, 0.08),
		--[[["empty"] = {
			"empty",
			{
				[1] = "null",
				[2] = "null"
			},
		},]]--
	},
}

SWEP.holsteredBone = "ValveBiped.Bip01_Spine2"
SWEP.holsteredPos = Vector(6, 9, -1)
SWEP.holsteredAng = Angle(210, 0, 180)

SWEP.LocalMuzzlePos = Vector(27.415,0.388,1.061)
SWEP.LocalMuzzleAng = Angle(0,-0.1,90)
SWEP.WeaponEyeAngles = Angle(0,0,0)

SWEP.weight = 4
SWEP.ScrappersSlot = "Primary"
SWEP.weaponInvCategory = 1
SWEP.CustomShell = "12x70"
--SWEP.EjectPos = Vector(-5,0,10)
--SWEP.EjectAng = Angle(-80,-90,0)
SWEP.UseCustomWorldModel = false
SWEP.Primary.ClipSize = 7
SWEP.Primary.DefaultClip = 7
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "12/70 gauge"
SWEP.Primary.Cone = 0
SWEP.Primary.Spread = Vector(0.01, 0.01, 0.01)
SWEP.NumBullet = 8

SWEP.Primary.Sound = {"toz_shotgun/toz_fp.wav", 80, 70, 75}
SWEP.Primary.Wait = 0.2
SWEP.DeploySnd = {"homigrad/weapons/draw_hmg.mp3", 65, 100, 110}
SWEP.HolsterSnd = {"homigrad/weapons/hmg_holster.mp3", 65, 100, 110}
SWEP.HoldType = "ar2"
SWEP.ZoomPos = Vector(0.12, -1.2, 0)
SWEP.RHandPos = Vector(-10, -2, 4)
SWEP.LHandPos = Vector(7, -2, 0)
SWEP.SprayRand = {Angle(-0.2, -0.4, 0), Angle(-0.4, 0.4, 0)}
SWEP.Ergonomics = 0.9
SWEP.Penetration = 7
SWEP.WorldPos = Vector(5, -0.5, -2.8)
SWEP.WorldAng = Angle(0, 0, 0)
SWEP.UseCustomWorldModel = true
SWEP.attPos = Vector(0, 0, 0)
SWEP.attAng = Angle(0, -0.1, 90)
SWEP.lengthSub = 18
SWEP.handsAng = Angle(0, -2, 0)

local finger1 = Angle(10, -12, -25)
local finger2 = Angle(-10,30,0)
local finger3 = Angle(0,-10,0)

function SWEP:AnimHoldPost(model)
	self:BoneSetAdd(1, "l_finger0", vector_zero, finger1)
    self:BoneSetAdd(1, "l_finger02", vector_zero, finger2)
    self:BoneSetAdd(1, "l_finger1", vector_zero, finger3)
    self:BoneSetAdd(1, "l_finger2", vector_zero, finger3)
end

--local to head
SWEP.RHPos = Vector(3,-5,3)
SWEP.RHAng = Angle(0,-5,90)
--local to rh
SWEP.LHPos = Vector(15,-1,-3)
SWEP.LHAng = Angle(-110,-90,-90)


-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(-5,15,5),
	Angle(-6,15,14),
	Angle(-7,15,16),
	Angle(-8,16,15),
	Angle(-7,17,16),
	Angle(-10,15,-15),
	Angle(-2,22,-15),
	Angle(0,15,-32),
	Angle(0,14,-45),
	Angle(0,12,-55),
	Angle(0,10,-54),
	Angle(0,0,0)
}