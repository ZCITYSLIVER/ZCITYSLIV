-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_spas12.lua"

--ents.Reg(nil,"weapon_m4super")
SWEP.Base = "weapon_m4super"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "Franchi SPAS-12"
SWEP.Author = "Luigi Franchi S.p.A."
SWEP.Instructions = "Semi-automatic shotgun chambered in 12/70"
SWEP.Category = "Weapons - Shotguns"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/tfa_ins2/w_spas12_bri.mdl"

SWEP.WepSelectIcon2 = Material("vgui/hud/tfa_ins2_spas12")
SWEP.IconOverride = "vgui/hud/tfa_ins2_spas12"
SWEP.ScrappersSlot = "Primary"
SWEP.CustomShell = "12x70"

SWEP.weight = 4
SWEP.weaponInvCategory = 1
SWEP.ShellEject = "ShotgunShellEject"
SWEP.UseCustomWorldModel = false
SWEP.Primary.ClipSize = 8
SWEP.Primary.DefaultClip = 8
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "12/70 gauge"
SWEP.Primary.Cone = 0
SWEP.Primary.Spread = Vector(0.01, 0.01, 0.01)
SWEP.NumBullet = 8
SWEP.Primary.Sound = {"toz_shotgun/toz_fp.wav", 80, 70, 75}
SWEP.Primary.Wait = 0.2
SWEP.HoldType = "ar2"
SWEP.DeploySnd = {"homigrad/weapons/draw_hmg.mp3", 55, 100, 110}
SWEP.HolsterSnd = {"homigrad/weapons/hmg_holster.mp3", 55, 100, 110}
SWEP.ReloadSound = "weapons/spas12/handling/toz_shell_insert_2.wav"
SWEP.ZoomPos = Vector(-1.4, 0.03, 33)
SWEP.RHandPos = Vector(-14, -1, 4)
SWEP.LHandPos = Vector(7, -2, 0)

SWEP.availableAttachments = {
	barrel = {
		[1] = {"supressor6", Vector(0,0,0), {}},
		[2] = {"supressor5", Vector(1.4,-0.45,0), {}},
		["mount"] = Vector(-0.5,0.3,0),
	}
}

SWEP.LocalMuzzlePos = Vector(27.531,0.388,1.044)
SWEP.LocalMuzzleAng = Angle(0.2,0,90)
SWEP.WeaponEyeAngles = Angle(0,0,0)

SWEP.Ergonomics = 0.9
SWEP.AnimShootMul = 3
SWEP.AnimShootHandMul = 3
SWEP.OpenBolt = true
SWEP.Penetration = 7
SWEP.WorldPos = Vector(6,-1,-2.8)
SWEP.WorldAng = Angle(0, 0, 0)
SWEP.UseCustomWorldModel = true
SWEP.attPos = Vector(0, 0, 0)
SWEP.attAng = Angle(0, -0.2, 0)
SWEP.lengthSub = 20
SWEP.handsAng = Angle(0, -1, 0)

--local to head
SWEP.RHPos = Vector(3,-5.4,4.2)
SWEP.RHAng = Angle(0,-10,90)
--local to rh
SWEP.LHPos = Vector(17,-1,-4)
SWEP.LHAng = Angle(-100,-90,-90)
function SWEP:AnimationPostPost()
	self:BoneSetAdd(1, "l_finger0", Vector(0, 0, 0), Angle(0, -30, -25))
end

function SWEP:AnimHoldPost()
end

function SWEP:DrawPost()
end

-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(-5,15,5),
	Angle(-6,15,14),
	Angle(-7,15,16),
	Angle(-8,16,15),
	Angle(-7,17,16),
	Angle(-10,15,-15),
	Angle(-2,22,-15),
	Angle(0,15,-32),
	Angle(0,14,-45),
	Angle(0,12,-55),
	Angle(0,10,-54),
	Angle(0,0,0)
}