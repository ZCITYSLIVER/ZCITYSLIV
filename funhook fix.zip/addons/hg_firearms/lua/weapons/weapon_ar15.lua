-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_ar15.lua"

SWEP.Base = "homigrad_base"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "AR-15"
SWEP.Author = "ArmaLite"
SWEP.Instructions = "An AR-15–style rifle is a lightweight semi-automatic rifle based on or similar to the Colt AR-15 design. The Colt model removed the selective fire feature of its predecessor, the original ArmaLite AR-15, itself a scaled-down derivative of the AR-10 design by Eugene Stoner. It is closely related to the military M16 rifle. The AR-15 is a good rifle for defending your possessions. Chambered in 5.56x45 mm"
SWEP.Category = "Weapons - Assault Rifles"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/zcity/colt_m4.mdl"
SWEP.weaponInvCategory = 1
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "5.56x45 mm"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 44
SWEP.Primary.Spread = 0
SWEP.Primary.Force = 44
SWEP.ShockMultiplier = 3
SWEP.Primary.Sound = {"zcitysnd/sound/weapons/firearms/mil_m16a4/m16_fire_01.wav", 75, 90, 100, 2}
SWEP.DistSound = "zcitysnd/sound/weapons/mk18/mk18_dist.wav"
SWEP.Primary.Wait = 0.11

SWEP.CustomShell = "556x45"
SWEP.EjectPos = Vector(-4,0,4)
SWEP.EjectAng = Angle(0,0,-65)
SWEP.ScrappersSlot = "Primary"
SWEP.WepSelectIcon2 = Material("vgui/wep_jack_hmcd_assaultrifle")
SWEP.IconOverride = "entities/weapon_insurgencym4a1.png"

SWEP.LocalMuzzlePos = Vector(0.106,23.254,3.5)
SWEP.LocalMuzzleAng = Angle(-0.5,90,90)
SWEP.WeaponEyeAngles = Angle(0,-90,0.5)

SWEP.weight = 3

SWEP.availableAttachments = {
	barrel = {
		[1] = {"supressor2", Vector(0,0,0), {}},
		[2] = {"supressor6", Vector(0,0,-0.1), {}},
		["mount"] = Vector(-2,1 - 0.5,0),
	},
	sight = {
		["empty"] = {
			"empty",
			{
				[2] = "models/drgordon/weapons/colt/m4/m4_sights",
			},
		},
		["ironsight2"] = {
			"ironsight2",
			{
				[2] = "models/drgordon/weapons/colt/m4/m4_sights",
			},
		},
		["mountType"] = {"picatinny","ironsight"},
		["mount"] = {ironsight = Vector(-13 - 4.5, 1.8 - 0.4, -0.1), picatinny = Vector(-13 - 6, 1.8 - 0.45, -0.15)},
		["mountAngle"] = Angle(0,0,1),
		["removehuy"] = {
			[2] = "null"
		},
	},
	grip = {
		["mount"] = Vector(2 + 8.6 - 6, -0.7 + 1, -0.1),
		["mountType"] = "picatinny"
	},
	underbarrel = {
		["mount"] = {["picatinny_small"] = Vector(3, -0.03, -2.5),["picatinny"] = Vector(5,0,0)},
		["mountAngle"] = {["picatinny_small"] = Angle(0, 0, -180),["picatinny"] = Angle(0, 0, 0)},
		["mountType"] = {"picatinny_small","picatinny"},
		["removehuy"] = {
		["picatinny"] = {
			},
			["picatinny_small"] = {
			}
		}
	}
}

SWEP.StartAtt = {"grip2"}

SWEP.ReloadTime = 5.5
SWEP.ReloadSoundes = {
	"none",
	"none",
	"none",
	"pwb2/weapons/m4a1/ru-556 clip out 1.wav",
	"none",
	"none",
	"pwb2/weapons/m4a1/ru-556 clip in 2.wav",
	"none",
	"none",
	"pwb2/weapons/m4a1/ru-556 bolt back.wav",
	"pwb2/weapons/m4a1/ru-556 bolt forward.wav",
	"none",
	"none",
	"none",
	"none"
}

SWEP.PPSMuzzleEffect = "pcf_jack_mf_mrifle2" -- shared in sh_effects.lua

SWEP.HoldType = "ar2"
SWEP.ZoomPos = Vector(-0.15,0.15, -1.2)
SWEP.RHandPos = Vector(-4, 0, -5)
SWEP.LHandPos = Vector(5, -2, -0)
SWEP.AimHands = Vector(-3, 0, -4.8)
SWEP.attPos = Vector(-1.5, 0, -25)
SWEP.attAng = Angle(90, -179, -90)

SWEP.cameraShakeMul = 1

SWEP.rotatehuy = 0

SWEP.Ergonomics = 1
SWEP.Penetration = 13
SWEP.WorldPos = Vector(4, -1, 0)
SWEP.WorldAng = Angle(0, 90, 0.5)
SWEP.UseCustomWorldModel = true
SWEP.handsAng = Angle(0, 0, 0)
SWEP.handsAng2 = Angle(0, 180, 0)

--local to head
SWEP.RHPos = Vector(3,-5.5,3.5)
SWEP.RHAng = Angle(0,-15,90)
--local to rh
SWEP.LHPos = Vector(13,0.8,-3.5)
SWEP.LHAng = Angle(-110,-180,0)

local finger1 = Angle(15, -15, 0)
local finger2 = Angle(-40, 20, 40)

SWEP.holsteredBone = "ValveBiped.Bip01_Spine2"
SWEP.holsteredPos = Vector(-4, 9.8, -4)
SWEP.holsteredAng = Angle(150, 180, 180)

function SWEP:DrawPost()
	local wep = self:GetWeaponEntity()
	local vec = vector_nasral
	if CLIENT and IsValid(wep) then
		self.shooanim = LerpFT(0.1,self.shooanim or 0,self:Clip1() > 0 and 0 or 0)
		vec[1] = -2*self.shooanim
		vec[2] = 0
		vec[3] = 0
		wep:ManipulateBonePosition(3,vec,false)
		vec[1] = -1*self.ReloadSlideOffset
		vec[2] = 0.09*self.ReloadSlideOffset
		vec[3] = -0.06*self.ReloadSlideOffset
		wep:ManipulateBonePosition(2,vec,false)
	end
end

function SWEP:AnimHoldPost()
	self:BoneSetAdd(1, "l_finger0", Vector(0, 0, 0), Angle(0, -20, 40))
	self:BoneSetAdd(1, "l_finger02", Vector(0, 0, 0), Angle(0, 40, 0))
	self:BoneSetAdd(1, "l_finger1", Vector(0, 0, 0), Angle(0, -10, 0))
	self:BoneSetAdd(1, "l_finger11", Vector(0, 0, 0), Angle(-10, 5, -10))
	self:BoneSetAdd(1, "l_finger2", Vector(0, 0, 0), Angle(-5, -29, 15))
	self:BoneSetAdd(1, "l_finger21", Vector(0, 0, 0), Angle(-10, 20, 0))
end

function SWEP:DrawHUDAdd()
	--[[local att = self:GetWeaponEntity():GetAttachment(1)
	local pos,ang = LocalToWorld(self.attPos,self.attAng,att.Pos,att.Ang)
	cam.Start3D()
	render.DrawLine(pos,pos+ang:Forward()*30,color_white,true)
	cam.End3D()--]]
end

-- RELOAD ANIM SR25/AR15
SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(-2,1,-8),
	Vector(-2,2,-9),
	Vector(-2,2,-9),
	Vector(-2,7,-10),
	Vector(-15,5,-25),
	Vector(-15,15,-25),
	Vector(-5,15,-25),
	Vector(-2,4,-10),
	Vector(-2,2,-10),
	Vector(-2,2,-10),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	"fastreload",
	Vector(-3,1,-3),
	Vector(-3,2,-3),
	Vector(-3,3,-3),
	Vector(-9,3,-3),
	Vector(-9,3,-3),
	Vector(0,3,-3),
	"reloadend",
	Vector(0,0,0),
	Vector(0,0,0),
}

SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(-60,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(-90,0,110),
	Angle(0,0,95),
	Angle(0,0,60),
	Angle(0,0,30),
	Angle(0,0,2),
	Angle(0,0,0),
}

SWEP.ReloadAnimRHAng = {
	Angle(0,0,0),
}

SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(-15,25,-15),
	Angle(-15,25,-25),
	Angle(5,28,-25),
	Angle(5,25,-25),
	Angle(1,24,-22),
	Angle(2,25,-21),
	Angle(-5,24,-22),
	Angle(1,25,-21),
	Angle(0,24,-22),
	Angle(1,25,-32),
	Angle(-5,24,-25),
	Angle(0,25,-26),
	Angle(0,0,2),
	Angle(0,0,0),
}

SWEP.ReloadSlideAnim = {
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4,
	4,
	4,
	0,
	0,
	0,
	0
}

-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(15,15,15),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,7,24),
	Angle(10,3,-5),
	Angle(2,3,-15),
	Angle(0,4,-22),
	Angle(0,3,-45),
	Angle(0,3,-45),
	Angle(0,-2,-2),
	Angle(0,0,0)
}