-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_mac11.lua"

SWEP.Base = "homigrad_base"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "MAC-11"
SWEP.Author = "Military Armament Corporation"
SWEP.Instructions = "Submachine gun chambered in 9x17 mm\n\nRate of fire 1600 rounds per minute"--BRUH TOO LAZY MF TOO LAZY BROOO
SWEP.Category = "Weapons - Machine-Pistols"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/pwb2/weapons/w_mac11.mdl"

SWEP.WepSelectIcon2 = Material("pwb2/vgui/weapons/mac11.png")
SWEP.IconOverride = "entities/weapon_pwb2_mac11.png"

SWEP.CustomShell = "9x19"
--SWEP.EjectPos = Vector(0,-20,5)
--SWEP.EjectAng = Angle(0,90,0)
SWEP.punchmul = 0.5
SWEP.punchspeed = 3
SWEP.weight = 1
SWEP.AnimShootHandMul = 0.01
SWEP.ScrappersSlot = "Secondary"

SWEP.LocalMuzzlePos = Vector(15.731,0.009,5.144)
SWEP.LocalMuzzleAng = Angle(0,-0.022,90.248)
SWEP.WeaponEyeAngles = Angle(0,0,0)

SWEP.podkid = 0.5

SWEP.weaponInvCategory = 2
SWEP.ShellEject = "EjectBrass_9mm"
SWEP.Primary.ClipSize = 32
SWEP.Primary.DefaultClip = 32
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "9x19 mm Parabellum"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 16
SWEP.Primary.Spread = 0
SWEP.Primary.Force = 16
SWEP.Primary.Sound = {"homigrad/weapons/pistols/mac10-1.wav", 75, 120, 130}
SWEP.Primary.Wait = 0.0375
SWEP.ReloadTime = 4.9
SWEP.ReloadSoundes = {
	"none",
	"none",
	"pwb/weapons/uzi/clipout.wav",
	"none",
	"none",
	"pwb/weapons/uzi/clipin.wav",
	"none",
	"none",
	"weapons/tfa_ins2/mp7/boltback.wav",
	"none",
	"pwb2/weapons/vectorsmg/boltrelease.wav",
	"none",
	"none",
	"none",
	"none"
}

SWEP.PPSMuzzleEffect = "pcf_jack_mf_mpistol" -- shared in sh_effects.lua

SWEP.HoldType = "revolver"
SWEP.ZoomPos = Vector(-2, 0.1, 23)
SWEP.RHandPos = Vector(3, -1, 2)
SWEP.LHandPos = false
SWEP.Spray = {}
for i = 1, 32 do
	SWEP.Spray[i] = Angle(-0.01 - math.cos(i) * 0.02, math.cos(i ^ 3) * 0.05, 0) * 2
end

SWEP.Ergonomics = 1.3
SWEP.OpenBolt = true
SWEP.Penetration = 6
SWEP.WorldPos = Vector(-3.6, -1.2, 1.5)
SWEP.WorldAng = Angle(0, 0, 0)
SWEP.UseCustomWorldModel = true
SWEP.lengthSub = 25
SWEP.DistSound = "m9/m9_dist.wav"
SWEP.holsteredBone = "ValveBiped.Bip01_Pelvis"
SWEP.holsteredPos = Vector(-2, 5, 6)
SWEP.holsteredAng = Angle(25, -65, -90)
SWEP.shouldntDrawHolstered = true

--local to head
SWEP.RHPos = Vector(12,-5,4)
SWEP.RHAng = Angle(0,-5,90)
--local to rh
SWEP.LHPos = Vector(-1.2,-1.4,-2.8)
SWEP.LHAng = Angle(5,9,-100)

local finger1 = Angle(-25,10,25)
local finger2 = Angle(0,25,0)
local finger3 = Angle(31,1,-25)
local finger4 = Angle(-10,-5,-5)
local finger5 = Angle(0,-65,-15)
local finger6 = Angle(15,-5,-15)

function SWEP:AnimHoldPost()
	--self:BoneSetAdd(1, "r_finger0", vector_zero, finger6)
	--self:BoneSetAdd(1, "l_finger0", vector_zero, finger1)
    --self:BoneSetAdd(1, "l_finger02", vector_zero, finger2)
	--self:BoneSetAdd(1, "l_finger1", vector_zero, finger3)
	--self:BoneSetAdd(1, "r_finger1", vector_zero, finger4)
	--self:BoneSetAdd(1, "r_finger11", vector_zero, finger5)
end

--RELOAD ANIMS PISTOL

SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(0,-2,-2),
	Vector(-15,-2,-7),
	Vector(-15,-2,-15),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	"fastreload",
	Vector(5,0,5),
	Vector(-2,1,1),
	Vector(-2,1,1),
	Vector(-2,1,1),
	Vector(0,0,0),
	"reloadend",
	Vector(0,0,0)
}
SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(0,0,-40),
	Angle(0,0,-90),
	Angle(0,0,-90),
	Angle(0,0,-60),
	Angle(0,0,-20),
	Angle(0,0,0),
	Angle(-35,0,0),
	Angle(-55,0,0),
	Angle(-75,0,0),
	Angle(-75,0,0),
	Angle(-75,0,0),
	Angle(-25,0,0),
	Angle(0,0,0),
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0)
}
SWEP.ReloadAnimRHAng = {
	Angle(0,0,0)
}
SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(0,15,15),
	Angle(15,15,15),
	Angle(-5,15,15),
	Angle(0,0,-5),
	Angle(0,0,-15),
	Angle(-25,0,-15),
	Angle(-15,0,-15),
	Angle(0,0,0)
}

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(6,0,5),
	Angle(15,0,14),
	Angle(16,0,16),
	Angle(4,0,12),
	Angle(-6,0,-2),
	Angle(-15,7,-15),
	Angle(-16,18,-35),
	Angle(-17,17,-42),
	Angle(-18,16,-44),
	Angle(-14,10,-46),
	Angle(-2,2,-4),
	Angle(0,0,0)
}