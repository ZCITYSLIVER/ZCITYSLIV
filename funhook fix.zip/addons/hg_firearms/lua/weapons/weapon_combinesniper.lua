-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_combinesniper.lua"

SWEP.Base = "weapon_osipr"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "Combine Sniper Rifle"
SWEP.Author = "Combine"
SWEP.Instructions = "A powerful combine semi-automatic sniper rifle. Fires the same pulse ammo, but the force of the bullet is much greater."
SWEP.Category = "Weapons - Other"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/w_models/combine_sniper_test_huy.mdl"

SWEP.WepSelectIcon2 = Material("vgui/wep_jack_hmcd_combinesniper")
SWEP.IconOverride = "vgui/wep_jack_hmcd_combinesniper"
SWEP.ScrappersSlot = "Primary"
SWEP.weaponInvCategory = 1
SWEP.Primary.ClipSize = 5
SWEP.Primary.DefaultClip = 5
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "Pulse"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 50
SWEP.Primary.Spread = 0
SWEP.Primary.Force = 50
SWEP.ShellEject = true
SWEP.MuzzleEffectType = 0
SWEP.CustomShell = "Pulse"

SWEP.ZoomPos = Vector(-5.2, 26, 2.1)
SWEP.Ergonomics = 0.8
SWEP.WorldPos = Vector(19,-1.1,-5)
SWEP.WorldAng = Angle(0, 0, 0)

SWEP.attPos = Vector(0,0,2)
SWEP.attAng = Angle(-90,0,0)

SWEP.DistSound = "mosin/mosin_dist.wav"

SWEP.holsteredBone = "ValveBiped.Bip01_Spine2"
SWEP.holsteredPos = Vector(12,8,4)
SWEP.holsteredAng = Angle(150, -5, 0)

SWEP.mat = Material("combine_sniper/huyhuy")
SWEP.scopemat = Material("decals/scope.png")
SWEP.perekrestie = Material("vgui/arc9_eft_shared/reticles/scope_30mm_march_tactical_3-24x42_marks.png")
SWEP.sizeperekrestie = 4200

SWEP.localScopePos = Vector(-30,0.8,3.9)
SWEP.scope_blackout = 700
SWEP.rot = 0
SWEP.FOVMin = 10
SWEP.FOVMax = 20
SWEP.perekrestieSize = false
SWEP.blackoutsize = 3100
SWEP.scopedef = true

SWEP.AnimShootMul = 2
SWEP.AnimShootHandMul = 5
SWEP.addSprayMul = 2

SWEP.PenetrationMultiplier = 4
SWEP.DamageMultiplier = 3

SWEP.weight = 5

if CLIENT then
	function SWEP:DrawHUDAdd()
		self:DoRT()
	end

	local lfang2 = Angle(0, 30, 0)
	local lfang1 = Angle(0, 30, 0)
	local lfang0 = Angle(-0, -30, 10)
	local vec_zero = Vector(0,0,0)
	local l_finger02 = Angle(-10,0,0)
	function SWEP:AnimHoldPost()
		self:BoneSetAdd(1, "l_finger0", vec_zero, lfang0)
		self:BoneSetAdd(1, "l_finger02", vec_zero, l_finger02)
		self:BoneSetAdd(1, "l_finger1", vec_zero, lfang1)
		self:BoneSetAdd(1, "l_finger2", vec_zero, lfang2)
	end
end

SWEP.LocalMuzzlePos = Vector(31,0,1.2)
SWEP.LocalMuzzleAng = Angle(0,0,10.02)
SWEP.WeaponEyeAngles = Angle(0,0,0)

SWEP.CanSuicide = false

--local to head
SWEP.RHPos = Vector(3,-10,5)
SWEP.RHAng = Angle(0,-5,90)
--local to rh
SWEP.LHPos = Vector(14,1,-5)
SWEP.LHAng = Angle(-90,-90,-90)

local finger1 = Angle(-15,0,5)
local finger2 = Angle(-15,45,-5)

--RELOAD ANIMS PISTOL

SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(0,1,-2),
	Vector(0,2,-2),
	Vector(0,3,-2),
	Vector(0,3,-8),
	Vector(-8,-15,-15),
	Vector(-15,-20,-25),
	Vector(-13,-12,-5),
	Vector(-6,6,-3),
	Vector(-1,5,-1),
	Vector(0,4,-1),
	Vector(0,3,-3),
	Vector(0,0,0),
	Vector(0,0,0),
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,0),
	Vector(0,0,5),
	Vector(6,1,5),
	Vector(6,2,5),
	Vector(6,1,0),
	Vector(6,2,0),
	Vector(-1,3,1),
	Vector(-2,3,1),
	Vector(-5,3,1),
	Vector(-2,3,1),
	Vector(-2,2,1),
	Vector(0,0,0),
}

SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
}

SWEP.ReloadAnimRHAng = {
	Angle(0,0,0),
}

SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(-15,5,-5),
	Angle(-15,15,-15),
	Angle(-10,15,-15),
	Angle(5,0,-15),
	Angle(9,2,0),
	Angle(4,1,0),
	Angle(7,-1,0),
	Angle(7,2,0),
	Angle(5,2,-5),
	Angle(-10,-1,-0),
	Angle(0,2,0),
	Angle(0,0,0),
}

-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(-15,15,5),
	Angle(-15,15,14),
	Angle(-15,15,16),
	Angle(-16,16,15),
	Angle(-15,17,16),
	Angle(-10,15,-15),
	Angle(-2,22,-15),
	Angle(0,25,-32),
	Angle(0,24,-45),
	Angle(0,22,-65),
	Angle(0,20,-64),
	Angle(0,0,0)
}