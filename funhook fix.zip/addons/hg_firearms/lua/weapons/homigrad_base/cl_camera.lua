-- "addons\\homigrad-weapons\\lua\\weapons\\homigrad_base\\cl_camera.lua"

--
local vecZero, angZero = Vector(0, 0, 0), Angle(0, 0, 0)
local eyeAngL = EyeAngles()
local angZoom = Angle(0, 0, 0)
local k, k2, passive = 0, 0, 0
local vec1 = Vector(-1, 0, 0)
local angfuk23 = Angle(0,0,0)

SWEP.ZoomPos = Vector(-3, 1.2, 35)
SWEP.attAng = Angle(0, 0, 0)
SWEP.attPos = Vector(0, 0, 0)

SWEP.Ergonomics = 1

local Lerp, LerpVector, LerpAngle = Lerp, LerpVector, LerpAngle
local ply
local math_sin, math_cos = math.sin, math.cos
local math_Clamp = math.Clamp
local CurTime = CurTime
local gun
local traceBuilder = {}
local util_TraceLine = util.TraceLine
local dof_zoom = 0
disthuy = 0
local angRandLerp = Angle(0,0,0)
local angle_spray = Angle(0,0,0)
local fovlerp = 0

function SWEP:GetZoomPos(wepAng,wepPos,recoilZoomPos,view,eyePos)
	recoilZoomPos = recoilZoomPos or vecZero
	
	local att = self:GetMuzzleAtt(gun, true, false)
	
	local tr,pos,ang = self:GetTrace()

	local up, right, forward = wepAng:Up(), wepAng:Right(), wepAng:Forward()

	local addPos = -(-self.ZoomPos)
	local originWep = view.origin - wepPos

	local zoomPos = forward * addPos[3] + up * addPos[1] + right * addPos[2]
	local posZoom = originWep + zoomPos
	
	local override = self:GetCameraOverride(view)
	if override then
		posZoom = override
	end
	
	if eyePos then
		local _,hitpos,dist = util.DistanceToLine(posZoom,posZoom + view.angles:Forward(),eyePos)
		disthuy = Lerp(FrameTime() * 10,disthuy,dist)
		posZoom = posZoom + ang:Forward() * disthuy - recoilZoomPos * 0.5
	elseif self:HasAttachment("sight") then
		posZoom = posZoom + (att.Ang:Forward() * addPos[3]/1.8) + forward * 2	
	end
	
	return posZoom,wepPos
end

function SWEP:GetZoomValue()
	return k or 0
end

SWEP.punchmul = 1
SWEP.punchspeed = 1

local blurintens = CreateClientConVar("hg_weaponshotblur_mul", "0.03", true, false,"Sets shotblurintens",0,1)
local shouldblur = CreateClientConVar("hg_weaponshotblur_enable", "1", true, false,"Enable shotblur",0,1)

function SWEP:Blur(x,y,w,z)
	if not shouldblur:GetBool() then return nil end
	local primary = self.Primary
	
	local fraction = self:GetAnimPos_Shoot2(self.lastShoot or 0, 0.01 * (math.max((self.weight or 1) - 1,0.1) * 5 + 1))

	w = w+fraction * - blurintens:GetFloat()
	local blurtbl = {x,y,w,z}
	return blurtbl
end

hook.Add("HUDPaint","asdasdasddasdsahuy",function()
	if LocalPlayer():Alive() then return end
	local ply = LocalPlayer():GetNWEntity("spect",LocalPlayer())
	if not ply:IsPlayer() then return end
	local wep = ply:GetActiveWeapon()
	if IsValid(ply) and IsValid(wep) and wep.DrawHUD then
		wep:DrawHUD()
	end
end)
local hg_fov = ConVarExists("hg_fov") and GetConVar("hg_fov") or CreateClientConVar("hg_fov", "70", true, false, "changes fov to value", 75, 100)
local fov = hg_fov:GetFloat()
function SWEP:Camera(eyePos, eyeAng, view, vellen, ply)
	ply = ply or self:GetOwner()
	--self:SetHandPos()
	
	local wepPos, wepAng
	if self.UseCustomWorldModel then
		self:WorldModel_Transform()
		self:DrawAttachments()
		self:GetTrace(true)
		gun = self.worldModel
	else
		gun = self
	end
	
	self.Anim_RecoilCameraZoom = LerpVectorFT(0.5, self.Anim_RecoilCameraZoom or Vector(0,0,0), self.Anim_RecoilCameraZoomSet)
	local primary = self.Primary--FrameTime() * 30,FrameTime() * 10
	--self.Anim_RecoilLerp = math.max((primary.Next - CurTime()) / primary.Wait / 2, 0)
	self.Anim_RecoilCameraZoomSet = LerpVectorFT(0.1, self.Anim_RecoilCameraZoomSet or Vector(0,0,0), vector_origin)
	local att = self:GetMuzzleAtt(gun, true, false)
	if not att then return end
	wepPos, wepAng = att.Pos, att.Ang
	wepAng:RotateAroundAxis(wepAng:Forward(), -90)

	if not ply.GetAimVector then return end
	local aimvec = ply:GetAimVector():Angle()
	local up, right, forward = aimvec:Up(), aimvec:Right(), aimvec:Forward()
	
	addPos = self.Anim_RecoilCameraZoom * 2 * self.punchmul --/ 2 *
	local recoilZoomPos = up * addPos[1] + right * addPos[2] + forward * addPos[3]
	if not self.attachments then return end
	local att = self:GetMuzzleAtt(gun, self:HasAttachment("sight"),false)
	wepPos, wepAng = att.Pos, att.Ang
	wepAng:RotateAroundAxis(wepAng:Forward(), -90)

	--bodycam MODE

	eyeAngL = eyeAng
	
	local posZoom,wepPos = self:GetZoomPos(wepAng,wepPos,recoilZoomPos,view,eyePos)

	angZoom = eyeAngL
	addPos = self.IdlePos
	--angZoom[3] = 0
	local posIdle = eyePos - recoilZoomPos * 0.5
	local angIdle = eyeAngL
	local zoom = self:IsZoom() and (IsValid(ply.FakeRagdoll) or ((self:CloseAnim() * self.closeanimdis) < 5 and (posIdle:IsEqualTol(posZoom,20))))
	
	k = Lerp(self.Ergonomics * FrameTime() * 4, k, zoom and 1 or 0)

	local organism = ply.organism or {}
	local debil = (((organism.larm or 0) > 0.75 and (organism.larm - 0.75) or 0) + ((organism.rarm or 0) > 0.75 and (organism.rarm - 0.75) or 0)) / 4
	local addview = AngleRand(-debil-0.005,debil+0.005) * (organism.holdingbreath and 0.1 or 1)
	addview[3] = 0
	if ply == LocalPlayer() then
		ViewPunch2(addview)
	end
	--PrintTable(organism)
	--ViewPunch2(angRandLerp)
	local k4 = ((organism.adrenaline or 0) * 0.01) * math.max(organism.recoilmul or 1,0.1)
	local angRand = AngleRand(-k4 * 2, k4 * 2)
	--ViewPunch(angRand)
	
	local angRand2 = AngleRand(-0.1, 0.1)

	if (ply.Karma or 100) < 60 then
		ViewPunch2(angRand2 * (1 - ply.Karma / 60))
	end

	local angfuk = angfuk23
	angfuk[2] = -position_difference3[2]/40

	ViewPunch2(angfuk)

	--local shootLerp = self.Anim_RecoilLerp
	--view.fov = Lerp(shootLerp,view.fov,view.fov - 5 * self.Penetration / 15)
	local outputPos, outputAng
	local animpos = (self.AdditionalAng or Angle(0, 0, 0))[2] / 20 --:GetAnimShoot2()
	local eyeSpray = -(-self.EyeSpray)
	local animposSpray, spray = self:GetCameraSprayValues(ply, eyeSpray, animpos)
	--angZoom[1] = angZoom[1] + animpos * 20
	posZoom:Add(-animposSpray * 250)

	if GetGlobalBool("FullRealismMode",false) then
		local mul = (hg.GunPositions[ply] and hg.GunPositions[ply].x or 1) * 100
		posIdle:Add(angle_difference_localvec*mul+position_difference * 0.3)
		posZoom:Add(angle_difference_localvec*mul)
		angIdle:Add(-angle_difference*1)
		--angIdle:Add(offsetView)
		--posZoom = LerpVector(k,posZoom - angIdle:Up() * 4,posZoom)
	end
	--angZoom[3] = Lerp(k,angZoom[3],angZoom[3])

	outputPos = LerpVector(k, posIdle, posZoom)
	outputAng = LerpAngle(k, angIdle, angZoom)
	--if self:CanUse() then
	outputAng:Add(-eyeSpray * 10)
	if GetGlobalBool("FullRealismMode",false) then
		outputAng:Add(-eyeSpray * 5)
		outputPos:Add(-spray * 120)
	end
	outputAng:Add(-GetViewPunchAngles2() / 2.5)
	outputAng:Add(-eyeSpray)
	--posIdle:Add(angle_difference_localvec*100)
	--outputAng:Add(offsetView/5)
	--posZoom = LerpVector(k,posZoom - angIdle:Up() * 3,posZoom)
	
	outputPos:Add(-spray * 150)
	outputPos:Add((angle_difference_localvec * 30) / (self.Ergonomics or 1))
	--outputAng:Add(-self.WepAngOffset / 15)

	local fthuy = ftlerped * 150

	angle_spray[3] = math.Rand(-self.sprayAngles[3], self.sprayAngles[3]) * 60 * game.GetTimeScale() * 0.7
	angle_spray[1] = math.Rand(-self.sprayAngles[3], self.sprayAngles[3]) * 12 * game.GetTimeScale() * 0.7
	angle_spray[2] = math.Rand(-self.sprayAngles[3], self.sprayAngles[3]) * 12 * game.GetTimeScale() * 0.7
	outputAng:Add(angle_spray)
		
	if not GetGlobalBool("FullRealismMode",false) then
		local mul = ((1 - self.Ergonomics) * 1 + 1) / 30
		local k = 2
		local asdAng = -(-angle_difference)
		asdAng[3] = 0
		outputAng:Add(asdAng * mul * k * 30)
		ply:SetEyeAngles(ply:EyeAngles() + asdAng * mul * k)
	else
		local mul = ((1 - 0.9) * 1 + 1) / 30
		local k = 2
		local asdAng = -(-angle_difference)
		asdAng[3] = 0
		outputAng:Add(asdAng * mul * k * -30)
		ply:SetEyeAngles(ply:EyeAngles() + asdAng * mul * k * -1 * fthuy)
	end

	view.origin = view.origin - outputPos
	view.angles = outputAng

	fovlerp = Lerp(0.01,fovlerp,(ply:IsSprinting() and ply:GetVelocity():LengthSqr() > 1500 and 10 or 0) - ( organism and (organism and (((organism.immobilization or 0) / 4) - (organism.adrenaline or 0) * 5)) or 0) / 2 - (ply.suiciding and (ply:GetNetVar("suicide_time",CurTime()) < CurTime()) and (1 - math.max(ply:GetNetVar("suicide_time",CurTime()) + 8 - CurTime(),0) / 8) * 20 or 0))

	fov = Lerp(k,math.Clamp(hg_fov:GetFloat(),75,100) + fovlerp,self.isscoping and 55 or 75)
	
	view.fov = fov
	
	if LOW_RENDER then
		view.zfar = 50
	end

	return view
end

function SWEP:GetCameraSprayValues(ply, eyeSpray, animpos)
	local animposSpray = -(-eyeSpray)
	animposSpray[1] = animpos
	animposSpray[2] = 0 - (curlean or 0) / 10
	animposSpray[3] = 0
	animposSpray = -animposSpray:Forward()
	animposSpray[1] = 0
	animposSpray:Rotate(ply:EyeAngles())
	local spray = (eyeSpray):Forward()
	spray[1] = 0
	spray[3] = spray[3] / 3
	spray[2] = spray[2]
	spray:Rotate(ply:EyeAngles())
	return animposSpray * 1, spray * (self:IsZoom() and 2 or 5)
end

function SWEP:ChangeCameraPassive(value)
	return value
end

function SWEP:IsEyeAng()
	return self.reload or self.deploy or self.holster or self:IsSprinting() or not self:GetOwner():OnGround()
end

local white = Color(255, 255, 255)
local white2 = Color(150, 150, 150)
local white3 = Color(0, 0, 0)
local red = Color(250, 100, 100)
local hg_show_hitposmuzzle = ConVarExists("hg_show_hitposmuzzle") and GetConVar("hg_show_hitposmuzzle") or CreateClientConVar("hg_show_hitposmuzzle", "0", false, false, "shows weapons crosshair, work only ведьма admin rank or sv_cheats 1")
local sv_cheats = GetConVar("sv_cheats")
local pos, wep, lply
hook.Add("HUDPaint", "homigrad-test-att", function()
	lply = LocalPlayer()
	if not hg_show_hitposmuzzle:GetBool() or (hg_show_hitposmuzzle:GetBool() and not (sv_cheats:GetBool() or lply:IsAdmin() or lply:IsSuperAdmin())) then return end
	wep = lply:GetActiveWeapon()
	if not IsValid(wep) or not wep.GetTrace then return end
	local tr = wep:GetTrace()

	pos = tr.StartPos:ToScreen()
	draw.RoundedBox(0, pos.x - 2, pos.y - 2, 4, 4, red)
	pos = tr.HitPos:ToScreen()
	draw.RoundedBox(0, pos.x - 2, pos.y - 2, 4, 4, white)
	local tr = lply:GetEyeTrace()
	local scr = tr.HitPos:ToScreen()
	draw.RoundedBox(0, scr.x - 2, scr.y - 2, 4, 4, white2)
	draw.RoundedBox(0, ScrW() / 2 - 2, ScrH() / 2 - 2, 4, 4, white3)
end)

local pp_dof_initlength = CreateClientConVar("pp_dof_initlength", "256", true, false)
local pp_dof_spacing = CreateClientConVar("pp_dof_spacing", "512", true, false)
local pp_dof = CreateClientConVar("pp_dof", "0", false, false)
local potatopc = GetConVar("hg_potatopc") or CreateClientConVar("hg_potatopc", "0", true, false, "enable this if you are noob", 0, 1)
hook.Add("Think", "DOFThink", function()
	--if not GAMEMODE:PostProcessPermitted("dof") or not pp_dof:GetBool() or potatopc:GetInt() or 0 >= 1 then return end
	--DOF_SPACING = pp_dof_spacing:GetFloat()
	--DOF_OFFSET = pp_dof_initlength:GetFloat()
end)

--[[local angleHuy = Angle(0,-90,0)
local someVec = Vector(0,0,36)
hook.Add("PreDrawTranslucentRenderables","huy",function()
	local lply = LocalPlayer()
	local firstPerson = true--lply == GetViewEntity()
	if firstPerson then
		lply:ManipulateBoneAngles(lply:LookupBone("ValveBiped.Bip01_Spine1"),angleHuy)
		playerModel = playerModel or ClientsideModel(lply:GetModel())

		--local pos,ang = lply:GetBonePosition(0)

		playerModel:SetPos(lply:GetPos())

		--ang:RotateAroundAxis(ang:Right(),90)
		--ang:RotateAroundAxis(ang:Forward(),-90)
		local ang = lply:EyeAngles()
		ang[1] = 0
		playerModel:SetAngles(ang)
		local ang = lply:EyeAngles()

		playerModel:ManipulateBoneAngles(playerModel:LookupBone("ValveBiped.Bip01_Head1"),Angle(ang[3],-ang[1],0))

		playerModel:ManipulateBonePosition(0,playerModel:WorldToLocal(lply:GetBonePosition(0)) - someVec,false)
		playerModel:ManipulateBoneAngles(playerModel:LookupBone("ValveBiped.Bip01_L_Thigh"),-angleHuy)
		playerModel:ManipulateBoneAngles(playerModel:LookupBone("ValveBiped.Bip01_R_Thigh"),-angleHuy)
	end
end)]]

local ot = Angle(0, 0, 0)

hook.Add("HG.InputMouseApply", "huyasd2", function(tbl)
	if IsValid(follow) then return end

	local wep = LocalPlayer():GetActiveWeapon()
	if not wep.bipodDir then return end

	local attang = wep.bipodDir:Angle()

	attang[1] = 0

	tbl.angle.pitch = math.Clamp(tbl.angle.pitch + tbl.y / 50, -89, 89)
	tbl.angle.yaw = tbl.angle.yaw - tbl.x / 50

	local ang = -(-tbl.angle)
	ang[3] = 0

	local _, ot = WorldToLocal(vector_origin, ang, vector_origin, attang)

	ot[2] = math.Clamp(ot[2], -25, 25)
	ot[1] = math.Clamp(ot[1], -25, 15)

	local _, newang = LocalToWorld(vector_origin, ot, vector_origin, attang)

	tbl.angle = newang
	
	tbl.override_angle = true
end)