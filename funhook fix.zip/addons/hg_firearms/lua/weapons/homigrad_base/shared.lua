-- "addons\\homigrad-weapons\\lua\\weapons\\homigrad_base\\shared.lua"

SWEP.Base = "weapon_base"
SWEP.PrintName = "base_hg"
SWEP.Category = "Other"
SWEP.Spawnable = false
SWEP.AdminOnly = true
SWEP.ReloadTime = 1
SWEP.ReloadSound = "weapons/smg1/smg1_reload.wav"
SWEP.Primary.SoundEmpty = {"zcitysnd/sound/weapons/m14/handling/m14_empty.wav", 75, 100, 105, CHAN_WEAPON, 2}
SWEP.Primary.Wait = 0.1
SWEP.Primary.Next = 0
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"
SWEP.Weight = 5
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = false
SWEP.shouldntDrawHolstered = false
hg.weapons = hg.weapons or {}

SWEP.ishgwep = true

SWEP.EyeSprayVel = Angle(0,0,0)

SWEP.ScrappersSlot = "Primary"
--[type_] = {1 = name,2 = dmg,3 = pen,4 = numbullet,5 = RubberBullets,6 = ShockMultiplier,7 = Force},
SWEP.AmmoTypes2 = {
	["12/70 gauge"] = {
		[1] = {"12/70 gauge"},
		[2] = {"12/70 beanbag"},
		[3] = {"12/70 Slug"}
	},
	["9x19 mm Parabellum"] = {
		[1] = {"9x19 mm Parabellum"},
		[2] = {"9x19 mm Green Tracer"},
	},
	["5.56x45 mm"] = {
		[1] = {"5.56x45 mm"},
		[2] = {"5.56x45 mm M856"},
		[3] = {"5.56x45 mm AP"}
	},
	["14.5x114mm B32"] = {
		[1] = {"14.5x114mm B32"},
		[2] = {"14.5x114mm BZTM"}
	},
	[".45 ACP"] = {
		[1] = {".45 ACP"},
		[2] = {".45 ACP Hydro Shock"},
	},
	["9mm PAK Blank"] = {
		[1] = {"9mm PAK Blank"},
		[2] = {"9mm PAK Flash Defense"},
	},
}

function SWEP:OnReloaded()
	if self.newammotype then
		self:ApplyAmmoChanges(self.newammotype)
	end
end

function SWEP:ChangeFOV()
	--ееее😎
end

function SWEP:IsClient()
	return CLIENT and self:GetOwner() == LocalPlayer()
end

function SWEP:KeyDown(KEY)
	local owner = self:GetOwner()

	if not IsValid(owner) then return end

	local isdown = owner:KeyDown(KEY)

	return isdown
end

SWEP.CanSuicide = true

game.AddParticles("particles/tfa_smoke.pcf")
PrecacheParticleSystem("smoke_trail_tfa")
PrecacheParticleSystem("smoke_trail_wild")
--function SWEP:PVS_Connect() end

SWEP.StartAtt = {}
function SWEP:Initialize()
	self:SetLastShootTime(0)
	self.LastPrimaryDryFire = 0
	self:Initialize_Spray()
	self:Initialize_Anim()
	self:Initialize_Reload()
	self:SetClip1(self.Primary.DefaultClip)
	self:Draw()
	
	if self:GetOwner():IsNPC() then
		self:SetHoldType( self.HoldType )
	end
	
	self.SlotPos = self:IsPistolHoldType() and 1 or 2

	self.deploy = CurTime() + self.CooldownDeploy / self.Ergonomics

	self:ClearAttachments()

	self.AmmoTypes = self.AmmoTypes2[self.Primary.Ammo]

	--game.AddParticles("particles/tfa_ins2_muzzlesmoke.pcf")
	--PrecacheParticleSystem("tfa_ins2_weapon_muzzle_smoke")
	
	if hg.PrecacheSoundsSWEP then
		hg.PrecacheSoundsSWEP(self)
	end

	self:WorldModel_Transform()

	table.insert(hg.weapons,self)
	self.ishgweapon = true

	if SERVER then
		self:SetNetVar("attachments",self.attachments)
	end
	--SetNetVar("weapons",hg.weapons)

	if CLIENT then
		if not IsValid(self.worldModel) then
			self:CreateWorldModel()
		end
		
		self:CallOnRemove("asdasd", function()
			if self.flashlight and self.flashlight:IsValid() then
				self.flashlight:Remove()
				self.flashlight = nil
			end
		end)
	end

	self.init = false
	
	timer.Simple(0.1,function()
		if self.AmmoTypes and SERVER then
			self:ApplyAmmoChanges(1)
		end
	end)

	if SERVER then hg.SyncWeapons() end
	self:InitializePost()
end

SWEP.WepSelectIcon2 = Material("null")
SWEP.IconOverride = ""

function SWEP:DrawWeaponSelection( x, y, wide, tall, alpha )
	render.PushFilterMag(TEXFILTER.ANISOTROPIC)
	render.PushFilterMin(TEXFILTER.ANISOTROPIC)
	surface.SetDrawColor( 255, 255, 255, alpha )
	surface.SetMaterial( self.WepSelectIcon2 )
	if not self.IconEdited then
		self.WepSelectIcon2:SetInt("$flags", 32)
		self.IconEdited = true
	end
	if self.WepSelectIcon2box then
		surface.DrawTexturedRect( x + wide/2 - (wide/1.95)/2, y,  wide/1.95 , wide/1.95 )
	else
		surface.DrawTexturedRect( x, y,  wide , wide/2)
	end

	render.PopFilterMin()
	render.PopFilterMag()

	self:PrintWeaponInfo( x + wide + 20, y + tall * 0.95, alpha )

end

if CLIENT then
	hook.Add("OnGlobalVarSet","hg-weapons",function(key,var)
		if key == "weapons" then
			hg.weapons = var
		end
	end)

	hook.Add("OnNetVarSet","weapons-net-var",function(index,key,var)
		if key == "attachments" then
			local ent = Entity(index)

			ent.attachments = nil
			if ent.modelAtt then
				for atta, model in pairs(ent.modelAtt) do
					if not atta then continue end
					if IsValid(model) then model:Remove() end
					ent.modelAtt[atta] = nil
				end
			end

			ent.attachments = var
		end
	end)
else
	function hg.SyncWeapons()
		SetNetVar("weapons",hg.weapons)
	end
end

function SWEP:ShouldDropOnDie()
	return true
end

function SWEP:OwnerChanged()
	self.init = true
	self.reload = nil
	--self.drawBullet = self:Clip1() > 0

	self.deploy = CurTime() + self.CooldownDeploy / self.Ergonomics

	if SERVER then
		self:SetNetVar("attachments",self.attachments)
	end
end

function SWEP:InitializePost()
end

hg.weaponsDead = hg.weaponsDead or {}
function SWEP:OnRemove()
	if SERVER then
		table.RemoveByValue(hg.weapons,self)

		SetNetVar("weapons",hg.weapons)
	end
end

local owner
local CurTime = CurTime
function SWEP:IsZoom()
	local owner = self:GetOwner()
	return self:CanUse() and (self:GetOwner():IsPlayer() and self:KeyDown(IN_ATTACK2)) and ((IsValid(owner.FakeRagdoll) and self:KeyDown(IN_USE)) or (owner:IsOnGround() or owner:InVehicle())) and not owner.suiciding-- and owner.posture ~= 1 and owner.posture ~= 3-- and (not IsValid(owner.FakeRagdoll) or self:KeyDown(IN_JUMP))
end

function SWEP:CanUse()
	return not (self.reload or self.deploy or self.holster or (self:GetOwner():IsPlayer() and (self:IsSprinting() or (self:GetOwner().organism and self:GetOwner().organism.otrub))))-- and (not self:GetOwner():InVehicle() or self:IsPistolHoldType())
end

function SWEP:IsSprinting()
	local ply = self:GetOwner()
	return not ply:IsNPC() and (self:KeyDown(IN_SPEED)) and not IsValid(ply.FakeRagdoll)
end

function SWEP:IsLocal()
	return CLIENT and self:GetOwner() == LocalPlayer()
end

function SWEP:IsLocal2()
	return CLIENT and self:GetOwner() == LocalPlayer() and LocalPlayer() == GetViewEntity()
end

local math_random = math.random
function SWEP:PlaySnd(snd, server, chan)
	if SERVER and not server then return end
	local owner = IsValid(self:GetOwner().FakeRagdoll) and self:GetOwner().FakeRagdoll or self
	
	if CLIENT then
		local view = render.GetViewSetup(true)
		local time = owner:GetPos():Distance(view.origin) / 17836
		timer.Simple(time, function()
			if not IsValid(self) or not IsValid(self:GetOwner()) then return end
			
			local owner = IsValid(self:GetOwner().FakeRagdoll) and self:GetOwner().FakeRagdoll or self
			owner = IsValid(owner) and owner
			if not owner then return end
			if type(snd) == "table" then
				EmitSound(snd[1], owner:GetPos(), owner:EntIndex(), chan or CHAN_ITEM, 1, snd[2] or (self.Supressor and 65 or 75), 0, math_random(snd[3] or 100, snd[4] or 100))
				--EmitSound(snd[1], owner:GetPos() + vector_up * 5, owner:EntIndex(), chan or CHAN_BODY, 1, snd[2] or (self.Supressor and 65 or 75), 0, math_random(snd[3] or 100, snd[4] or 100))
				--sound.Play( snd[1], owner:GetPos(), 100)
				--sound.Play( snd[1], owner:GetPos(), 100)
				--sound.Play( snd[1], owner:GetPos(), 100)
				--owner:EmitSound(snd[1],75,100,1,CHAN_AUTO)
				--owner:EmitSound(snd[1],75,100,1,CHAN_WEAPON)
				--owner:EmitSound(snd[1],75,100,1,CHAN_REPLACE)
			else
				EmitSound(snd, owner:GetPos(), owner:EntIndex(), chan or CHAN_ITEM, 1, self.Supressor and 65 or 75, 0, 100)
				--EmitSound(snd, owner:GetPos() + vector_up * 5, owner:EntIndex(), chan or CHAN_BODY, 1, self.Supressor and 65 or 75, 0, 100)
				--owner:EmitSound(snd,75,100,1,CHAN_AUTO)
				--owner:EmitSound(snd,75,100,1,CHAN_WEAPON)
				--owner:EmitSound(snd,75,100,1,CHAN_REPLACE)
			end
		end)
	else
		if type(snd) == "table" then
			EmitSound(snd[1], owner:GetPos(), owner:EntIndex(), chan or CHAN_ITEM, 1, snd[2] or (self.Supressor and 75 or 75), 0, math_random(snd[3] or 100, snd[4] or 100))
		else
			EmitSound(snd, owner:GetPos(), owner:EntIndex(), chan or CHAN_ITEM, 1, self.Supressor and 65 or 75, 0, 100)
		end
	end
end

function SWEP:PlaySndDist(snd)
	if SERVER then return end
	local owner = IsValid(self:GetOwner().FakeRagdoll) and self:GetOwner().FakeRagdoll or self:GetOwner()
	owner = IsValid(owner) and owner or self
	local view = render.GetViewSetup(true)
	local time = owner:GetPos():Distance(view.origin) / 17836
	timer.Simple(time, function()
		if not IsValid(self) or not IsValid(self:GetOwner()) then return end

		local owner = IsValid(self) and (IsValid(self:GetOwner()) and (IsValid(self:GetOwner().FakeRagdoll) and self:GetOwner().FakeRagdoll or self:GetOwner()) or self)
		owner = IsValid(owner) and owner
		if not owner then return end
		EmitSound(snd, owner:GetPos(), owner:EntIndex(), CHAN_AUTO, 1, self.Supressor and 1 or 100, 0, 100)
	end)
end

local math_Rand = math.Rand
local matrix, matrixSet
local math_random = math.random
local primary
local weapons_Get = weapons.Get
if SERVER then util.AddNetworkString("hgwep shoot") end
function SWEP:CanPrimaryAttack()
	local owner = self:GetOwner()
	--[[if owner.suiciding then
		if (owner:GetNetVar("suicide_time",CurTime()) + 8) < CurTime() then if SERVER then owner:SetNetVar("suicide_time",nil) end return true end
		if SERVER and owner:KeyPressed(IN_ATTACK) then owner:SetNetVar("suicide_time",owner:GetNetVar("suicide_time",CurTime()) - 0.5) end
		return false
	end--]]
	return true
end

hook.Add("Player Think","huyhuy",function(ply)
	local wep = ply:GetActiveWeapon()
	if not ishgweapon(wep) then ply.suiciding = false end
end)

function SWEP:Shoot(override)
	--self:GetWeaponEntity():ResetSequenceInfo()
	--self:GetWeaponEntity():SetSequence(1)
	
	if self:GetOwner():IsNPC() then self.drawBullet = true end
	if not self:CanPrimaryAttack() then return false end
	--if not self:CanUse() then return false end
	if CLIENT and self:GetOwner() != LocalPlayer() and not override then return false end
	local primary = self.Primary
	if override then self.drawBullet = override end

	if not self.drawBullet or (self:Clip1() == 0 and not override) then
		self.LastPrimaryDryFire = CurTime()
		self:PrimaryShootEmpty()
		primary.Automatic = false
		return false
	end
	
	if not self:GetOwner():IsNPC() and primary.Next > CurTime() then return false end
	if not self:GetOwner():IsNPC() and (primary.NextFire or 0) > CurTime() then return false end
	primary.Next = CurTime() + primary.Wait
	primary.RealAutomatic = primary.RealAutomatic or weapons_Get(self:GetClass()).Primary.Automatic
	primary.Automatic = primary.RealAutomatic
	self:PrimaryShoot()
	self:PrimaryShootPost()
end

function SWEP:PrimaryAttack()
	if CLIENT and not IsFirstTimePredicted() then return end
	if CLIENT and not self:IsClient() then return end
	
	local huy = self:Shoot() ~= false
	if SERVER then
		net.Start("hgwep shoot")
		net.WriteEntity(self)
		net.WriteBool(huy)
		net.Broadcast()
	end
end

function SWEP:PrimaryShootPost()
end

function SWEP:Draw(server)
	if self.drawBullet == false then
		if SERVER and server then self:RejectShell(self.ShellEject) end
		if CLIENT and not server then self:RejectShell(self.ShellEject) end
		self.drawBullet = nil
	end

	if self:Clip1() > 0 then self.drawBullet = true end
end

SWEP.AutomaticDraw = true
SWEP.ShootAnimMul = 2
function SWEP:PrimaryShoot()
	self:EmitShoot()
	if SERVER or self:IsClient() then
		self:FireBullet()
	end
	self.dwr_reverbDisable = nil
	self.shooanim = self.ShootAnimMul

	if not (CLIENT and self:GetOwner():IsNPC()) then
		self:TakePrimaryAmmo(1)
	end

	self.drawBullet = false
	if self.AutomaticDraw then self:Draw() end
	self:PrimarySpread()
end

SWEP.SightSlideOffset = 1

function SWEP:PrimaryShootEmpty()
	if CLIENT then return end
	self:PlaySnd(self.Primary.SoundEmpty, true, CHAN_AUTO)
end

local hg_newsounds = GetConVar("hg_newsounds") or CreateClientConVar("hg_newsounds", "0", true, false, "new gun sounds", 0, 1)

SWEP.DistSound = "m4a1/m4a1_dist.wav"
SWEP.NewSoundClose = nil
SWEP.NewSoundDist = nil
SWEP.NewSoundSupressor = nil
function SWEP:EmitShoot()
	if SERVER then return end
	local snd_new = "sounds_zcity/"..(string.Replace(self:GetClass(),"weapon_","")).."/"
	local snd_close = snd_new.."close.wav"
	local snd_suppressor = snd_new.."supressor.wav"
	local snd_dist = snd_new.."dist.wav"
	if not self.NewSoundClose then
		local a1,_ = file.Find("sound/"..snd_close,"GAME")
		local a2,_ = file.Find("sound/"..snd_suppressor,"GAME")
		self.NewSoundClose = a1
		self.NewSoundSupressor = a2
	end
	
	if hg_newsounds:GetBool() and (not self.Supressor and (self.NewSoundClose and not table.IsEmpty(self.NewSoundClose)) or (self.NewSoundSupressor and not table.IsEmpty(self.NewSoundSupressor))) then
		self:PlaySnd(self.Supressor and snd_suppressor or snd_close)
		self:PlaySndDist(self.Supressor and snd_suppressor or snd_dist)
	else
		self:PlaySnd(self.Supressor and (self.SupressedSound or (self:IsPistolHoldType() and "homigrad/weapons/pistols/sil.wav" or "m4a1/m4a1_suppressed_fp.wav")) or self.Primary.Sound)
		self:PlaySndDist(self.DistSound)
	end
end

function SWEP:CanSecondaryAttack()
end

function SWEP:SecondaryAttack()
end

PISTOLS_WAIT = 0.15

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

if CLIENT then
	local hook_Run = hook.Run
	hook.Add("Think", "homigrad-weapons", function()
		for i,wep in ipairs(hg.weapons) do
			--local wep = ply:GetActiveWeapon()
			if not IsValid(wep) or not wep.Step or (not IsValid(wep:GetOwner()) and wep:GetVelocity():Length() < 1) then continue end
			hook_Run("SWEPStep", wep)
			wep:Step()
		end
	end)
end

function SWEP:GetInfo()
	if not IsValid(self) then return {self.Primary.ClipSize,hg.ClearAttachments(self.ClassName)} end -- дурак
	return {self:Clip1(),self:GetNetVar("attachments")}
end

function SWEP:SetInfo(info)
	if not info then return end
	self:SetClip1(info[1])
	self.attachments = info[2]
	self:SetNetVar("attachments",info[2] or {})
end

local colBlack = Color(0, 0, 0, 125)
local colWhite = Color(255, 255, 255, 255)
local yellow = Color(255, 255, 0)
local vecZero = Vector(0, 0, 0)
local angZero = Angle(0, 0, 0)
local lerpAmmoCheck = 0
local function LerpColor(lerp, source, set)
	return Lerp(lerp, source.r, set.r), Lerp(lerp, source.g, set.g), Lerp(lerp, source.b, set.b)
end

local col = Color(0, 0, 0)
local col2 = Color(0, 0, 0)
local dynamicmags
local instructions 
if CLIENT then
	surface.CreateFont("AmmoFont",{
		font = "Bahnschrift",
		size = ScreenScale(16),
		extended = true,
		weight = 500,
		antialias = true
	})

	surface.CreateFont("DescFont",{
		font = "Bahnschrift",
		size = ScreenScale(8),
		extended = true,
		shadow = true,
		weight = 500,
		antialias = true
	})

	dynamicmags = CreateClientConVar("hg_dynamic_mags", "0", true, false)
	instructions = CreateClientConVar("hg_instructions","1", true, false)
end

function SWEP:DrawHUDAdd()
end

local blur = Material( "pp/blurscreen" )
local function DrawBlurRect(x, y, w, h, dens, alpha)

	local lightness = alpha and 80*math.Clamp(alpha,0,255)/255 or 50

	draw.RoundedBox(0,x,y,w,h,Color(0,0,0,lightness))
   	surface.SetDrawColor(0,0,0)
end

	--local clipsize = (self:GetMaxClip1() + (self.OpenBolt and 0 or 1))
	--local owner = self:GetOwner()
	--if not IsValid(owner) then return end
	--local attpos = self:GetMuzzleAtt(nil, true, true).Pos
	--local posX,posY = dynamicmags:GetBool() and attpos:ToScreen().x + 50 or ScrW() - ScrW() / 4, dynamicmags:GetBool() and attpos:ToScreen().y + 90 or ScrH() - ScrH() / 6
	--local sizeX,sizeY =  (clipsize == 1 and ScrH() / 15 or ScrW() / 40) * scale, (clipsize == 1 and ScrH() / 80 or ScrH() / 10) * scale
--
--
	--lerpAmmoCheck = Lerp(owner:KeyDown(IN_RELOAD) and 0.5 or 0.02, lerpAmmoCheck, self:KeyDown(IN_RELOAD) and 1 or (dynamicmags:GetBool() and 0 or 0.0))
	--colBlack.a = 125 * lerpAmmoCheck
	--colWhite.a = 255 * lerpAmmoCheck
	--local ammoLeft = math.ceil(self:Clip1() / clipsize * sizeY)
	--local ammo = owner:GetAmmoCount(self:GetPrimaryAmmoType())
	--local magCount = math.ceil(ammo / clipsize)
--
	--col:SetUnpacked(LerpColor(ammoLeft / sizeY, yellow, color_white))
	--col.a = 255 * lerpAmmoCheck
	--if col.a > 1 then
	--	DrawBlurRect(posX-sizeX*(clipsize ~= 1 and .2 or .3),posY-sizeY*(clipsize ~= 1 and .1 or .7),(sizeX+sizeX*(clipsize ~= 1 and .12 or .2)) * (math.max(math.min(magCount+1,(clipsize ~= 1 and 5 or 4)),1.3)), sizeY + (clipsize ~= 1 and 20 or 60),7,col.a*5)
	--end
	--
	--local color = col
	--surface.SetDrawColor(color)
	--surface.DrawRect(posX,posY - ammoLeft + sizeY, sizeX, ammoLeft, 1)
	--surface.DrawOutlinedRect(posX - 5, posY - 5, sizeX + 10, sizeY + 10, 1)
--
	--local posX,posY = posX + (clipsize == 1 and ScrW() / 40 or ScrW() / 50), posY + (clipsize == 1 and ScrH()/70 or ScrH() / 20)
	--local sizeX,sizeY = sizeX / 2,sizeY / 2
--
	--for i = 1,magCount do
	--	if i > 3 then continue end
	--	local ammoasd = math.min(clipsize,ammo)
	--	ammo = ammo - ammoasd
	--	
	--	local ammoLeft = math.ceil(ammoasd / clipsize * sizeY)
	--	
	--	col2:SetUnpacked(LerpColor(ammoLeft / sizeY, yellow, color_white))
	--	col2.a = 255 * lerpAmmoCheck
	--	surface.SetDrawColor(col2)
	--	surface.DrawRect(posX + (sizeX + 15) * i,posY - ammoLeft + sizeY, sizeX, ammoLeft, 1)
	--	surface.DrawOutlinedRect(posX - 5 + (sizeX + 15) * i,posY - 5, sizeX + 10, sizeY + 10, 1)
	--end
--
	--if magCount > 3 then
	--	draw.SimpleText("+"..magCount-3,"AmmoFont",posX + (sizeX + 15) * 4 + 1, posY + sizeX/2 + 1,Color(0,0,0,255*lerpAmmoCheck),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
	--	draw.SimpleText("+"..magCount-3,"AmmoFont",posX + (sizeX + 15) * 4 , posY + sizeX/2,Color(255,255,255,255*lerpAmmoCheck),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
	--end
	

	--self.hudinspect = self.hudinspect or 0
	--if instructions:GetBool() and self.hudinspect - (CurTime()-6) > 0 then
	--	self.InfoAlpha = Lerp(FrameTime() * 10,self.InfoAlpha or 0,math.min(self.hudinspect - (CurTime() - 5),1)*255)
	--	local txt = self.Instructions
	--	if not self.InfoMarkup1 then
	--		self.InfoMarkup1 = markup.Parse( "<font=DescFont>"..txt.."</font>", 450 )
	--	end
	--	DrawBlurRect(posX - 5 - self.InfoMarkup1:GetWidth() - ScrW()*0.05, posY - self.InfoMarkup1:GetHeight()/2 - 5, self.InfoMarkup1:GetWidth()+10, self.InfoMarkup1:GetHeight()+10, 8, self.InfoAlpha)
	--	self.InfoMarkup1:Draw(posX- ScrW()*0.05,posY,TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER,self.InfoAlpha)
	--end

local scale = 1
local developer = GetConVar("developer")


local function DrawBullet(matIcon, x, y, size, cColor)
	render.PushFilterMin(TEXFILTER.ANISOTROPIC)
		surface.SetDrawColor(cColor)
		surface.SetMaterial(matIcon or matPistolAmmo)
		surface.DrawTexturedRect(x-size/2,y-size,size,size)
	render.PopFilterMin()
end

if CLIENT then
	local scrW, scrH = ScrW(), ScrH()

	local HudHPos = 0.8
	local lastShoot = 0
	local StopShowBullet = false
	local WhiteColor = Color(200,200,200,255)

	local matPistolAmmo = Material("vgui/hud/bullets/low_caliber.png")
	local matRfileAmmo = Material("vgui/hud/bullets/high_caliber.png")
	local matShotgunAmmo = Material("vgui/hud/bullets/buck_caliber.png")
	local lerpAmmoCheck = 0
	local ammoCheck = 0
	local color_bg = Color(0,0,0,150)
	local ammoLongCheck = 0
	SWEP.DrawAmmoMetods = {
		["Default"] = function(self,texture)
			local clipsize = (self:GetMaxClip1()+ (self.OpenBolt and 0 or 1))
			local clip = self:Clip1()
			local owner = self:GetOwner()
			local shoot = CurTime() - self:LastShootTime()
			local ammo = owner:GetAmmoCount(self:GetPrimaryAmmoType())
			local magCount = math.ceil(ammo / clipsize)
			
			lastShoot = LerpFT(0.5,lastShoot, shoot > 0 and 1 or 0)
			lastShootFor = lastShoot

			if (clip < clipsize/3 and lastShoot < 0.9 and dynamicmags:GetBool()) or self:KeyDown(IN_RELOAD) then
				ammoCheck = CurTime() + 1	
			end
			ammoLongCheck = LerpFT(0.025,ammoLongCheck, self:KeyDown(IN_RELOAD) and 5 or 0)
			
			if ammoLongCheck > 4 then
				local text = (
					(clip > clipsize - (self.OpenBolt and 0 or 1) - 1) and "Full" or 
					(clip <= clipsize and clip > clipsize/1.5 ) and "~ Full" or 
					(clip <= clipsize/1.5 and clip > clipsize/3.5) and "~ Half" or 
					(clip <= clipsize/3.5 and clip != 0 ) and "~ Almost Empty" or 
					(clip == 0 and "Empty")
				)
				draw.SimpleText(text,"AmmoFont",scrW*0.8 + 2, scrH*HudHPos + scrH*0.05 + 2,Color(0,0,0,210*math.max(ammoLongCheck-4,0)),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
				draw.SimpleText(text,"AmmoFont",scrW*0.8, scrH*HudHPos + scrH*0.05,Color(255,255,255,210*math.max(ammoLongCheck-4,0)),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
			end

			lerpAmmoCheck = LerpFT((ammoCheck > CurTime()) and 0.8 or 0.05, lerpAmmoCheck, ammoCheck > CurTime() and 1 or 0)
			local Yellow = (( clipsize/clip )-1)/(clipsize/5)
			--print(Yellow)
			color_bg = Color(55*Yellow,0,0,150)
			--draw.RoundedBox(0,scrW*0.75-(scrH*0.12/2),scrH*0.72,scrH*0.12,scrH*0.18,ColorAlpha(color_black,50))

			if clip > 0 then
				DrawBullet(texture,scrW*0.75 - (scrH*0.16)+(scrH*0.08)*(1+lastShoot) + 2,scrH*(HudHPos) + 2,scrH*0.08, ColorAlpha(color_bg,(250*lastShoot) * lerpAmmoCheck))
				DrawBullet(texture,scrW*0.75 - (scrH*0.16)+(scrH*0.08)*(1+lastShoot),scrH*(HudHPos),scrH*0.08, ColorAlpha(WhiteColor,(150*lastShoot) * lerpAmmoCheck))
				--if lastShoot < 0.2 then StopShowBullet = true end
			end
			--if StopShowBullet then
			--	lastShootFor = 0 
			--	if lastShoot > 0.6 then
			--		StopShowBullet = false
			--	end
			--else
			--end
			--print(clipsize)
			--print(lastShoot)
			for i = 2, clip do
				if i > 6 and lastShootFor > 0.5 or i > 7 then continue end
				i = i - 1
				if i < 2 then
					DrawBullet(texture,scrW*0.75 + 2,scrH*((HudHPos) + i*(0.026*lastShootFor))+2,scrH*0.08, ColorAlpha(color_bg,250 * lerpAmmoCheck))
					DrawBullet(texture,scrW*0.75,scrH*((HudHPos) + i*(0.026*lastShootFor)),scrH*0.08, ColorAlpha(WhiteColor,150 * lerpAmmoCheck))
				else
					DrawBullet(texture,scrW*0.75+2,scrH*((HudHPos - 0.026) + i*0.026+(0.026*lastShootFor))+2,scrH*0.08, ColorAlpha(color_bg,(210 - (20 * i)) * lerpAmmoCheck))
					DrawBullet(texture,scrW*0.75,scrH*((HudHPos - 0.026) + i*0.026+(0.026*lastShootFor)),scrH*0.08, ColorAlpha(WhiteColor,(210 - (20 * i) )* lerpAmmoCheck))
				end
			end

			if magCount > 0 then
				draw.SimpleText("+"..magCount,"AmmoFont",scrW*0.8 + 2, scrH*HudHPos + 2,Color(0,0,0,210*lerpAmmoCheck),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
				draw.SimpleText("+"..magCount,"AmmoFont",scrW*0.8, scrH*HudHPos,Color(255,255,255,210*lerpAmmoCheck),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
			end
			--draw.SimpleText("lastShoot: "..lastShoot,"Default",0,0)
		end
	}

	SWEP.AmmoDrawMetod = "Default"

	function SWEP:DrawHUD()
		if not IsValid(self:GetOwner()) then return end
		local ammotype = hg.ammotypeshuy[self.Primary.Ammo].BulletSettings and hg.ammotypeshuy[self.Primary.Ammo].BulletSettings.Icon or matPistolAmmo
		self.DrawAmmoMetods[self.AmmoDrawMetod](self,ammotype)
		
		self.isscoping = false

		if self.attachments then
			for plc,att in pairs(self.attachments) do
				if not self:HasAttachment(plc) then continue end
				if hg.attachments[plc][att[1]].sightFunction then
					hg.attachments[plc][att[1]].sightFunction(self)
				end
			end
		end
		self:ChangeFOV()
		self:CheckBipod()
		self:DrawHUDAdd()

		self.hudinspect = self.hudinspect or 0

		--[[if developer:GetBool() and LocalPlayer():IsAdmin() then
			local _,tr = self:CloseAnim(true)
			cam.Start3D()
				render.DrawLine(tr.StartPos,tr.HitPos,color_white,true)
			cam.End3D()
		end--]]
	end
end

if SERVER then
	hook.Add("Think", "homigrad-weapons", function()
		for i,wep in ipairs(hg.weapons) do
			if not IsValid(wep) or not wep.Step or (not IsValid(wep:GetOwner()) and wep:GetVelocity():Length() < 1) then continue end

			wep:Step()
		end
	end)
end

function SWEP:Step()
	self:CoreStep()
end

local CurTime = CurTime
if CLIENT then
	SWEP.particleEffect = nil

	local vecSmoke = Vector(255, 255, 255)
	function SWEP:MuzzleEffect(time_)
		local tr, pos, ang = self:GetTrace()
		local owner = self:GetOwner()

		local lastdmg = self.dmgStack
		local lastdmgMul = lastdmg / 100
		
		if time_ < 0.5 and self.SprayI == 0 then
			if not IsValid(self.particleEffect) then
				self.particleEffect = CreateParticleSystemNoEntity("smoke_trail_tfa", pos, ang)
				self.particleEffectCreateTime = CurTime()
			end
		end
		
		if IsValid(self.particleEffect) then
			self.particleEffect:SetControlPoint(0, pos)
			
			if self.particleEffectCreateTime + 2 < CurTime() then
				self.particleEffect:StopEmission()
			end

			if self.particleEffectCreateTime + 4 < CurTime() then
				self.particleEffect:StopEmissionAndDestroyImmediately()
				self.particleEffect = nil
			end

			if IsValid(owner) and owner:IsPlayer() and IsValid(owner:GetActiveWeapon()) and owner:GetActiveWeapon() ~= self and self.shouldntDrawHolstered then
				if IsValid(self.particleEffect) then
					self.particleEffect:StopEmission()
				end
			end
		end
	end
else
	function SWEP:MuzzleEffect(time)
	end
end

if SERVER then
	util.AddNetworkString("place_bipod")
	function SWEP:PlaceBipod(bipod, dir)
		net.Start("place_bipod")
		net.WriteEntity(self)
		net.WriteVector(bipod)
		net.WriteVector(dir)
		net.Broadcast()
		self.removebipodtime = CurTime() + 0.25
		self.bipodPlacement = bipod
		self.bipodDir = dir
	end

	function SWEP:RemoveBipod()
		net.Start("place_bipod")
		net.WriteEntity(self)
		net.Broadcast()
		self.bipodPlacement = nil
		self.bipodDir = nil
	end
else
	net.Receive("place_bipod", function()
		local self = net.ReadEntity()
		local pos, dir = net.ReadVector(), net.ReadVector()
		if pos:IsZero() or dir:IsZero() then
			self.bipodPlacement = nil
			self.bipodDir = nil
			return
		end

		self.bipodPlacement = pos
		self.bipodDir = dir
	end)
end

function SWEP:GunOverHead(height)
	local attheight = self:GetMuzzleAtt().Pos[3]
	local owner = self:GetOwner()
	return owner:GetAttachment(owner:LookupAttachment("eyes")).Pos[3] < (height or attheight)
end

function SWEP:CoreStep()
	local owner = self:GetOwner()
	local actwep = owner.GetActiveWeapon and owner:GetActiveWeapon() or nil
	local dtime = SysTime() - (self.dtimethink or SysTime())

	if SERVER and self.UseCustomWorldModel then
		self:ChangeGunPos()
		self:GetAdditionalValues()
	end--self:WorldModel_Transform() end
	
	if SERVER and ((self.cooldown_transform or 0) < CurTime()) then
		self.cooldown_transform = CurTime() + 0.25

		self:WorldModel_Transform()
	end

	if CLIENT then
		self.sprayAngles = Lerp(hg.lerpFrameTime2(0.18,dtime),self.sprayAngles or Angle(0,0,0),angle_zero)
	end

	if owner.suiciding and not hg.CanSuicide(owner) then owner.suiciding = false end

	--	if SERVER and self.UseCustomWorldModel then self:WorldModel_Transform() end
	if SERVER and (not IsValid(owner) or (IsValid(actwep) and self != actwep)) then return end

	if SERVER and not owner:IsNPC() and not owner.organism.canmove and IsValid(actwep) and self == actwep then
		self:RemoveFake()
		owner:DropWeapon()
		return
	end

	local time = CurTime()

	if CLIENT then
		local time2 = time - self:LastShootTime()

		self:MuzzleEffect(time2)
	end

	if SERVER or (CLIENT and not self.isdrawn) then self:GetTrace(true) end--cache

	if not IsValid(owner) or (IsValid(actwep) and self != actwep) then return end
	
	self:Step_HolsterDeploy(time)
	self:Step_Inspect(time)
	self:Step_Reload(time)
	self:ClearAnims()
	self:Animation(time)
	if self:IsClient() or SERVER then self:Step_Spray(time,dtime) end
	if self:IsClient() or SERVER then self:Step_SprayVel(dtime) end
	self.dtimethink = SysTime()
	self:ThinkAtt()

	if CLIENT then
		if self:IsZoom() then
			if not self.zoomsound then
				self:PlaySnd({"pwb2/weapons/p90/cloth3.wav",60,80,120},false,CHAN_AUTO)
				self.zoomsound = true
				if self:IsClient() then
					ViewPunch2(Angle(0,0,-3))
				end
			end
		else
			if self.zoomsound then
				self:PlaySnd({"pwb2/weapons/matebahomeprotection/mateba_cloth.wav",60,80,120},false,CHAN_AUTO)
				if self:IsClient() then
					ViewPunch2(Angle(0,0,3))
				end
			end
			self.zoomsound = nil
		end
	end

	if SERVER and self.bipodAvailable then
		local bipod, dir = self:CheckBipod()
		if bipod and not IsValid(owner.FakeRagdoll) and not self.bipodPlacement then self:PlaceBipod(bipod, dir) end
		local bipod, dir = self:CheckBipod(true)
		if ((self.removebipodtime or 0) < CurTime()) and self.bipodPlacement and (not self:CanUse() or owner:GetVelocity():Length() > 10 or self:GunOverHead(self.bipodPlacement[3]) or not bipod) then self:RemoveBipod() end
	else
		if self.bipodPlacement and self.bipodPlacement:IsZero() then
			self.bipodPlacement = nil
			self.bipodDir = nil
		end
	end
	
	if SERVER then self:DrawAttachments() end
end

if SERVER then hook.Add("UpdateAnimation", "fuckgmodok", function(ply) ply:RemoveGesture(ACT_GMOD_NOCLIP_LAYER) end) end
if CLIENT then
	local nilTbl = {}
	function SWEP:CustomAmmoDisplay()
		return nilTbl
	end
end


local vecZero = Vector(0, 0, 0)
local angZero = Angle(0, 0, 0)
local hullVec = Vector(2, 2, 2)

function SWEP:CheckBipod(nouse)
	local owner = self:GetOwner()
	if not IsValid(owner) or IsValid(owner.FakeRagdoll) then return end
	if SERVER and ((not self:KeyDown(IN_USE) and not nouse) or not self.bipodAvailable) then return end
	local tr, pos, ang = self:GetTrace()
	if (owner.fakecd or 0) > CurTime() then return end
	
	local tr = {}
	tr.start = pos - ang:Forward() * 30
	tr.endpos = tr.start - vector_up * 20
	tr.filter = {self,self:GetWeaponEntity(),owner}
	tr.mins = -hullVec
	tr.maxs = hullVec
	tr = util.TraceLine(tr)
	
	if CLIENT and developer:GetBool() and LocalPlayer():IsAdmin() then
		cam.Start3D()
			render.DrawLine(tr.StartPos,tr.HitPos,color_white)
		cam.End3D()
	end

	if CLIENT then return end

	local selfpos, selfang, pos, ang = self:WorldModel_Transform(true)
	if not selfpos then return end
	selfpos[3] = tr.HitPos[3]
	if selfpos[3] < (owner:EyePos()[3] - 32) then return end
	if tr.Hit then
		return selfpos + vector_up * 5, owner:GetAimVector()
	end
end

function SWEP:DoImpactEffect( tr, nDamageType )
	if CLIENT then return true end
	return false
end

local vecZero = Vector(0, 0, 0)
local angZero = Angle(0, 0, 0)

--local to head
SWEP.RHPos = Vector(7,-7,5)
SWEP.RHAng = Angle(0,0,90)
--local to rh
SWEP.LHPos = Vector(15,0,-4)
SWEP.LHAng = Angle(-110,-90,-90)

SWEP.RHPosOffset = Vector(0,0,0)
SWEP.LHPosOffset = Vector(0,0,0)

SWEP.RHAngOffset = Angle(0,0,0)
SWEP.LHAngOffset = Angle(0,0,0)

SWEP.AdditionalPos = Vector(0,0,0)
SWEP.AdditionalAng = Angle(0,0,0)

SWEP.desiredPos = Vector(0,0,0)
SWEP.desiredAng = Angle(0,0,0)

local funcNil = function() end

hg.postureFunctions2 = {
	[1] = function(self,ply)
		if self:IsZoom() then return end
		self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] - 4
		self.AdditionalPosPreLerp[1] = self.AdditionalPosPreLerp[1] - 4
		self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] + 1
	end,
	[2] = function(self,ply)
		self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] - 4
	end,
	[3] = function(self,ply)
		if self:IsZoom() then return end
		self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] - 6
		self.AdditionalPosPreLerp[1] = self.AdditionalPosPreLerp[1] - 7
		self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] + 5
	end,
	[4] = function(self,ply)
		if self:IsZoom() then return end
		if self:IsPistolHoldType() then 
			self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] - 7
			self.AdditionalPosPreLerp[1] = self.AdditionalPosPreLerp[1] - 3
			self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] + 1
		else
			self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] + 2 
			self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] - 4
			self.AdditionalPosPreLerp[1] = self.AdditionalPosPreLerp[1] + -5
		end
	end,
	[5] = function(self,ply)
		local add = (hg.GunPositions[ply] and hg.GunPositions[ply][2]) or 0
		self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] - 1 - add
	end,
	[6] = function(self,ply)
		if self:IsZoom() then return end
		if self:IsPistolHoldType() then 
			self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] + 10
			self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] + 3
		else
			self.AdditionalPosPreLerp[1] = self.AdditionalPosPreLerp[1] - 3
			self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] + 13
			self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] + 3
		end
	end,
}

SWEP.AdditionalPosPreLerp = Vector(0,0,0)
SWEP.AdditionalAngPreLerp = Angle(0,0,0)

SWEP.vecSuicidePist = Vector(-7,-7,4)
SWEP.angSuicidePist = Angle(40,100,80)
SWEP.vecSuicideRifle = Vector(4,-25,3)
SWEP.angSuicideRifle = Angle(15,100,90)

local function isCrouching(ply)
	return (hg.KeyDown(ply,IN_DUCK)) and ply:OnGround()
end

local angle_huy = Angle(0,0,0)

local host_timescale = game.GetTimeScale

SWEP.pitch = 0

function SWEP:GetAdditionalValues()
	local ply = self:GetOwner()
	if !IsValid(ply) or !ply:IsPlayer() then return end

	self.AdditionalPosPreLerp:Zero()
	self.AdditionalAngPreLerp:Zero()
	--self.AdditionalAng:Zero()
	local add = (hg.GunPositions[ply] and hg.GunPositions[ply][3]) or 0
	self.AdditionalPosPreLerp[2] = self:IsZoom() and 1.5 - add or 0
	local animpos = self.lerpaddcloseanim
	if not ply:InVehicle() then
		self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] + animpos * 5
		self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] + animpos * -10
		self.AdditionalPosPreLerp[1] = self.AdditionalPosPreLerp[1] + animpos * -self.closeanimdis
	end
	--self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] - ((ply.lean or 0) * 2)
	
	local val = math.Clamp((self.deploy and ((self.deploy - CurTime()) * 10) or self.holster and (((self.CooldownDeploy / self.Ergonomics) - (self.holster - CurTime())) * 10) or 0) / (self.CooldownDeploy / self.Ergonomics),0,10)
	self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] - val * 1
	self.AdditionalPosPreLerp[1] = self.AdditionalPosPreLerp[1] - val * 2 * (self:IsPistolHoldType() and 0.5 or 0.75)
	
	local posture = ((animpos < 0.2 and self:IsSprinting()) or animpos > (self:IsPistolHoldType() and 0.5 or 0.2)) and (self:IsPistolHoldType() and 3 or 4) or ply.posture
	local func = hg.postureFunctions2[(self:IsSprinting() or self.lerpaddcloseanim > (self:IsPistolHoldType() and 0.29 or 0.2)) and ((ply.posture == 4 and 4) or (ply.posture == 3 and 3) or (self:IsPistolHoldType() and 3 or 4)) or ply.posture] or funcNil

	if not self.reload and not self.inspect then
		func(self,ply)
	end

	if ply.suiciding then
		if self:IsPistolHoldType() then
			self.AdditionalPosPreLerp:Set(self.vecSuicidePist)
			self.AdditionalAngPreLerp:Set(self.angSuicidePist)
		else
			self.AdditionalPosPreLerp:Set(self.vecSuicideRifle)
			self.AdditionalAngPreLerp:Set(self.angSuicideRifle)
			--self.AdditionalAngPreLerp:Set(Angle(0,180,0))
		end
	end

	local dtime = SysTime() - (self.timetick2 or SysTime()) --/ host_timescale:GetFloat()
	local pranktime = CurTime() / 2
	self.walkinglerp = Lerp(hg.lerpFrameTime2(0.1,dtime),self.walkinglerp or 0,ply:InVehicle() and 0 or hg.GetCurrentCharacter(ply):GetVelocity():LengthSqr())
	self.huytime = self.huytime or 0
	local walk = math.Clamp(self.walkinglerp / 10000,0,1)
	
	self.huytime = self.huytime + walk * dtime * 8 * host_timescale()
	if self:IsSprinting() then
		walk = walk * 2
	end

	local huy = self.huytime
	
	local x,y = math.cos(huy) * math.sin(huy) * walk * 1,math.sin(huy) * walk * 1
	self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] - walk
	self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] - x * 0.5
	self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] - y * 0.5

	if CLIENT and self:IsLocal2() then
		angle_huy[1] = x / 300
		angle_huy[2] = y / 300
		ViewPunch2(angle_huy)
	end
	
	self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] + math.cos(pranktime) * math.sin(pranktime - 2) * math.cos(pranktime + 1) * 0.5
	self.AdditionalPosPreLerp[3] = self.AdditionalPosPreLerp[3] + math.sin(pranktime) * math.sin(pranktime) * math.cos(pranktime + 1) * 0.5

	--self.AdditionalPosPreLerp[2] = self.AdditionalPosPreLerp[2] + (ply.Crouching and isCrouching(ply) and -1 or 0)

	local skillissue = ply.organism and ply.organism.recoilmul or 1

	local speed_add = math.Clamp(1 / skillissue,0.5,1.5)

	self.pitch = Lerp(hg.lerpFrameTime2(0.1,dtime), self.pitch, (ply.suiciding or (self:IsSprinting() or ((ply.posture == 4 or ply.posture == 3) and not self:IsZoom()))) and 1 or 0)

	self.AdditionalPos = Lerp(hg.lerpFrameTime2(0.1,dtime) * self.Ergonomics * speed_add,self.AdditionalPos,self.AdditionalPosPreLerp)
	local animpos = self:GetAnimShoot2(0.07, true) * 0.07
	
	animpos = animpos * (self:IsPistolHoldType() and 1 or 0.1) * (((ply.posture == 1 and not self:IsZoom()) or ply.posture == 7 or ply.posture == 8) and 3 or 1)
	self.AdditionalPos[1] = self.AdditionalPos[1] + animpos * -math.min(self.Primary.Force / 40,3) * 5 * (self.NumBullet or 1) * (self.animposmul or 1)
	self.AdditionalPos[2] = self.AdditionalPos[2] + animpos * -math.min(self.Primary.Force / 40,3) * 2 * (self.NumBullet or 1) * (self.animposmul or 1)
	
	self.AdditionalAng = Lerp(hg.lerpFrameTime2(0.1,dtime) * self.Ergonomics * speed_add,self.AdditionalAng,self.AdditionalAngPreLerp + self.weaponAng)
	
	self.timetick2 = SysTime()
end

function SWEP:AnimHands() end

vector_nasral = Vector(0,0,0)

local veccopy = Vector(0,0,0)
local addvec = Vector(0,0,-0.2)
function SWEP:SetHandPos(noset)
	self.addvec = self.addvec or Vector(0,0,0)
	self.rhandik = self.setrhik
	self.lhandik = self.setlhik
	
	local ply = self:GetOwner()

    if not IsValid(ply) or not IsValid(self.worldModel) then return end
    if not ply.shouldTransmit or ply.NotSeen then return end

	local ent = hg.GetCurrentCharacter(ply)
	if ent ~= ply and not (self:KeyDown(IN_USE) or (ply:GetNetVar("lastFake",0) - CurTime() + 5 > 0)) then return end
	--ply:SetIK(false)
	
	if not IsValid(ply) or not ply:IsPlayer() then return end
	
	local rh,lh = ply:LookupBone("ValveBiped.Bip01_R_Hand"), ply:LookupBone("ValveBiped.Bip01_L_Hand")
	local torso = ply:LookupBone("ValveBiped.Bip01_R_Hand")

	local rhmat = ent:GetBoneMatrix(rh)
	local lhmat = ent:GetBoneMatrix(lh)
	
	if not rhmat or not lhmat then return end
	
	local tr, _, headmat = hg.eyeTrace(ply,60,ent)--hg.torsoTrace(ply,60,ent)

	local wepang = ply:GetAimVector():Angle()
	wepang:Normalize()
	wepang[1] = math.ApproachAngle(wepang[1], 0, wepang[1] * self.pitch)

	local ang = wepang

	ang[3] = ang[3] + (ply:EyeAngles()[3]) + 90
	--ang[3] = headmat:GetAngles()[3] + 90
	--self:GetAdditionalValues()
	
	local pos = tr.StartPos - tr.Normal:Angle():Up() * 1
	
	local vec,lang = LocalToWorld(self.RHPos+self.AdditionalPos,self.AdditionalAng,pos,ang)
	
	if self.bipodPlacement then
		vec = self.bipodPlacement
		vec = LocalToWorld(-self.WorldPos,angZero,vec,ang)
	end

	local x,y,z = hg.GunPositions[ply] and hg.GunPositions[ply][1], hg.GunPositions[ply] and hg.GunPositions[ply][2], hg.GunPositions[ply] and hg.GunPositions[ply][3]
	veccopy.x = not ply.suiciding and x or 0
	veccopy.x = ((ply.posture == 7 or ply.posture == 8) and not self.reload and not ply.suiciding) and 1 or veccopy.x
	veccopy.y = not ply.suiciding and -(y or 0) or 0
	veccopy.z = not ply.suiciding and z or 0

	local angnorm = ang:Forward():Angle()
	
	local vec,_ = LocalToWorld(veccopy,angZero,vec,angnorm)
	local _,ang = LocalToWorld(vector_origin,self.AdditionalAng,vector_origin,ang)
	local vec2,lang2 = LocalToWorld(self.LHPos+(ThatPlyIsFemale(ply) and addvec or vecZero),self.LHAng,vec,ang+(self.weaponAngLerp or angZero))
	
	if self:HasAttachment("grip") and not self.reload and not ply.suiciding then
		local model = self:GetAttachmentModel("grip")
		
		local inf = self:GetAttachmentInfo("grip")
		if inf and inf.LHandPos and IsValid(model) then
			local infpos,infang = inf.LHandPos,inf.LHandAng
			vec2,lang2 = LocalToWorld(infpos,infang,model:GetPos(),model:GetAngles())
		end
	end

	lang:Add(self.weaponAngLerp or angZero)
	local rhmat,lhmat = ent:GetBoneMatrix(rh),ent:GetBoneMatrix(lh)

	local _,lang = LocalToWorld(vector_origin,self.RHAng,vector_origin,lang)
	local vec,ang = LocalToWorld(self.RHPosOffset,self.RHAngOffset,vec,lang)
	local vec2,lang2 = LocalToWorld(self.LHPosOffset,self.LHAngOffset,vec2,lang2)

	vec.x = math.Clamp(vec.x, pos.x - 38, pos.x + 38) -- clamping if something gone wrong so no stretching (or animator is fleshy)
	vec.y = math.Clamp(vec.y, pos.y - 38, pos.y + 38)
	vec.z = math.Clamp(vec.z, pos.z - 38, pos.z + 38)
	
	local torso = ply:LookupBone("ValveBiped.Bip01_Spine1")
	local tmat = ent:GetBoneMatrix(torso)
	
	local ang2 = tmat:GetAngles():Forward()
	local dot = ang2:Dot(wepang:Forward())
	dot = dot < -0.5 and dot + 0.5 or 0
	dot = dot * 2
	vec:Add(wepang:Forward() * dot * -10)
	vec2:Add(wepang:Forward() * dot * -10)

	rhmat:SetTranslation(vec)
	rhmat:SetAngles(ang)

	vec2.x = math.Clamp(vec2.x, pos.x - 38, pos.x + 38) -- clamping if something gone wrong so no stretching (or animator is fleshy)
	vec2.y = math.Clamp(vec2.y, pos.y - 38, pos.y + 38)
	vec2.z = math.Clamp(vec2.z, pos.z - 38, pos.z + 38)

	lhmat:SetTranslation(vec2)
	lhmat:SetAngles(lang2)

	if IsValid(self:GetWeaponEntity()) then
		self:AnimHands()
	end

	if hg.CanUseLeftHand(ply) and self.attachments then
		local hold = self:IsPistolHoldType() and "pistol_hold2" or "ak_hold"
		hold = self.attachments.grip and #self.attachments.grip ~= 0 and hg.attachments.grip[self.attachments.grip[1]].hold or hold
		
		hg.set_hold(ent, hold)
	end

	hg.set_holdrh(ent, self:IsPistolHoldType() and "pistol_hold2" or "ak_hold")
	
	self:AnimationRender()
	self:AnimHoldPost(self:GetWeaponEntity())

	hg.bone_apply_matrix(ent, rh, rhmat)
	if ( hg.CanUseLeftHand(ply) and self.lhandik ) or self.reload then
		hg.bone_apply_matrix(ent, lh, lhmat)
	end

	return rhmat, lhmat
end

function SWEP:GetTracerOrigin()
	return select(2,self:GetTrace())
end