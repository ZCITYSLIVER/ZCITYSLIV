-- "addons\\homigrad-weapons\\lua\\weapons\\homigrad_base\\sh_worldmodel.lua"

AddCSLuaFile()
--
hook.Add("PhysgunPickup", "homigrad-weapons", function(ply, ent) if ent:GetNWBool("nophys") then return false end end)
SWEP.WorldPos = Vector(13, -0.3, 3.4)
SWEP.WorldAng = Angle(5, 0, 180)
SWEP.UseCustomWorldModel = false

function SWEP:SetupDataTables()

end

if SERVER then
	util.AddNetworkString("give-me-guns")

	--[[local entityMeta = FindMetaTable("Entity")
	function entityMeta:SyncArmor()
		if self.armors then
			self:SetNetVar("Armor", self.armors)
		end
	end]]-- ОНО В ИНИТЕ БРОНИ

	hook.Add("PlayerSync", "sync_weapons", function(ply)
		--hg.SyncWeapons(ply)

		timer.Simple(1, function()
			if ply.SyncVars then ply:SyncVars() end
		end)
	end)
end

SWEP.weaponAng = Angle(0, 0, 0)
local angZero = Angle(0, 0, 0)
local math_max, math_Clamp = math.max, math.Clamp
function SWEP:GetAnimPos_Shoot2(time, timeSpan)
	local animpos = math.max(time - SysTime() + timeSpan,0) / timeSpan

	return animpos
end

function SWEP:GetAnimShoot2(time,force)
	if self.IsPistolHoldType and not self:IsPistolHoldType() and not force then return 0 end
	
	local animpos = self:GetAnimPos_Shoot2(self.lastShoot or 0, time * (math.max((self.weight or 1) - 1,0.1) * 5 + 1))
	--/ (FrameTime() / engine.TickInterval())
	animpos = 1.5 * animpos ^ 3 - 1 * animpos ^ 2
	
	if animpos > 0 then
		--animpos = animpos * math.max(self.Primary.Force / 40, 0) / (math.max((self.weight or 1) - 1,0.1) * 5 + 1) * (self.NumBullet or 1)
		--animpos = animpos * (self.animposmul or 1)
	end
	
	return animpos
end

local angZero, vecZero = Angle(0, 0, 0), Vector(0, 0, 0) -- а неиспользуется потому что глуалин подчеркнул это
local angPosture3 = Angle(10, 45, -10)
local angPosture4 = Angle(30, -30, -30)
local angPosture5 = Angle(5, 5, 0)
local angPosture6 = Angle(30, 20, 0)
local angPosture7 = Angle(5, -60, 0)
local angPosture8 = Angle(40, 10, -30)
local angSuicide = Angle(-35, 120, 0)
local angReload = Angle(-20, 10, 0)

SWEP.AllowedInspect = true

if SERVER then
	util.AddNetworkString("hg_viewgun")
	concommand.Add("hg_inspect", function(ply, cmd, args)
		local gun = ply:GetActiveWeapon()
		if not IsValid(gun) or not gun or not gun.AllowedInspect then return end
		gun.inspect = CurTime() + 5
		net.Start("hg_viewgun")
		net.WriteEntity(gun)
		net.WriteFloat(gun.inspect)
		net.Broadcast()
	end)
else
	net.Receive("hg_viewgun", function() 
		local ent = net.ReadEntity()
		local time = net.ReadFloat()
		ent.inspect = time
		ent.hudinspect = time
	end)
	local function inspect() RunConsoleCommand("hg_inspect") end
	hook.Add("radialOptions", "!Mainus", function()
		local lply = LocalPlayer()
		local gun = lply:GetActiveWeapon()
		if not IsValid(gun) or not gun or not gun.AllowedInspect then return end
		local tbl = {inspect, "Inspect"}
		hg.radialOptions[#hg.radialOptions + 1] = tbl
	end)
end

local funcNil = function() end

hg.postureFuncWorldModel = {
	[1] = function(self,ply)
	end,
	[2] = function(self,ply)
		self.weaponAng[3] = self.weaponAng[3] - 15
	end,
	[3] = function(self,ply)
		if self:IsZoom() then return end
		self.weaponAng:Add(angPosture3)
	end,
	[4] = function(self,ply)
		if self:IsZoom() then return end
		self.weaponAng:Add(self:IsPistolHoldType() and angPosture7 or (ply:IsFlagSet(FL_ANIMDUCKING) and angPosture8 or angPosture4))
		--self.weaponAng[2] = self.weaponAng[2] - 12
	end,
	[5] = function(self,ply)
		self.weaponAng[3] = self.weaponAng[3] - (self:IsZoom() and 0 or 20)
	end,
	[6] = function(self,ply)
		if self:IsZoom() then return end
		self.weaponAng[3] = self.weaponAng[3] - 55
	end,
}
SWEP.lerpaddcloseanim = 0
SWEP.closeanimdis = 40
SWEP.WepAngOffset = Angle(0,0,0)
SWEP.weaponAngLerp = Angle(0,0,0)
local tickInterval = engine.TickInterval -- gde
local hook_Run = hook.Run
function SWEP:ChangeGunPos()
	local ply = self:GetOwner()
	if not IsValid(ply) then return end
	if not ply:IsPlayer() then return end
	self.setrhik = true 
	self.setlhik = not self:IsPistolHoldType() and true or (not ply.suiciding)

	if ply.suiciding then self.weaponAngLerp:Zero() self.weaponAng:Zero() return end

	local fakeRagdoll = IsValid(ply.FakeRagdoll)

	self.weaponAng[1] = 0
	self.weaponAng[2] = 0
	self.weaponAng[3] = 0
	
	if ply.viewingGun and ply.viewingGun > CurTime() then
		self.weaponAng:Add(Angle(math.sin(ply.viewingGun - CurTime()) * -5, math.sin(ply.viewingGun - CurTime()) * -5, math.cos(ply.viewingGun+1.5 - CurTime()) * 30))
		ply.viewingGun = not (self:KeyDown(IN_ATTACK2) or self:KeyDown(IN_ATTACK)) and ply.viewingGun or nil
	end

	if self.GetAnimPos_Draw and CLIENT then
		local animpos = math.Clamp(self:GetAnimPos_Draw(CurTime()),0,1)
		local sin = 1 - animpos
		if sin >= 0.5 then
			sin = 1 - sin
		else
			sin = sin * 1
		end
		sin = sin * 2
		sin = math.ease.InOutSine(sin)
		self.weaponAng[1] = self.weaponAng[1] - sin * 5
		--self.weaponAng[2] = self.weaponAng[2] + sin * 5
		self.weaponAng[3] = self.weaponAng[3] + sin * -25
	end

	local func = hg.postureFuncWorldModel[(self:IsSprinting() or self.lerpaddcloseanim > (self:IsPistolHoldType() and 0.29 or 0.2)) and ((ply.posture == 4 and 4) or (ply.posture == 3 and 3) or (self:IsPistolHoldType() and 3 or 4)) or ply.posture] or funcNil
	
	if not self.reload and not self.inspect then
		func(self,ply)
	end

	if (ply.posture == 7 or ply.posture == 8) and not self.reload and not ply.suiciding then
		--gangsta mode!!!
		if ply.posture == 7 then
			self.weaponAng[3] = self.weaponAng[3] - (not self:IsZoom() and 60 or 0)
		else
			self.weaponAng[3] = self.weaponAng[3] - (not self:IsZoom() and 10 or 0)
		end
		self.setlhik = false
	end

	self.weaponAng[1] = self.weaponAng[1] + math.Clamp(((self.deploy and ((self.deploy - CurTime())) or self.holster and (((self.CooldownDeploy / self.Ergonomics) - (self.holster - CurTime()))) or 0) / (self.CooldownDeploy / self.Ergonomics)) * 60,0,60)
	self.weaponAng[2] = self.weaponAng[2] - math.Clamp(((self.deploy and ((self.deploy - CurTime())) or self.holster and (((self.CooldownDeploy / self.Ergonomics) - (self.holster - CurTime()))) or 0) / (self.CooldownDeploy / self.Ergonomics)) * 60,0,60)

	local _,anga = LocalToWorld(vecZero,self.WepAngOffset,vecZero,self.weaponAng)
	
	self.weaponAng = anga

	--self.weaponAng:Add((self.reload and self.reload - 0.5 > CurTime()) and not fakeRagdoll and angReload or angZero)
	local animpos = self:GetAnimShoot2(0.1,self.podkid or self:IsPistolHoldType())
	local dtime = SysTime() - (self.timetick or SysTime())
	
	self.weaponAng[2] = self.weaponAng[2] - animpos * -15 * (self.podkid or 1)
	--self.weaponAngLerp = Lerp(hg.lerpFrameTime2(0.1,dtime) * self.Ergonomics, self.weaponAngLerp or Angle(0, 0, 0), self.weaponAng)
	
	self.timetick = SysTime()
end

function SWEP:DrawPost() end

--[[ 
	self.WepPosOffset
	self.WepAngOffset
--]]

local angcopy = Angle(0,0,0)
local veccopy = Vector(0,0,0)
local addvec2 = Vector(0,-1,0)
local angleZero = Angle(0,0,0)
local vectorZero = Angle(0,0,0)

function SWEP:PosAngChanges(ply,desiredPos,desiredAng,bNoAdditional)
	desiredPos = desiredPos or vectorZero
	desiredAng = desiredAng or angleZero
    if ply:IsNPC() then
        return desiredPos,desiredAng
    end

	self:GetAdditionalValues()

    local _
	local ent = hg.GetCurrentCharacter(ply)
    if not (ent ~= ply and not (self:KeyDown(IN_USE) or (ply:GetNetVar("lastFake",0) - CurTime() + 5 > 0))) then
		local tr = hg.eyeTrace(ply,60,ent)--hg.torsoTrace(ply,60,ent)
		local wepang = ply:GetAimVector():Angle()
		wepang:Normalize()

		wepang[1] = math.ApproachAngle(wepang[1], 0, wepang[1] * self.pitch)

		local ang = wepang
		ang[3] = ang[3] + (ply:EyeAngles()[3]) + 90
		
        desiredPos,desiredAng = LocalToWorld(self.RHPos+(bNoAdditional and vector_origin or self.AdditionalPos),bNoAdditional and angle_zero or self.AdditionalAng,tr.StartPos - tr.Normal:Angle():Up() * 1,ang)

		if self.bipodPlacement then
			desiredPos = self.bipodPlacement
			desiredPos = LocalToWorld(-self.WorldPos,angZero,desiredPos,ang)
		end

		desiredAng[3] = desiredAng[3] + 90
		local x,y,z = hg.GunPositions[ply] and hg.GunPositions[ply][1], hg.GunPositions[ply] and hg.GunPositions[ply][2], hg.GunPositions[ply] and hg.GunPositions[ply][3]
		veccopy.x = not ply.suiciding and x or 0
		veccopy.x = ((ply.posture == 7 or ply.posture == 8) and not self.reload and not ply.suiciding) and 1 or veccopy.x
		veccopy.y = not ply.suiciding and -(y or 0) or 0
		veccopy.z = not ply.suiciding and z or 0
		
		local angnorm = ang:Forward():Angle()
		local torso = ply:LookupBone("ValveBiped.Bip01_Spine1")
		local tmat = ent:GetBoneMatrix(torso)
		
		local ang2 = tmat:GetAngles():Forward()
		local dot = ang2:Dot(wepang:Forward())
		dot = dot < -0.5 and dot + 0.5 or 0
		dot = dot * 2
		desiredPos:Add(wepang:Forward() * dot * -10)

		desiredPos,_ = LocalToWorld(veccopy,angZero,desiredPos,angnorm)
	end
	desiredPos:Add(desiredAng:Up() * 1)
    return desiredPos,desiredAng
end

if SERVER then return end

local function remove(self, model)
    model:Remove()
end

local function DrawWorldModel(self)
	if not IsValid(self) or not self.WorldModel_Transform then return end
	local owner = self:GetOwner()
	
	if IsValid(owner) and not owner.shouldTransmit or owner.NotSeen then
		return
	end
	
	local willdraw = false

	local localdraw = self:IsLocal2() and (owner:GetActiveWeapon() == self)

	self:DrawPost()
	
	if not localdraw then
		if IsValid(owner) and (owner.GetActiveWeapon and (owner:GetActiveWeapon() ~= self) or owner:IsRagdoll()) then
			if not self.shouldntDrawHolstered then
				self:WorldModel_Transform_Holstered()
				willdraw = true
			else
				if IsValid(self.worldModel) then
					self.worldModel:Remove()
				end
				self:ClearAttModels()
				return
			end
		elseif owner.GetActiveWeapon and owner:GetActiveWeapon() == self then
			self:WorldModel_Transform()
			willdraw = true
		end
	else
		willdraw = true
	end

	self.isdrawn = false
	
	if IsValid(self.worldModel) and willdraw then
		self.worldModel:DrawModel()
	end
	
	if willdraw then
		self:DrawAttachments()
	end
end

function SWEP:CreateWorldModel()
	local model = ClientsideModel(self.WorldModel)
	
	--model:SetNoDraw(true)
	model:SetOwner(self)
	model:SetRenderOrigin(self:GetPos())
	model:SetPos(self:GetPos())
	--debug.Trace()
	model.RenderOverride = function(self)
		local model = self
		local self = self:GetOwner()
		if not IsValid(self) then return end
		model:SetPos(self:GetPos())
		--DrawWorldModel(self)
	end
	
	for i = 0, 6 do
		model:SetBodygroup(i, self:GetBodygroup(i))
	end

	self:CallOnRemove("clientsidemodel", function() model:Remove() end)
	model:CallOnRemove("removeAtts", function() hg.ClearAttModels(model) end)
	self.worldModel = model

	--self:WorldModel_Transform(true)

	return model
end

local vecZero = Vector(0, 0, 0)
local angZero = Angle(0, 0, 0)
local math_max = math.max

hook.Add("NotifyShouldTransmit", "PvsThingy", function(ent, shouldTransmit)
	ent.shouldTransmit = shouldTransmit
end)

function SWEP:WorldModel_Transform(bNoApply,bNoAdditional,model)
	local model, owner = model or self.worldModel, self:GetOwner()
	if not IsValid(model) then model = self:CreateWorldModel() end

	if IsValid(owner) then
		local ent = hg.GetCurrentCharacter(owner) or owner
		
		local RHand = ent:LookupBone("ValveBiped.Bip01_R_Hand")
		
		if not RHand then return end
		
		--ent:SetupBones()

		local matrixR = ent:GetBoneMatrix(RHand)
		
		if not matrixR then return end
		
		local aimvec = ent:IsNPC() and matrixR:GetAngles() or owner:GetAimVector():Angle()

		self:ChangeGunPos()
		
		local matrixRAngRot = matrixR:GetAngles()
		matrixRAngRot:RotateAroundAxis(matrixRAngRot:Forward(),180)
		local lerp = self:KeyDown(IN_ATTACK2) and 1 or 1
		local _,ang = WorldToLocal(vecZero,matrixRAngRot,vecZero,aimvec)
		ang = ang * lerp
		local _,ang = LocalToWorld(vecZero,ang,vecZero,aimvec)
		ang[3] = matrixRAngRot[3]
		local desiredAng = ((ent~=owner)) and ang or aimvec
		desiredAng[3] = desiredAng[3] + (owner:EyeAngles()[3])
		desiredAng:RotateAroundAxis(desiredAng:Forward(),ent:IsNPC() and 0 or 180)
		local desiredPos = matrixR:GetTranslation()
		
		if hg.ShouldTPIK(owner) then
			desiredPos,desiredAng = self:PosAngChanges(owner,desiredPos,desiredAng,bNoAdditional)
		end

		if ent == owner then
			if not owner.suiciding then
				desiredAng:Add(self.weaponAngLerp or angZero)
			end
		elseif ent~=owner then
			desiredAng:Add(self.weaponAngLerp or angZero)
			desiredPos:Add(matrixRAngRot:Up() * 0)
		end

		local newPos,newAng = LocalToWorld(self.WorldPos,self.WorldAng,desiredPos,desiredAng)
		newAng:RotateAroundAxis(newAng:Forward(),180)
		
		if bNoApply then
			return newPos, newAng, desiredPos, desiredAng
		end

		self.desiredPos,self.desiredAng = newPos,newAng
		
		model:SetPos(newPos)
		model:SetAngles(newAng)
		model:SetRenderOrigin(newPos)
		model:SetRenderAngles(newAng)
	else
		model:SetRenderOrigin(self:GetPos())
		model:SetRenderAngles(self:GetAngles())
		model:SetPos(self:GetPos())
		model:SetAngles(self:GetAngles())
	end
end

SWEP.holsteredBone = "ValveBiped.Bip01_Spine2"
SWEP.holsteredPos = Vector(4, 8, -4)
SWEP.holsteredAng = Angle(210, 0, 180)
function SWEP:WorldModel_Transform_Holstered()
	local model, owner = self.worldModel, self:GetOwner()
	if not IsValid(model) then model = self:CreateWorldModel() end
	owner = hg.GetCurrentCharacter(owner)
	if not IsValid(owner) then
		model:SetNoDraw(true)
		return
	end
	
	if IsValid(owner) then
		local matrix = owner:GetBoneMatrix(owner:LookupBone(self.holsteredBone))
		if not matrix then return end
		local localPos, localAng = self.holsteredPos, self.holsteredAng
		
		local newPos, newAng = LocalToWorld(localPos, localAng, matrix:GetTranslation(), matrix:GetAngles())
		
		local newPos, newAng = LocalToWorld(self.WorldPos, self.WorldAng, newPos, newAng)
		
		model:SetRenderOrigin(newPos)
		model:SetRenderAngles(newAng)
		model:SetPos(newPos)
		model:SetAngles(newAng)
		model:SetRenderOrigin()
		model:SetRenderAngles()
	else
		model:SetRenderOrigin(self:GetPos())
		model:SetRenderAngles(self:GetAngles())
	end
end

function SWEP:ClearAttModels()
	if self.modelAtt then
		for atta, model in pairs(self.modelAtt) do
			if not atta or not IsValid(self.modelAtt[atta]) then continue end
			if IsValid(model) then model:Remove() end
			self.modelAtt[atta] = nil
		end
	end
end

function hg.ClearAttModels(model)
	if model.modelAtt then
		for atta, modela in pairs(model.modelAtt) do
			if not atta or not IsValid(modela) then continue end
			if IsValid(modela) then modela:Remove() end
			model.modelAtt[atta] = nil
		end
		model.modelAtt = nil
	end
end

local function removeFlashlights(self)
	if self.flashlight and self.flashlight:IsValid() then
		self.flashlight:Remove()
		self.flashlight = nil
	end
end

function SWEP:DrawWorldModel()
	local owner = self:GetOwner()
	if IsValid(owner) and owner:IsNPC() then
		if owner.shouldTransmit and not owner.NotSeen then
			self:WorldModel_Transform(nil,nil,self)
		else
			self:SetRenderOrigin()
			self:SetRenderAngles()
		end

		self:DrawModel()
	end

	if (not IsValid(owner)) or (not IsValid(owner:GetActiveWeapon()) or owner:GetActiveWeapon() ~= self) then
		self:SetupBones()
		self:DrawPost()
		self:DrawAttachments()
		self:SetRenderOrigin()
		self:SetRenderAngles()
		self:DrawModel()
		if IsValid(self.worldModel) then
			self.worldModel:SetRenderOrigin(self:GetPos())
			self.worldModel:SetRenderAngles(self:GetAngles())
			self.worldModel:SetPos(self:GetPos())
			self.worldModel:SetAngles(self:GetAngles())
		end
	end
end

hook.Add("DrawPlayerRagdoll", "huyCock", function(ent,owner)
	local wep = owner.GetActiveWeapon and owner:GetActiveWeapon()
	
	if IsValid(wep) then
		DrawWorldModel(wep)
	end

	if owner.GetWeapons then
		for i,wep2 in ipairs(owner:GetWeapons()) do
			if ishgweapon(wep2) and wep2 ~= wep then
				DrawWorldModel(wep2)
			end
		end
	end
end)

hook.Add("DrawPlayerRagdoll","drawweapons",function(ent,owner)
	local inv = ent:GetNetVar("Inventory",{})
	if ent == owner and not owner:IsPlayer() and inv["Weapons"] then
		if not ent.shouldTransmit then return end
		if ent.NotSeen then return end

		for i,tbl in pairs(inv["Weapons"]) do
			if not istable(tbl) then continue end
			tbl["render"] = istable(tbl["render"]) and tbl["render"] or weapons.Get(i)
			if not tbl["render"] then continue end
			
			if tbl["render"].shouldntDrawHolstered then continue end
			--print(tbl[3].WorldModel)
			
			local wep = istable(tbl["render"]) and tbl["render"] or weapons.Get(i)
			if not wep.WorldModel then continue end
			--if not wep.ishgweapon then continue end
			if not IsValid(tbl.weapon) then
				tbl.weapon = ClientsideModel(wep.WorldModel)
				local model = tbl.weapon
				model:SetNoDraw(true)
				model:SetOwner(ent)
				ent:CallOnRemove("removehuysususus",function()
					if IsValid(model) then
						model:Remove()
					end
				end)

				function wep:Clip1()
					return tbl[1]
				end

				tbl.weapon.attachments = tbl[2]

				table.Inherit(tbl.weapon,wep)
				tbl.weapon.worldModel = model
			else
				DrawWorldModel(tbl.weapon)
			end
		end

	end
end)

hook.Add("DrawPlayerRagdoll", "asdhujy_huy", function(ent,ply)
	--[[if not IsValid(ply.FakeRagdoll) and ply:IsPlayer() and ent == ply then
		local wep = ply:GetActiveWeapon()
		if IsValid(wep) and ishgweapon(wep) then
			DrawWorldModel(wep)
		end
		for i,wep2 in ipairs(ply:GetWeapons()) do
			if ishgweapon(wep2) and wep2 ~= wep then
				DrawWorldModel(wep2)
			end
		end
	end--]]
end)

hook.Add("PostDrawTranslucentRenderables", "huyCock333", function()
	hg.weapons = hg.weapons or {}
	for i,self in ipairs(hg.weapons) do
		if not IsValid(self) then table.remove(hg.weapons,i) continue end
		if IsValid(self:GetOwner()) and self:GetOwner():GetActiveWeapon() ~= self and self.shouldntDrawHolstered then removeFlashlights(self) continue end
		if not self.attachments then continue end
		if not self.lasertoggle then removeFlashlights(self) end
		if not table.IsEmpty(self.attachments.underbarrel) and string.find(self.attachments.underbarrel[1], "laser") or self.laser then self:DrawLaser() end
	end
end)

function SWEP:ShouldDrawViewModel()
	return false
end


