-- "addons\\homigrad-weapons\\lua\\weapons\\homigrad_base\\cl_optics.lua"

AddCSLuaFile()
--
local delta = 0

hook.Add("HG.InputMouseApply", "ChangeZoom", function(tbl)
	local ply = LocalPlayer()

	delta = Lerp(FrameTime() * 5, delta, 0)

	if IsAiming(ply) and not ply.Fake then
		delta = input.WasMousePressed(MOUSE_WHEEL_UP) and delta + 1 * (FrameTime() / engine.TickInterval()) or input.WasMousePressed(MOUSE_WHEEL_DOWN) and delta - 1 * (FrameTime() / engine.TickInterval()) or delta
		tbl.cmd:SetMouseWheel(0)
		if LocalPlayer():KeyDown(IN_WALK) then
			delta = delta - tbl.y / 24
			tbl.y = 0
		end
	end
end)

function IsAiming(ply)
	local wep = ply:GetActiveWeapon()

	return IsValid(wep) and ishgweapon(wep) and ply:KeyDown(IN_ATTACK2)
end

local rtsize = 512
local rtmat = GetRenderTarget("huy-glass", rtsize, rtsize, false)
local mat = Material("huy-glass")
local mat2 = Material("huy-glass")
SWEP.scopemat = Material("decals/scope.png")
SWEP.perekrestie = Material("decals/perekrestie3.png")
local limit = 1
local vecVel = Vector(0, 0, 0)
local angZero = Angle(0, 0, 0)
local vecZero = Vector(0, 0, 0)
SWEP.localScopePos = Vector(-21, 3.95, -0.2)
SWEP.scope_blackout = 400
SWEP.maxzoom = 3.5
SWEP.rot = 37
SWEP.FOVMin = 3.5
SWEP.FOVMax = 10
SWEP.blackoutsize = 2500
function surface.DrawTexturedRectRotatedHuy(x, y, w, h, rot, offsetX, offsetY, rotHuy)
	rotHuy = rotHuy or 0
	local newX = x + offsetX * math.sin(math.rad(rot))
	local newY = x + offsetX * math.cos(math.rad(rot))
	local newX = newX + offsetY * math.cos(math.rad(rot))
	local newY = newY - offsetY * math.sin(math.rad(rot))
	surface.DrawTexturedRectRotated(newX, newY, w, h, rot + rotHuy)
end

function surface.DrawTexturedRectRotatedPoint(x, y, w, h, rot, x0, y0)
	local c = math.cos(math.rad(rot))
	local s = math.sin(math.rad(rot))
	local newx = y0 * s - x0 * c
	local newy = y0 * c + x0 * s
	surface.DrawTexturedRectRotated(x + newx, y + newy, w, h, rot)
end

local addmat_r = Material("CA/add_r")
local addmat_g = Material("CA/add_g")
local addmat_b = Material("CA/add_b")
local vgbm = Material("vgui/black")
local function DrawCA(rx, gx, bx, ry, gy, by, mater)
	render.UpdateScreenEffectTexture()
	addmat_r:SetTexture("$basetexture", mater)
	addmat_g:SetTexture("$basetexture", mater)
	addmat_b:SetTexture("$basetexture", mater)
	--render.SetMaterial(vgbm)
	--render.DrawScreenQuad()
	render.SetMaterial(addmat_r)
	render.DrawScreenQuadEx(-rx / 2, -ry / 2, ScrW() + rx, ScrH() + ry)
	render.SetMaterial(addmat_g)
	render.DrawScreenQuadEx(-gx / 2, -gy / 2, ScrW() + gx, ScrH() + gy)
	render.SetMaterial(addmat_b)
	render.DrawScreenQuadEx(-bx / 2, -by / 2, ScrW() + bx, ScrH() + by)
end

lodset = false

local hg_optimise_scopes = GetConVar("hg_optimise_scopes") or CreateClientConVar("hg_optimise_scopes", "1", true, false, "Enable this if scoping makes your fps cry (1 - lowers quality of props around you, 2 - \"disables\" main render)", 0, 2)
local hg_show_hitposmuzzle = ConVarExists("hg_show_hitposmuzzle") and GetConVar("hg_show_hitposmuzzle") or CreateClientConVar("hg_show_hitposmuzzle", "0", false, false, "shows weapons crosshair, work only ведьма admin rank or sv_cheats 1")

local angaddhuy = Angle(0,0,0)
function SWEP:DoRT()
	LOW_RENDER = nil
	local lply = LocalPlayer()
	local gun = self:GetWeaponEntity()
	local att = self:GetMuzzleAtt(gun,true)
	
	if not att then return end
	if not self.sizeperekrestie then return end
	
	self.isscoping = true

	local trace,pos,ang = self:GetTrace()
	
	if self.attachments.sight[1] and string.find(self.attachments.sight[1], "optic") and not string.find(self.attachments.sight[1], "0") and self.modelAtt and IsValid(self.modelAtt.sight) then pos = self.modelAtt.sight:GetPos() end
	local localPos = vecZero
	localPos:Set(self.localScopePos)
	localPos:Rotate(ang)
	pos:Add(localPos)
	
	local view = render.GetViewSetup(true)
	local diff, point = util.DistanceToLine(view.origin, view.origin + ang:Forward() * 50, pos)
	local scope_pos = WorldToLocal(point, angle_zero, pos, view.angles)
	local mat = self.mat or mat2
	
	mat:SetTexture("$basetexture", rtmat)
	
	if hg_show_hitposmuzzle:GetBool() then
		cam.Start3D()
			render.DrawLine(pos,point, Color( 255, 255, 255 ))
		cam.End3D()
	end

	local firstPerson = lply == GetViewEntity()

	local localhuy = pos - view.origin
	local anghuy = localhuy:Angle()
	local dist = pos:Distance(view.origin)

	ang[3] = lply:EyeAngles()[3] + self.AdditionalAng[3]
	
	angaddhuy[1] = scope_pos[3] * 7
	angaddhuy[2] = -scope_pos[2] * 7

	local rt = {
		x = 0,
		y = 0,
		w = rtsize,
		h = rtsize,
		angles = ang + angaddhuy,
		origin = pos,
		drawviewmodel = false,
		fov = math.max(self.ZoomFOV,0.5) / dist * 12,
		znear = 1,
		zfar = zfar,
		bloomtone = true
	}

	local scrw, scrh = ScrW(), ScrH() --retarded
	--render.RenderView(rt)

	local scr1 = pos:ToScreen()
	local scr2 = point:ToScreen()
	local diffa = Vector((scr1.x-scr2.x)/scrw,(scr1.y-scr2.y)/scrh)
	
	render.PushRenderTarget(rtmat, 0, 0, rtsize, rtsize)
	render.Clear(1, 1, 1, 1)
	local old = DisableClipping(true)

	diffa[1] = diffa[1] * ScrW() * 2
	diffa[2] = diffa[2] * ScrH() * 2
	
	if diffa:LengthSqr() < 10000.0 * (rtsize / 512) / (self.scope_blackout / 400) then
		if hg_optimise_scopes:GetInt() >= 2 then
			--LOW_RENDER = true
		end
		
		render.RenderView(rt)
		
		cam.Start3D()
			local aimWay = (trace.HitPos - trace.StartPos):GetNormalized() * 10000000000
			local toscreen = aimWay:ToScreen()
			local x, y = toscreen.x, toscreen.y
		cam.End3D()
		
		local distMul = 1.2
		local dist = math.sqrt(((x - scrw / 2) * distMul)^2 + ((y - scrh / 2) * distMul)^2)
		
		if dist > 850 * distMul then render.Clear(1, 1, 1, 1) end
		
		cam.Start2D()
			surface.SetDrawColor(255, 255, 255, 255)
			surface.SetMaterial(self.perekrestie)
			surface.DrawTexturedRectRotatedHuy(0, 0, (self.sizeperekrestie * rtsize / 512) / ((self.perekrestieSize and 4 ) or self.ZoomFOV / 3), (self.sizeperekrestie * rtsize / 512) / ((self.perekrestieSize and 4 ) or self.ZoomFOV / 3), 0, y / (scrh / ScrH()), x / (scrw / ScrW()), self.rot)
			surface.SetDrawColor(0, 0, 0, 255)
			surface.SetMaterial(self.scopemat)
			surface.DrawTexturedRectRotatedHuy(0, 0, self.blackoutsize * rtsize / 512 + 512, self.blackoutsize * rtsize / 512 + 512, 0, (ScrH() - y / (scrh / ScrH()) - rtsize / 2) * distMul * 1 + rtsize / 2, (ScrW() - x / (scrw / ScrW()) - rtsize / 2) * distMul * 1 + rtsize / 2)
			surface.SetDrawColor(0, 0, 0, 255)
			surface.SetMaterial(self.scopemat)
			surface.DrawTexturedRectRotatedHuy(0, 0, self.blackoutsize * rtsize / 512 + 512, self.blackoutsize * rtsize / 512 + 512, 0, (y / (scrh / ScrH()) - rtsize / 2) * distMul * 1 + rtsize / 2, (x / (scrw / ScrW()) - rtsize / 2) * distMul * 1 + rtsize / 2)
			surface.DrawTexturedRectRotatedHuy(0, 0, self.blackoutsize * rtsize / 512 + 512, self.blackoutsize * rtsize / 512 + 512, 0, -diffa[2] * 5 * distMul + rtsize / 2, -diffa[1] * 5 * distMul + rtsize / 2)
			--if self.SightDrawFunc then self:SightDrawFunc() end
			--surface.DrawTexturedRectRotatedHuy(rtsize / 2, rtsize / 2, self.blackoutsize * rtsize / 512 + 100, self.blackoutsize * rtsize / 512 + 100, self.rot, -scope_pos[3] * (self.scope_blackout * self.blackoutsize / 4000), -scope_pos[2] * (self.scope_blackout * self.blackoutsize / 4000))
			--DrawCA(0,0,0,0,0,0,rtmat)
		cam.End2D()
	end

	DisableClipping(old)
	render.PopRenderTarget()
end

function SWEP:ChangeFOV()
	self.ZoomFOV = math.Clamp(self.ZoomFOV - (delta / 10 or 0), self.FOVMin, self.FOVMax)
end

--
local vecZero = Vector(0, 0, 0)
local function WorldToScreen(vWorldPos, vPos, vScale, aRot, verticalScale)
	local vWorldPos = vWorldPos - vPos
	vWorldPos:Rotate(Angle(0, -aRot.y, 0))
	vWorldPos:Rotate(Angle(-aRot.p, 0, 0))
	vWorldPos:Rotate(Angle(0, 0, -aRot.r))
	return vWorldPos.x / vScale, (-vWorldPos.y) / (vScale * verticalScale)
end

SWEP.size = 0.0007
SWEP.holo_pos = Vector(-0.82, 3.48, 25)
SWEP.holo = Material("holo/huy-holo2.png")
SWEP.holo_lum = 1
SWEP.scale = Vector(1, 1.3, 1)

local anghuy = Angle(0,0,0)
local vechuy = Vector(0,0,0)

local exampleRT = GetRenderTarget( "example_rt", 1024, 1024 )

local customMaterial = CreateMaterial( "example_rt_mat", "UnlitGeneric", {
	["$basetexture"] = exampleRT:GetName(), -- You can use "example_rt" as well
	["$translucent"] = 1,
		["$vertexcolor"] = 1
} )

local mat_Mul = Material("pp/mul")
local mat_Add = Material("pp/add")
mat_Add:SetTexture("$basetexture", exampleRT)
mat_Add:SetVector("$color2", Vector(10, 10, 10))

hook.Add("InitPostEntity","zc_huyhuy",function()
	exampleRT = GetRenderTarget( "example_rt", 1024, 1024 )

	customMaterial = CreateMaterial( "example_rt_mat", "UnlitGeneric", {
		["$basetexture"] = exampleRT:GetName(), -- You can use "example_rt" as well
		["$translucent"] = 1,
		["$vertexcolor"] = 1
	} )

	mat_Mul = Material("pp/mul")
	mat_Add = Material("pp/add")
	mat_Add:SetTexture("$basetexture", exampleRT)
	mat_Add:SetVector("$color2", Vector(10, 10, 10))

end)


gameevent.Listen( "OnRequestFullUpdate" )
hook.Add( "OnRequestFullUpdate", "RT_shits", function( data )
	exampleRT = GetRenderTarget( "example_rt", 1024, 1024 )

	customMaterial = CreateMaterial( "example_rt_mat", "UnlitGeneric", {
		["$basetexture"] = exampleRT:GetName(), -- You can use "example_rt" as well
		["$translucent"] = 1,
		["$vertexcolor"] = 1
	} )

	mat_Mul = Material("pp/mul")
	mat_Add = Material("pp/add")
	mat_Add:SetTexture("$basetexture", exampleRT)
	mat_Add:SetVector("$color2", Vector(10, 10, 10))
end )

function SWEP:DoHolo()
end

local blured
// ПОЙНТ ТЫ НУБ ПОЛНЫЙ
--local hg_blur_holo = GetConVar("hg_blur_holo") or CreateClientConVar("hg_blur_holo", "1", true, false, "Disable this if holo blur makes your fps cry.", 0, 1)

hook.Add("PostDrawTranslucentRenderables","stencil-test-holo2",function()
	local ply = not LocalPlayer():Alive() and LocalPlayer():GetNWEntity("spect",LocalPlayer()) or LocalPlayer()
	if not IsValid(ply) then return end
	local self = ply.GetActiveWeapon and ply:GetActiveWeapon() or nil
	if not IsValid(self) or not self.GetWeaponEntity or not IsValid(self:GetWeaponEntity()) then return end

	local tr,pos,ang = self:GetTrace()
	local models = self.holomodels
	if not models then return end
	local view = render.GetViewSetup()
	local eyePos = view.origin
	local hitPos = eyePos + ang:Forward() * 2624
	
	if blured ~= self.holo then
		// МОЙ ДРУГ ТОЛЬКО С ПРОЦЕССОРОМ НЕ МОГ ИГРАТЬ НОРМАЛЬНО С ГОЛОГРАФАМИ!!!!
		// ТЫ ОЧЕНЬ ПЛОХОЙ!!! И НУЫЫЫЫЫ																							|\_/|
		// Короче я пофиксил какашку, теперь блюр один раз на изменение текстуры, теперь смешных приколов фпс падений не будет. |'.'|
		// ПЛЫВ ПЛЫВ ПЛЫВ																										|	|
		// ЭТО САМЫЙ БОЛЬШОЙ КОМЕНТАРИЙ ХЕХЕХЕХЕХЕЕХ																		   	|___|
		render.PushRenderTarget( exampleRT )
			render.OverrideAlphaWriteEnable( true, true )

			render.ClearDepth()
			render.Clear( 0, 0, 0, 0 )	

			DisableClipping(true)

				cam.Start2D()
					surface.SetDrawColor(255, 255, 255, 155)
					surface.SetMaterial(self.holo)
					surface.DrawTexturedRect(0, 0, 1024, 1024)
					--render.BlurRenderTarget(exampleRT, 30, 35, 5)

					--[[for i = 1, 2 do
						render.SetMaterial(mat_Add)
						render.DrawScreenQuad()
					end--]]
				cam.End2D()

			DisableClipping(false)

			render.OverrideAlphaWriteEnable( false )
		render.PopRenderTarget()

		blured = self.holo
	end

	if models then
		
		render.SetStencilWriteMask( 0xFF )
		render.SetStencilTestMask( 0xFF )
		render.SetStencilReferenceValue( 0 )
		render.SetStencilCompareFunction( STENCIL_ALWAYS )
		render.SetStencilPassOperation( STENCIL_KEEP )
		render.SetStencilFailOperation( STENCIL_KEEP )
		render.SetStencilZFailOperation( STENCIL_KEEP )
		render.ClearStencil()
		
		-- Enable stencils
		render.SetStencilEnable( true )
		-- Set everything up everything draws to the stencil buffer instead of the screen
		render.SetStencilReferenceValue( 1 )
		render.SetStencilCompareFunction( STENCIL_NOTEQUAL )
		render.SetStencilPassOperation( STENCIL_REPLACE )

		for model in pairs(models) do
			if not IsValid(model) then continue end
			model:DrawModel()
		end

		render.SetStencilCompareFunction( STENCIL_EQUAL )
		--render.ClearBuffersObeyStencil( 0, 148, 133, 255, false )

		cam.Start2D()
			local x,y = hitPos:ToScreen().x,hitPos:ToScreen().y
			local m = Matrix()
			local w,h = ScrW(),ScrH()
			vechuy[1] = w / 2
			vechuy[2] = h / 2
			local center = vechuy
		
			m:Translate( center )
			anghuy[2] = ang[3] - 90 - view.angles[3]
			m:Rotate( anghuy )
			m:Translate( -center )
		
			local size = 15
			--render.OverrideBlend( true,BLEND_DST_COLOR,BLEND_ONE,BLENDFUNC_ADD )
			--	surface.SetDrawColor(255,255,255,15)
			--	surface.SetMaterial(customMaterial)
			--	surface.DrawTexturedRectRotatedPoint(x,y,size * 2 * self.holo_size,size * 2 * self.holo_size,-anghuy[2],-0,0)
			--render.OverrideBlend( false )

			surface.SetDrawColor(255,122,122,255)
			surface.SetMaterial(self.holo)
			surface.DrawTexturedRectRotatedPoint(x,y,size * 2 * self.holo_size,size * 2 * self.holo_size,-anghuy[2],-0,0)
			
		cam.End2D()

		-- Let everything render normally again
		render.SetStencilEnable( false )

	end

end)

hook.Add("RenderScreenspaceEffects","stencil-test-holo2",function()
	--[[local ply = not LocalPlayer():Alive() and LocalPlayer():GetNWEntity("spect",LocalPlayer()) or LocalPlayer()
	local self = ply.GetActiveWeapon and ply:GetActiveWeapon() or nil
	if not IsValid(self) or not self.GetWeaponEntity or not IsValid(self:GetWeaponEntity()) then return end

	local att = self:GetMuzzleAtt(nil,true,false)
	local models = self.holomodels
	if not models then return end
	local view = render.GetViewSetup()
	local eyePos = view.origin
	local hitPos = eyePos + att.Ang:Forward() * 2624

	if models then
		render.SetStencilWriteMask( 0xFF )
		render.SetStencilTestMask( 0xFF )
		render.SetStencilReferenceValue( 0 )
		render.SetStencilCompareFunction( STENCIL_ALWAYS )
		render.SetStencilPassOperation( STENCIL_KEEP )
		render.SetStencilFailOperation( STENCIL_KEEP )
		render.SetStencilZFailOperation( STENCIL_KEEP )
		render.ClearStencil()
		
		-- Enable stencils
		render.SetStencilEnable( true )
		-- Set everything up everything draws to the stencil buffer instead of the screen
		render.SetStencilReferenceValue( 1 )
		render.SetStencilCompareFunction( STENCIL_NOTEQUAL )
		render.SetStencilPassOperation( STENCIL_REPLACE )
		
		for model in pairs(models) do
			if not IsValid(model) then continue end
			model:DrawModel()
		end

		render.SetStencilCompareFunction( STENCIL_EQUAL )

		render.SetStencilEnable( false )

	end--]]

end)

hook.Add("PostDrawOpaqueRenderables","stencil-test-holo",function()
	--wtf teplak??!???
	if true then return end
	render.SetStencilWriteMask( 0xFF )
	render.SetStencilTestMask( 0xFF )
	render.SetStencilReferenceValue( 0 )
	render.SetStencilCompareFunction( STENCIL_ALWAYS )
	render.SetStencilPassOperation( STENCIL_KEEP )
	render.SetStencilFailOperation( STENCIL_KEEP )
	render.SetStencilZFailOperation( STENCIL_KEEP )
	render.ClearStencil()

	-- Enable stencils
	render.SetStencilEnable( true )
	-- Set the reference value to 1. This is what the compare function tests against
	render.SetStencilReferenceValue( 1 )
	-- Always draw everything
	render.SetStencilCompareFunction( STENCIL_ALWAYS )
	
	render.SetStencilZFailOperation( STENCIL_KEEP )
	render.SetStencilPassOperation( STENCIL_REPLACE )

	-- Draw our entities. They will draw as normal
	for _, ent in ipairs( player.GetAll() ) do
		ent:DrawModel()
	end
	
	-- Now, only draw things that have their pixels set to 1. This is the hidden parts of the stencil tests.
	render.SetStencilCompareFunction( STENCIL_EQUAL )
	-- Flush the screen. This will draw teal over all hidden sections of the stencil tests
	
	render.ClearBuffersObeyStencil( 0, 148, 133, 255, false )

	-- Let everything render normally again
	render.SetStencilEnable( false )

end)

local Shells = {}
Shells["9x19"] = {m = "models/shells/fhell_9x19mm.mdl", s = "Shell"}
Shells["9x18"] = {m = "models/shells/fhell_9x18mm.mdl", s = "Shell"}
Shells["45acp"] = {m = "models/shells/fhell_45cal.mdl", s = "Shell"}
Shells["380acp"] = {m = "models/shells/fhell_380acp.mdl", s = "Shell"}
Shells["50ae"] = {m = "models/shells/fhell_50ae.mdl", s = "Shell"}
Shells["50cal"] = {m = "models/shells/fhell_50cal.mdl", s = {"weapons/shells/m249_link_concrete_01.wav","weapons/shells/m249_link_concrete_02.wav","weapons/shells/m249_link_concrete_03.wav","weapons/shells/m249_link_concrete_04.wav","weapons/shells/m249_link_concrete_05.wav","weapons/shells/m249_link_concrete_06.wav","weapons/shells/m249_link_concrete_07.wav","weapons/shells/m249_link_concrete_08.wav"}}
Shells["545x39"] = {m = "models/shells/fhell_545.mdl", s = "Shell"}
Shells["556x45"] = {m = "models/shells/fhell_556.mdl", s = "Shell"}
Shells["762x39"] = {m = "models/shells/fhell_762x39.mdl", s = "Shell"}
Shells["762x51"] = {m = "models/shells/fhell_762x51.mdl", s = "Shell"}
Shells["762x54"] = {m = "models/weapons/arc9/darsu_eft/shells/762x54r.mdl", s = "Shell"}
Shells[".338Lapua"] = {m = "models/shells/shell_338mag.mdl", s = "Shell"}
Shells["12x70"] = {m = "models/weapons/arc9/darsu_eft/shells/patron_12x70_shell.mdl", s = "12Guage"}
Shells["Pulse"] = {m = "models/pulse_slug.mdl", s = "12Guage"}
Shells["10mm"] = {m = "models/shells/fhell_10mm.mdl", s = "Shell"}
Shells["mc51len"] = {m = "models/shells/fhell_mc51.mdl"}
Shells["m249len"] = {m = "models/shells/fhell_m249.mdl"}
Shells["m60len"] = {m = "models/shells/fhell_m60.mdl"}
Shells["12x70beanbag"] = {m = "models/weapons/arc9/darsu_eft/shells/patron_12x70_slug_grizzly_40_shell.mdl", s = "12Guage"}
Shells["12x70slug"] = {m = "models/weapons/arc9/darsu_eft/shells/patron_12x70_slug_poleva_3_shell.mdl", s = "12Guage"}
Shells["ags_shell"] = {m = "models/weapons/arc9/darsu_eft/shells/40x46_m716.mdl", s = "12Guage", vCustomPhys = Vector(1,1,1)}


hg_shelles = hg_shelles or {}
local gamemod = engine.ActiveGamemode()

local Types = {
	["grass"] = "grass",
	["carpet"] = "carpet",
	["sand"] = "sand",
	["metal"] = "metal",
	["metalgrate"] = "metal",
	["wood"] = "wood",
	["wood_plank"] = "wood",
	["rubber"] = "carpet",
	["water"] = "water",
	["metalpanel"] = "metal",
	["wood_panel"] = "wood",
	["default"] = "dirt"
}

local ShellsSND = {
	["12Guage"] ="zcity/shells/shell_12ga_",
	["Shell"] = "zcity/shells/shell_39mm_"
}

hg_trails = hg_trails or {}

local hg_potatopc = GetConVar("hg_potatopc") or CreateClientConVar("hg_potatopc", "0", true, false, "Enable this if you are noob", 0, 1)
local hg_maxsmoketrails = GetConVar("hg_maxsmoketrails") or CreateClientConVar("hg_maxsmoketrails", "7", true, false, "Max amount of smoke trail effects (lags after 10)", 0, 30)
function SWEP:MakeShell(shell, pos, ang, vel)
	if not shell or not pos or not ang then
		return
	end
		
	local t = Shells[shell]
	
	if not t then
		return
	end
	
	vel = vel or Vector(0, 0, -100)
	vel = vel + VectorRand() * 5
	
	local ent = ClientsideModel(t.m, RENDERGROUP_BOTH) 
	function ent:Draw()
		if (LocalPlayer():EyePos() - self:GetPos()):LengthSqr() < 512^2 then
			self:DrawModel()
		end
	end
	ent:SetPos(pos)

	ent:PhysicsInitBox( t.vCustomPhys and -t.vCustomPhys or Vector(-0.5, -0.15, -0.5), t.vCustomPhys or Vector(0.5, 0.15, 0.5),"gmod_silent")

	ent:SetAngles(ang)
	ent:SetMoveType(MOVETYPE_VPHYSICS) 
	ent:SetSolid(SOLID_VPHYSICS) 
	ent:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
    hg_shelles[#hg_shelles+1] = ent
	
	local phys = ent:GetPhysicsObject()
	phys:SetMaterial("gmod_silent")
	phys:SetMass(10)
	phys:SetVelocity(vel + (((IsValid(self) and IsValid(self:GetOwner())) and self:GetOwner():GetVelocity()/1.1) or Vector(0,0,0)))
    phys:SetAngleVelocity(VectorRand() * 200)
	
	if not hg_potatopc:GetBool() then
		if math.random(3) == 1 and #hg_trails < 10 then
			local eff = ent:CreateParticleEffect("smoke_trail_wild",1,{PATTACH_ABSORIGIN_FOLLOW,ent,ent:GetPos()})
			table.insert(hg_trails,eff)
			eff:StartEmission()
			timer.Simple(3,function()
				if IsValid(eff) then
					eff:StopEmission()
				end
			end)
			timer.Simple(5,function()
				if IsValid(eff) then
					eff:StopEmissionAndDestroyImmediately()
					table.RemoveByValue(hg_trails,eff)
				end
			end)
		end
	end

    ent:AddCallback("PhysicsCollide",function(ent,data)
        if data.Speed > 50 then
			if isstring(t.s) then
				local fallmat = util.GetSurfacePropName( data.TheirSurfaceProps )
				if ent:WaterLevel() > 0 then
					fallmat = "water"
				end
				local Type = Types[fallmat] or "default"
				ent:EmitSound(ShellsSND[t.s]..Type.."_"..math.random(1,5)..".mp3", 60, 100) 
			end

            if istable(t.s) then
                ent:EmitSound(table.Random(t.s), 60, 100)   
            end
        end
    end)
	gamemod = gamemod or engine.ActiveGamemode()
	if zb.CROUND and zb.CROUND ~= "hmcd" or gamemod == "sandbox" then	
		SafeRemoveEntityDelayed(ent, 10)
	end
end

function hg.addBulletHoleEffect(pos)
	if not hg_potatopc:GetBool() then
		if math.random(3) == 1 and #hg_trails < hg_maxsmoketrails:GetInt() then
			local eff = CreateParticleSystemNoEntity( "smoke_trail_wild", pos )
			table.insert(hg_trails,eff)
			eff:StartEmission()
			timer.Simple(3,function()
				if IsValid(eff) then
					eff:StopEmission()
				end
			end)
			timer.Simple(5,function()
				if IsValid(eff) then
					eff:StopEmissionAndDestroyImmediately()
					table.RemoveByValue(hg_trails,eff)
				end
			end)
		end
	end
end

hook.Add("PostCleanupMap","cleanupshells",function()
    for k,v in ipairs(hg_shelles) do
        --print("huy")
        v:Remove()
    end
    hg_shelles = {}
end)