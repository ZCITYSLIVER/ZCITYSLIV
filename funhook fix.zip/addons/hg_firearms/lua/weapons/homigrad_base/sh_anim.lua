-- "addons\\homigrad-weapons\\lua\\weapons\\homigrad_base\\sh_anim.lua"

AddCSLuaFile()
--
function SWEP:Initialize_Anim()
	self.Anim_RecoilCameraZoom = Vector(0, 0, 0)
	self.Anim_RecoilCameraZoomSet = Vector(0, 0, 0)
	self.Anim_RecoilLerp = 0
end

if SERVER then
	function SWEP:WorldModel_Transform()

	end
end

function SWEP:SetHold(value)
	self.holdtype = value
	self:SetHoldType(value)
	self:SetWeaponHoldType(value)
end

local translatehuys = {
	[1] = 1,
	[2] = 1,
	[3] = 2,
	[4] = 2
}

hook.Add("Bones", "homigrad-weapons-bone", function(ply)
	local wep = ply:GetActiveWeapon()
	local func = wep.Animation
	if func then func(wep, ply) end
end)

local vecZero = Vector(0, 0, 0)
local vecZero2 = Vector(0, 0, 0)
local angZero = Angle(0, 0, 0)
local CurTime = CurTime
function SWEP:Animation()
	local owner = self:GetOwner()

	--local bon = owner:LookupBone("ValveBiped.Bip01_Spine")
	--local mat = owner:GetBoneMatrix(bon)
	--mat:SetTranslation(Player(3):GetBoneMatrix(1):GetTranslation())
	--mat:SetAngles(Angle(0,0,0))
	--mat:SetTranslation(Vector(0,0,0))
	--owner:SetBoneMatrix2(bon,mat)

	local dtime = SysTime() - (self.dtimeanim or SysTime())

	if IsValid(owner) and (not owner:IsNPC() and (owner.InVehicle and owner:InVehicle())) then
		self:SetHoldType(self:IsPistolHoldType() and "pistol" or "smg")
		if IsValid(owner) and owner:IsPlayer() and IsValid(owner:GetVehicle()) and owner:GetVehicle():GetDriver() == owner and owner:GetVehicle():GetClass() ~= "prop_vehicle_prisoner_pod"  then
			return
		end
	end

	if (not IsValid(owner)) or (owner:GetActiveWeapon() ~= self) then return end
	
	self:CloseAnim(dtime)

	self.dtimeanim = SysTime()

	if owner.suiciding then
		self:SuicideAnim()
		return
	end

	self:AnimApply_ShootRecoil(self:LastShootTime())
	self:AnimHold()
	if self:IsZoom() then self:AnimZoom() end
end

function SWEP:AnimationRender()
	self:AnimationPost()
end

function SWEP:AnimationPost()
end

local bone, name
function SWEP:BoneSetAdd(layerID, lookup_name, vec, ang)
	if self:GetOwner():IsPlayer() then
		local bon = hg.bone.client_only[lookup_name]
		if bon then
			local ent = hg.GetCurrentCharacter(self:GetOwner())
			local boneIndex = ent:LookupBone(bon) 
			
			if not boneIndex then return end 
			
			local mat = ent:GetBoneMatrix(boneIndex) 
			if not mat then return end 
			
			local nvec, nang = LocalToWorld(vec or vector_origin, ang or angle_zero, mat:GetTranslation(), mat:GetAngles())
			mat:SetTranslation(nvec)
			mat:SetAngles(nang)
			hg.bone_apply_matrix(ent, bon, mat)
			return
		end
		hg.bone.SetAdd(self:GetOwner(), translatehuys[layerID], lookup_name, vec, ang)
	end
end


function SWEP:AnimHoldPost(model)
end

if CLIENT then
	local function changePosture()
		RunConsoleCommand("hg_change_posture", -1)
	end

	local function resetPosture()
		RunConsoleCommand("hg_change_posture", 0)
	end

	hook.Add("radialOptions", "hg-change-posture", function()
		local wep = LocalPlayer():GetActiveWeapon()
		local organism = LocalPlayer().organism or {}

		if wep and ishgweapon(wep) and not organism.otrub then
			local tbl = {changePosture, "Change Posture"}
			hg.radialOptions[#hg.radialOptions + 1] = tbl
			local tbl = {resetPosture, "Reset Posture"}
			hg.radialOptions[#hg.radialOptions + 1] = tbl
		end
	end)

	local printed
	concommand.Add("hg_change_posture", function(ply, cmd, args)
		if not args[1] and not printed then print([[Change your gun posture:
0 - regular hold
1 - hipfire
2 - left clavicle pose
3 - high ready
4 - low ready
5 - point shooting
6 - shooting from cover
7 - one-armed shooting
]]) printed = true end
		local pos = math.Round(args[1] or -1)
		net.Start("change_posture")
		net.WriteEntity(ply)
		net.WriteInt(pos, 8)
		net.SendToServer()
	end)

	net.Receive("change_posture", function()
		local ply = net.ReadEntity()
		local pos = net.ReadInt(8)
		
		ply.posture = pos
	end)
else
	util.AddNetworkString("change_posture")
	net.Receive("change_posture", function()
		local ply = net.ReadEntity()
		local pos = net.ReadInt(8)

		if pos ~= -1 then 
			if pos == ply.posture then
				ply.posture = 0
				pos = 0
			else
				ply.posture = pos 
			end
		else
			ply.posture = ply.posture or 0
			ply.posture = (ply.posture + 1) >= 9 and 0 or ply.posture + 1
		end
		net.Start("change_posture")
		net.WriteEntity(ply)
		net.WriteInt(ply.posture, 9)
		net.Broadcast()
	end)
end

local angHold1 = Angle(-10, -5, 0)
local angHold2 = Angle(-10, 5, 0)
SWEP.handsAng = Angle(0, 0, 0)
local plyAng, handAng, handPos, addAng, _ = Angle(0, 0, 0), Angle(0, 0, 0), vecZero, Angle(0, 0, 0), vecZero

function SWEP:SuicideAnim()
	self:SetHold("normal")
end

function SWEP:IsPistolHoldType()
	return (self.HoldType == "revolver") or (self.HoldType == "pistol") or self.IsPistol
end

local ang1 = Angle(0, 0, 0)

local funcNil = function() end

hg.postureFunctions = {
	[1] = function(self,ply)
	end,
	[2] = function(self,ply)
	end,
	[3] = function(self,ply)
	end,
	[6] = function(self,ply)
	end,
	[7] = function(self,ply)
		if self.IsPistolHoldType and not self:IsPistolHoldType() then ply.posture = ply.posture + 1 end		
	end,
	[8] = function(self,ply)
		if self.IsPistolHoldType and not self:IsPistolHoldType() then ply.posture = ply.posture + 1 end		
	end,
}

function SWEP:ReadyStance()
	local ply = self:GetOwner()
	return self:IsSprinting() or ply.posture == 4 or ply.posture == 3
end

function SWEP:AnimHold()
	self.rotfuckinghands = self.IsPistolHoldType and not self:IsPistolHoldType()
	local _
	local ply = self:GetOwner()
	if not self.attachments then return end
	self.holdtype = self.attachments.grip and #self.attachments.grip ~= 0 and hg.attachments.grip[self.attachments.grip[1]].holdtype or self.HoldType
	self.holdtype = self.holster and (self.holster - CurTime()) / (self.CooldownHolster / self.Ergonomics) < 0.5 and "normal" or self.holdtype
	self.holdtype = (self:IsPistolHoldType() and ((ply.posture == 7 or ply.posture == 8) and not self.reload)) and "slam" or self.holdtype
	--self.holdtype = self:ReadyStance() and not self:IsPistolHoldType() and "pistol" or self.holdtype
	self:SetHold(self.holdtype)

	local func = hg.postureFunctions[ply.posture] or funcNil

	func(self,ply)

	if CLIENT then
		ply:SetIK(false)
	end

	if CLIENT then
		--self:AnimHoldPost(self.worldModel)
	end
end

local vecZoom1 = Vector(1, -1, 0)
local angZoom1 = Angle(0, 0, 0)
function SWEP:AnimZoom()
	local owner = self:GetOwner()
	local bon = owner:LookupBone("ValveBiped.Bip01_Head1")
	if not bon then return end
	local pos = owner:GetBonePosition(bon)
	if not pos then return end

	angZoom1[1] = (self:GetWeaponEntity():GetPos() - pos):GetNormalized():Dot(owner:EyeAngles():Right())
	angZoom1[1] = -angZoom1[1] * 50
	angZoom1[1] = math.Clamp(angZoom1[1],-20,20)
	self:BoneSetAdd(1, "head", vecZero, angZoom1)
end

local math_max, math_Clamp = math.max, math.Clamp
SWEP.AnimShootMul = 1
SWEP.AnimShootHandMul = 1
function SWEP:GetAnimPos_Shoot(time, timeSpan)
	local timeSpan = timeSpan or 0.2
	return timeSpan - math_Clamp(CurTime() - time, 0, timeSpan)
end

function SWEP:AnimApply_ShootRecoil(time, div)
	local owner = self:GetOwner()
	local animpos = self:GetAnimPos_Shoot(time)
	if animpos > 0 then
		animpos = animpos * ((self:IsZoom() and self.SpreadMulZoom or self.SpreadMul) + math_max(self.Primary.Force / 110 - 1, 0)) * (( not owner:IsNPC() and owner:Crouching() ) and self.CrouchMul or 1) * 0.75
		animpos = animpos * self.AnimShootMul
		animpos = animpos / (div or 1)

		if self.IsPistolHoldType and not self:IsPistolHoldType() then
			if CLIENT and (owner ~= LocalPlayer() or LocalPlayer() ~= GetViewEntity()) then
				self:BoneSetAdd(4, "spine", vecZero, Angle(0, 0, -25 * animpos * self.Primary.Force / 50))
			end
		end
	end
end

local hullVec = Vector(0, 0, 0)
local angZero = Angle(0, 0, 0)
local vecAsd2 = Vector(-45, 4, 1)
SWEP.lengthSub = 0
function SWEP:CloseAnim(dtime)
	if not self.attachments then return end
	local owner = self:GetOwner()
	if !owner:IsPlayer() then self.lerpaddcloseanim = 0 return 0  end
	if owner:InVehicle() then self.lerpaddcloseanim = 0 return 0 end
	if owner:IsNPC() then self.lerpaddcloseanim = 0 return 0 end
	if owner.suiciding then self.lerpaddcloseanim = 0 return 0 end

	local desiredPos,desiredAng = self:WorldModel_Transform(true,true)
	local tr,pos,ang = self:GetTrace(nil,desiredPos,desiredAng)
	
	--[[if SERVER then
		local ent = tr.Entity

		if IsValid(ent) and ent:IsNPC() and ((ent:Disposition(owner) == D_LI) or (ent:Disposition(owner) == D_NU)) then
			--self:SetNWFloat("lower_weapon", CurTime() + 2)
		else
			self:SetNWFloat("lower_weapon", 0)
		end
	end--]]

	local _, point, dis = util.DistanceToLine(pos, pos - ang:Forward() * 70, owner:EyePos())
	
	dis = math.ceil(dis)
	
	local tr = util.TraceHull({
		start = point,
		endpos = point + ang:Forward() * (dis + (self:HasAttachment("barrel", "supressor") and 20 or 0)),
		filter = {self, self:GetOwner(), hg.GetCurrentCharacter(self:GetOwner())},
		mins = -hullVec,
		maxs = hullVec,
		mask = MASK_SHOT
	})
	
	local frac = tr.Fraction
	local dist = 1 - frac
	
	if dtime and isnumber(dtime) then
		self.lerpaddcloseanim = math.min(dist,(self:IsPistolHoldType() and 0.45 or 0.3))--Lerp(hg.lerpFrameTime2(0.1,dtime),self.lerpaddcloseanim,dist)
		self.closeanimdis = dis
	end

	return dist,tr
end

local vec3 = Vector(0, 0, 2)
function SWEP:AnimApply_RecoilCameraZoom()
	local vecrand = VectorRand(-0.1, 0.1)
	vecrand[3] = vec3[3]
	--vecrand[1] = vecrand[1] - 0.3
	self.Anim_RecoilCameraZoomSet = vec3
	--self.Anim_RecoilCameraZoom = LerpVector(FrameTime() * 15, self.Anim_RecoilCameraZoom, self.Anim_RecoilCameraZoomSet)
end

local function isMoving(ply)
	return ply:GetVelocity():Length() > 30 and ply:OnGround()
end

local function isCrouching(ply)
	return (hg.KeyDown(ply,IN_DUCK) or ply:Crouching()) and ply:OnGround()
end

hook.Add("Bones", "homigrad-lean-bone", function(ply)
	if not hg.KeyDown(ply, IN_ALT1) and not hg.KeyDown(ply, IN_ALT2) or (hg.KeyDown(ply, IN_ALT1) and hg.KeyDown(ply, IN_ALT2)) then ply.lean = math.Approach(ply.lean or 0, 0, FrameTime() * 10) end
	
	ply.weightmul = weightmul or hg.CalculateWeight(ply, 140)
	
	local mul = ply.weightmul ^ 2

	if not hg.KeyDown(ply, IN_SPEED) and hg.KeyDown(ply, IN_ALT1) and not hg.KeyDown(ply, IN_ALT2) then
		ply.lean = math.Approach(ply.lean or 0, -1, FrameTime() * 10 * mul)
		local self = ply:GetActiveWeapon()
		if self.IsPistolHoldType and not self:IsPistolHoldType() then
			hg.bone.SetAdd(ply, 1, "r_upperarm", vecZero, Angle(0, -10, -20) * -ply.lean)
			hg.bone.SetAdd(ply, 1, "spine1", vecZero, Angle(-30,-10,10) * -ply.lean)
			hg.bone.SetAdd(ply, 1, "head", vecZero, Angle(0, 10, 0) * -ply.lean)
		else
			hg.bone.SetAdd(ply, 1, "spine1", vecZero, Angle(-30, 0, 0) * -ply.lean)
			hg.bone.SetAdd(ply, 1, "l_upperarm", vecZero, Angle(-20, 0, 0) * -ply.lean)
		end
	end

	if not hg.KeyDown(ply, IN_SPEED) and hg.KeyDown(ply, IN_ALT2) and not hg.KeyDown(ply, IN_ALT1) then
		ply.lean = math.Approach(ply.lean or 0, 1, FrameTime() * 10 * mul)
		local self = ply:GetActiveWeapon()
		if self.IsPistolHoldType and not self:IsPistolHoldType() then
			hg.bone.SetAdd(ply, 1, "r_upperarm", vecZero, Angle(10, 0, 10) * ply.lean)
			hg.bone.SetAdd(ply, 1, "spine1", vecZero, Angle(isCrouching(ply) and 35 or 20, 25, isCrouching(ply) and 18 or 18) * ply.lean)
			hg.bone.SetAdd(ply, 1, "r_forearm", vecZero, Angle(-10, -10, -10) * ply.lean)
			hg.bone.SetAdd(ply, 1, "head", vecZero, Angle(30, 0, 0) * ply.lean)
		else
			hg.bone.SetAdd(ply, 1, "spine1", vecZero, Angle(35, 0, 0) * ply.lean)
			hg.bone.SetAdd(ply, 1, "r_upperarm", vecZero, Angle(20, 0, 0) * ply.lean)
		end
	end
	--[[
	local tbl = {
		Angle(0,0,0),
		Angle(0,-10,0),
		Angle(0,-70,0),
		Angle(0,-150,0),
		Angle(0,-150,0),
		Angle(0,-90,0),
		Angle(0,-90,0),
	}
	local tbl2 = {
		Angle(0,60,0),
		Angle(0,70,0),
		Angle(0,80,0),
		Angle(0,120,0),
		Angle(0,120,0),
		Angle(0,-40,0),
		Angle(0,-40,0),
	}
	
	hg.bone.SetAdd(ply, 1, "r_thigh", vecZero, tbl[math.Round((CurTime()*10)%#tbl)])
	hg.bone.SetAdd(ply, 1, "r_calf", vecZero, tbl2[math.Round((CurTime()*10)%#tbl2)])
	--]]
	--пинок early access ^^^
	if ply:Crouching() and not ply:InVehicle() then
		local normaldist = 120

		local tr = {}
		tr.start = ply:GetPos()
		tr.endpos = ply:GetPos() + vector_up * normaldist
		tr.filter = {ply}
		tr.mask = MASK_PLAYERSOLID
		tr = util.TraceLine(tr)

		local dist = tr.HitPos:Distance(ply:GetPos())
		local frac = math.max(1 - dist / normaldist,0)
		
		--hg.bone.SetAdd(ply, 1, "spine1", vecZero, Angle(0,frac * 90,0))
		--hg.bone.SetAdd(ply, 1, "head", vecZero, Angle(0,frac * 90,0))
	end
	--hg.bone.SetAdd(ply, 1, "spine1", vecZero, Angle(0,thing,0))
	--hg.bone.SetAdd(ply, 1, "r_upperarm", vecZero, Angle(thing / 2,-thing / 2,0))
	--hg.bone.SetAdd(ply, 1, "head", vecZero, Angle(0,thing,0))
end)

function SWEP:InFreemove()
	--
end

function SWEP:ResetFreemove()
	--
end

function SWEP:Step_Inspect(time)
	if self.inspect == nil or self.reload ~= nil then return end
	if self:KeyDown(IN_RELOAD) or self:KeyDown(IN_ATTACK) or self:KeyDown(IN_ATTACK2) then
		self.inspect = nil
	end

	local time2 = self.inspect
	
	if time2 and time2 < time then
		self.inspect = nil
	end

	if time2 then
		local part = 1 - (time2 - time) / 5
		
		part = math.ease.InOutQuad(part)

		self:AnimationInspect(part)
	end
end

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0)
}

function SWEP:AnimationInspect(time)
	local wep = self--weapons.Get( self:GetClass() )
	
	local anims = wep.InspectAnimLH
	local anims2 = wep.InspectAnimLHAng
	local floortime = math.floor(time * (#anims))
	local floortime2 = math.floor(time * (#anims2))
	local lerp = time * (#anims) - floortime
	local lerp2 = time * (#anims2) - floortime2
	
	local pos1,pos2 = anims[math.Clamp(floortime,1,#anims)],anims[math.Clamp(floortime+1,1,#anims)]

	self.LHPosOffset = Lerp(lerp,pos1,pos2)
	self.LHAngOffset = Lerp(lerp2,anims2[math.Clamp(floortime2,1,#anims2)],anims2[math.Clamp(floortime2+1,1,#anims2)])

	local anims = wep.InspectAnimRH
	local anims2 = wep.InspectAnimRHAng
	local floortime = math.floor(time * (#anims))
	local floortime2 = math.floor(time * (#anims2))
	local lerp = time * (#anims) - floortime
	local lerp2 = time * (#anims2) - floortime2
	
	local pos1,pos2 = anims[math.Clamp(floortime,1,#anims)],anims[math.Clamp(floortime+1,1,#anims)]

	self.RHPosOffset = Lerp(lerp,pos1,pos2)
	self.RHAngOffset = Lerp(lerp2,anims2[math.Clamp(floortime2,1,#anims2)],anims2[math.Clamp(floortime2+1,1,#anims2)])

	local anims2 = wep.InspectAnimWepAng
	local floortime2 = math.floor(time * (#anims2))
	local lerp2 = time * (#anims2) - floortime2

	--self.WepPosOffset = Lerp(lerp,anims[math.Clamp(floortime,1,#anims)],anims[math.Clamp(floortime+1,1,#anims)])
	local ang1,ang2 = anims2[math.Clamp(floortime2,1,#anims2)],anims2[math.Clamp(floortime2+1,1,#anims2)]
	
	local oldang = -(-self.WepAngOffset)
	
	self.WepAngOffset = Lerp(lerp2,ang1,ang2) + self.angvel

	--self.angvel:Add((self.WepAngOffset-oldang)/75)
	--self.angvel = self.angvel * 0.99
	if CLIENT and self:GetOwner() == LocalPlayer() then
		local addang = (self.WepAngOffset-oldang)/15
		addang[3] = addang[3] / 5
		ViewPunch2(addang)
		ViewPunch(-addang)
	end
end


--[[
	"head",
	"spine",
	"spine1",
	"spine2",
	"spine4",
	"pelvis",

	"r_clavicle",
	"r_upperarm",
	"r_forearm",
	"r_hand",

	"l_clavicle",
	"l_upperarm",
	"l_forearm",
	"l_hand",

	"r_thigh",
	"r_calf",
	"r_foot",
	"r_toe0",

	"l_thigh",
	"l_calf",
	"l_foot",
	"l_toe0"
]]
