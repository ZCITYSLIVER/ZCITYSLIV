-- "addons\\homigrad-weapons\\lua\\weapons\\homigrad_base\\cl_camera_wep.lua"

local lply = LocalPlayer()
local wep
-- 💀