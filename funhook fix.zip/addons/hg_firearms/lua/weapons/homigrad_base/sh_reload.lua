-- "addons\\homigrad-weapons\\lua\\weapons\\homigrad_base\\sh_reload.lua"
AddCSLuaFile()

function SWEP:Initialize_Reload()
	self.LastReload = 0
end

SWEP.dwr_customVolume = 1
SWEP.OpenBolt = false
function SWEP:CanReload()
	local ply = self:GetOwner()
	if self:LastShootTime() + 0.1 > CurTime() then return end
	if IsValid(ply:GetNetVar("carryent2")) then
		if SERVER then
			local ent = ply:GetNetVar("carryent2")
			ply:SetNetVar("carryent2",NULL)
			ply:SetNetVar("carrybone2",nil)
			ply:SetNetVar("carrymass2",0)
			ply:SetNetVar("carrypos2",nil)
			heldents[ent:EntIndex()] = nil
		end
	end
	if self.ReloadNext or not self:CanUse() or self:GetOwner():GetAmmoCount(self:GetPrimaryAmmoType()) == 0 or self:Clip1() >= self:GetMaxClip1() + (self.drawBullet and not self.OpenBolt and 1 or 0) then --shit
		return
	end
	return true
end
if SERVER then
	util.AddNetworkString("hg_insertAmmo")
end
function SWEP:InsertAmmo(need)
	local owner = self:GetOwner()
	local primaryAmmo = self:GetPrimaryAmmoType()
	local primaryAmmoCount = owner:GetAmmoCount(primaryAmmo)
	need = need or self:GetMaxClip1() - self:Clip1()
	need = math.min(primaryAmmoCount, need)
	need = math.min(need, self:GetMaxClip1())
	self:SetClip1(self:Clip1() + need)
	owner:SetAmmo(primaryAmmoCount - need, primaryAmmo)

	if SERVER then
		net.Start("hg_insertAmmo")
			net.WriteEntity(self)
			net.WriteInt(self:Clip1(),10)
		net.Broadcast()
	end
end

if CLIENT then
	net.Receive("hg_insertAmmo",function()
		local ent = net.ReadEntity()
		local ammo = net.ReadInt(10)
		if IsValid(ent) then
			ent:SetClip1(ammo)
		end
	end)
end

SWEP.ReloadCooldown = 0.1
local math_min = math.min
function SWEP:ReloadEnd()
	self:InsertAmmo(self:GetMaxClip1() - self:Clip1() + (self.drawBullet ~= nil and not self.OpenBolt and 1 or 0))
	self.ReloadNext = CurTime() + self.ReloadCooldown --я хуй знает чо это
	self:Draw()
end

function SWEP:Step_Reload(time)
	if self:KeyDown(IN_WALK) and self:KeyDown(IN_RELOAD) then
		self.checkingammo = true
	else
		self.checkingammo = false
	end

	local time2 = self.reload
	
	if time2 and time2 < time then
		self.reload = nil
		self:ReloadEnd()
	else
		self:ClearAnims()
	end

	if time2 then
		local part = 1.15 - (time2 - time) / (self.StaminaReloadTime or 0.5)

		if SERVER then
			self:ReloadSounds(part)
		end

		part = math.ease.InOutQuad(part)

		if self:AnimationReload(part) then
			time2 = nil
			self.reload = nil
			self:ReloadEnd()
		end
	end

	time2 = self.ReloadNext
	if time2 and time2 < time then
		self.ReloadNext = nil
		self.dwr_reverbDisable = nil
	end
end

SWEP.ReloadAnimLH = {
	Vector(0,0,0)
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0)
}

SWEP.ReloadAnimLHAng = {
	Angle(0,0,0)
}

SWEP.ReloadAnimRHAng = {
	Angle(0,0,0),
}

SWEP.ReloadAnimWepAng = {
	Angle(0,0,0)
}

SWEP.ReloadSlideAnim = {
	0,
}

SWEP.WepAngOffset = Angle(0,0,0)
SWEP.ReloadSlideOffset = 0

local vecZero,angZero = Vector(0,0,0),Angle(0,0,0)

SWEP.vel = Vector(0,0,0)
SWEP.vel2 = Vector(0,0,0)
SWEP.angvel = Angle(0,0,0)

function SWEP:ClearAnims()
	if not self.reload and not self.inspect then
		local deltatime = FrameTime()
		local lerp = hg.lerpFrameTime2(0.1,deltatime)
		if not self.LHPosOffset:IsEqualTol(vecZero, 0.1) then self.LHPosOffset = Lerp(lerp,self.LHPosOffset,vecZero) end
		if not self.LHAngOffset:IsEqualTol(angZero, 0.1) then self.LHAngOffset = Lerp(lerp,self.LHAngOffset,angZero) end
		if not self.inanim then
			if not self.RHPosOffset:IsEqualTol(vecZero, 0.1) then self.RHPosOffset = Lerp(lerp,self.RHPosOffset,vecZero) end
			if not self.RHAngOffset:IsEqualTol(angZero, 0.1) then self.RHAngOffset = Lerp(lerp,self.RHAngOffset,angZero) end
		end
		if not self.WepAngOffset:IsEqualTol(vecZero, 0.1) then
			self.WepAngOffset = Lerp(lerp,self.WepAngOffset,angZero)
		else
			self.WepAngOffset:Set(angZero)
		end
		self.ReloadSlideOffset = Lerp(FrameTime()*15,self.ReloadSlideOffset,0)

		if not self.WepAngOffset:IsEqualTol(vecZero, 0.1) then self.angvel = Lerp(deltatime,self.angvel,angZero) else
			self.angvel:Set(angZero)
		end
		self.SndReloadCD = 0
	end
end

local function easedLerp(fraction, from, to)
	return Lerp(math.ease.InOutSine(fraction), from, to)
end

function SWEP:AnimationReload(time)
	local wep = self--weapons.GetStored( self:GetClass() )
	
	local anims = wep.ReloadAnimLH
	local anims2 = wep.ReloadAnimLHAng
	local floortime = math.floor(time * (#anims))
	local floortime2 = math.floor(time * (#anims2))
	local lerp = time * (#anims) - floortime
	local lerp2 = time * (#anims2) - floortime2
	
	local pos1,pos2 = anims[math.Clamp(floortime,1,#anims)],anims[math.Clamp(floortime+1,1,#anims)]
	
	if pos2 == "fastreload" then
		if self:Clip1() > 0 then
			self:ClearAnims()
			return true
		else
			pos2 = anims[math.Clamp(floortime+2,1,#anims)]
		end
	elseif pos1 == "fastreload" then
		if self:Clip1() > 0 then
			self:ClearAnims()
			return true
		else
			pos1 = anims[math.Clamp(floortime+1,1,#anims)]
		end
	elseif pos2 == "reloadend" then
		self:ClearAnims()
		return true
	elseif pos1 == "reloadend" then
		self:ClearAnims()
		return true
	end

	self.LHPosOffset = easedLerp(lerp,pos1,pos2)

	self.LHAngOffset = easedLerp(lerp2,anims2[math.Clamp(floortime2,1,#anims2)],anims2[math.Clamp(floortime2+1,1,#anims2)])

	local anims = wep.ReloadAnimRH
	local anims2 = wep.ReloadAnimRHAng
	local floortime = math.floor(time * (#anims))
	local floortime2 = math.floor(time * (#anims2))
	local lerp = time * (#anims) - floortime
	local lerp2 = time * (#anims2) - floortime2
	
	local pos1,pos2 = anims[math.Clamp(floortime,1,#anims)],anims[math.Clamp(floortime+1,1,#anims)]

	if pos2 == "fastreload" then
		if self:Clip1() > 0 then
			self:ClearAnims()
			return true
		else
			pos2 = anims[math.Clamp(floortime+2,1,#anims)]
		end
	elseif pos1 == "fastreload" then
		if self:Clip1() > 0 then
			self:ClearAnims()
			return true
		else
			pos1 = anims[math.Clamp(floortime+1,1,#anims)]
		end
	elseif pos2 == "reloadend" then
		self:ClearAnims()
		return true
	elseif pos1 == "reloadend" then
		self:ClearAnims()
		return true
	end

	self.RHPosOffset = easedLerp(lerp,pos1,pos2)

	self.RHAngOffset = easedLerp(lerp2,anims2[math.Clamp(floortime2,1,#anims2)],anims2[math.Clamp(floortime2+1,1,#anims2)])

	local anims2 = wep.ReloadAnimWepAng
	local floortime2 = math.floor(time * (#anims2))
	local lerp2 = time * (#anims2) - floortime2

	--self.WepPosOffset = Lerp(lerp,anims[math.Clamp(floortime,1,#anims)],anims[math.Clamp(floortime+1,1,#anims)])
	local ang1,ang2 = anims2[math.Clamp(floortime2,1,#anims2)],anims2[math.Clamp(floortime2+1,1,#anims2)]
	
	local oldang = -(-self.WepAngOffset)
	
	self.WepAngOffset = easedLerp(lerp2,ang1,ang2) + self.angvel

	--self.angvel:Add((self.WepAngOffset-oldang)/2)
	--self.angvel = self.angvel * 0.99
	if CLIENT and self:GetOwner() == LocalPlayer() and self.reload then
		local addang = (self.WepAngOffset-oldang)/12
		addang[3] = addang[3] / 12
		ViewPunch2(addang)
		ViewPunch(addang)
	end

	local anims2 = wep.ReloadSlideAnim
	local floortime2 = math.floor(time * (#anims2))
	local lerp2 = time * (#anims2) - floortime2
	local num1,num2 = anims2[math.Clamp(floortime2,1,#anims2)],anims2[math.Clamp(floortime2+1,1,#anims2)]
	
	
	self.ReloadSlideOffset = easedLerp(lerp2,num1,num2)
end

SWEP.ReloadSoundes = {
	"none"
}
SWEP.SndReloadCD = 0

function SWEP:ReloadSounds(time)
	local sounds = self.ReloadSoundes
	local floortime2 = math.floor(time * (#sounds))

	if sounds and sounds[floortime2] and self.SndReloadCD != floortime2 and sounds[floortime2] != "none" and (SERVER or self:IsLocal()) then
		self:EmitSound( sounds[floortime2], 55, math.random(98,102), 0.5, CHAN_AUTO )
		self.SndReloadCD = floortime2
	end
end

function SWEP:ReloadStartPost()
end

if SERVER then return end
net.Receive("hgwep reload", function()
	local self = net.ReadEntity()
	local time = net.ReadFloat()
	if self and self.SetClip1 then self:SetClip1(net.ReadInt(10)) end
	self.StaminaReloadTime = net.ReadFloat()
	if self.Reload then self:Reload(time) end
end)

function SWEP:Reload(time)
	time = time or CurTime()
	if not time then return end
	self.LastReload = time
	self:ReloadStart()
	self:ReloadStartPost()
	self.StaminaReloadTime =  self.ReloadTime * ( IsValid( self:GetOwner() ) and self:GetOwner().organism and self:GetOwner().organism.stamina and 2 -(self:GetOwner().organism.stamina / 180 ) or 1 )
	self.reload = time + (self.StaminaReloadTime or self.ReloadTime)
	self.dwr_reverbDisable = true
end

function SWEP:ReloadStart()
	if not IsValid(self:GetOwner()) then return end
	--self:SetHold(self.ReloadHold or self.HoldType)
	--self:GetOwner():SetAnimation(PLAYER_RELOAD)
end