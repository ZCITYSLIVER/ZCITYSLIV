-- "addons\\homigrad-weapons\\lua\\weapons\\homigrad_base\\sh_bullet.lua"
AddCSLuaFile()
--
local surface_hardness = {
	[MAT_METAL] = 1,
	[MAT_COMPUTER] = 0.9,
	[MAT_VENT] = 0.9,
	[MAT_GRATE] = 0.9,
	[MAT_FLESH] = 0.5,
	[MAT_ALIENFLESH] = 0.3,
	[MAT_SAND] = 0.1,
	[MAT_DIRT] = 0.9,
	[74] = 0.1,
	[85] = 0.2,
	[MAT_WOOD] = 0.5,
	[MAT_FOLIAGE] = 0.5,
	[MAT_CONCRETE] = 0.9,
	[MAT_TILE] = 0.8,
	[MAT_SLOSH] = 0.05,
	[MAT_PLASTIC] = 0.3,
	[MAT_GLASS] = 0.6,
}

local player_GetAll = player.GetAll
local function BulletEffects(tr, self)
end

if SERVER then
	util.AddNetworkString("bullet_fell")
	util.AddNetworkString("blood particle")
	BulletEffects = function(tr, self)
		--[[net.Start("bullet_fell")
		net.WriteTable(tr)
		net.WriteEntity(self)
		net.Broadcast()--]]
	end
end

local function BloodTr(att, tr, dmgInfo)
	--util.Decal("Impact.Flesh",tr.HitPos + tr.HitNormal,tr.HitPos - tr.HitNormal)
	if SERVER then
		net.Start("blood particle")
		net.WriteVector(tr.StartPos)
		net.WriteVector((tr.HitPos - tr.StartPos):GetNormalized() * dmgInfo:GetDamage() * 2 + VectorRand(-50, 50))
		net.Broadcast()
	end
end
local bulletHit
local hg_bulletholes = GetConVar("hg_bulletholes") or CreateClientConVar("hg_bulletholes", "150", true, false, "0-500, amount of bullet hole effects (r6s-like)", 0, 500)
local function callbackBullet(self, tr, dmg, force, bullet)
	if CLIENT then return end
	if not bullet.penetrated then return end
	if bullet.penetrated > 6 then return end
	bullet.penetrated = bullet.penetrated + 1
	if tr.Entity.organism then return end
	
	local dir, hitNormal, hitPos = tr.Normal, tr.HitNormal, tr.HitPos
	if SERVER then BulletEffects(tr, self) end
	local hardness = surface_hardness[tr.MatType] or 0.5
	local ApproachAngle = -math.deg(math.asin(hitNormal:DotProduct(dir)))
	local MaxRicAngle = 60 * hardness
	-- all the way through
	--print(ApproachAngle > MaxRicAngle * 0.7  )
	if ApproachAngle > MaxRicAngle * 0.7 then--or tr.Entity:IsVehicle() then
		local Pen = (bullet.Penetration or 5) * 3 or dmg
		local MaxDist, SearchPos, SearchDist, Penetrated = Pen / hardness * 0.4, hitPos, 5, false
		
		local hit
		while not Penetrated and SearchDist < MaxDist do
			SearchPos = hitPos + dir * SearchDist
			local PeneTrace = util.QuickTrace(SearchPos, -dir * SearchDist)
			if not PeneTrace.StartSolid and PeneTrace.Hit then
				Penetrated = true
				hit = PeneTrace
				bullet.Penetration = bullet.Penetration - Pen * SearchDist / MaxDist / 3
			else
				SearchDist = SearchDist + 5
			end
		end
		
		if CLIENT then
			if Penetrated then				
				local ent = IsValid(tr.Entity) and tr.Entity or Entity(0)
				if #hg.bulletholes > hg_bulletholes:GetInt() then table.remove(hg.bulletholes,1) table.remove(hg.bulletholes,1) end
				local hitPos2,dir2 = WorldToLocal(hitPos,dir:Angle(),ent:GetPos(),ent:GetAngles())
				local _,hitNormal2 = WorldToLocal(hitPos,hitNormal:Angle(),ent:GetPos(),ent:GetAngles())
				table.insert(hg.bulletholes,{hitPos2,dir2,SearchDist,hitNormal2,Pen,ent})
				local hitPos2,dir2 = WorldToLocal(hit.HitPos,(-dir):Angle(),ent:GetPos(),ent:GetAngles())
				local _,hitNormal2 = WorldToLocal(hit.HitPos,hit.HitNormal:Angle(),ent:GetPos(),ent:GetAngles())
				table.insert(hg.bulletholes,{hitPos2,dir2,SearchDist,hitNormal2,Pen,ent})
				hg.addBulletHoleEffect(hitPos)
				hg.addBulletHoleEffect(hit.HitPos)
				--return true
			end
			--return false
		end
		--print(Penetrated)
		if Penetrated then--or tr.Entity:IsVehicle() then
			--[[self:FireLuaBullets({
				Attacker = self:GetOwner(),
				Damage = 0,
				Force = 0,
				Num = 1,
				Tracer = 0,
				TracerName = "nil",
				Dir = -dir,
				Spread = Vector(0, 0, 0),
				Src = SearchPos + dir,
				DisableLagComp = true,
				Filter = {},
				Distance = SearchPos
				--Penetration = bullet.Penetration,
				--Diameter = bullet.Diameter 
				--Callback = bulletHit
			},true)--]]
			ParticleEffect( "impact_dirt", SearchPos, dir:Angle() )
			util.Decal("Impact.Concrete",SearchPos + dir*5, SearchPos - dir*15)
			local tBullet = {
				Attacker = self:IsNPC() and self or self:GetOwner(),
				Damage = dmg * 0.65,
				Force = force / 3,
				Num = 1,
				Tracer = 0,
				TracerName = "nil",
				Dir = dir,
				Spread = Vector(0, 0, 0),
				Src = SearchPos + dir,
				Callback = bulletHit,
				DisableLagComp = true,
				Filter = {},
				Penetration = bullet.Penetration,
				Diameter = bullet.Diameter,
				penetrated = bullet.penetrated,
				dmgtype = bullet.dmgtype or DMG_BULLET,
				NpcShoot = bullet.NpcShoot
			}

			self.bullet = tBullet

			self:FireLuaBullets( tBullet )
			
			local tr = util.TraceLine( {
				start = SearchPos + dir,
				endpos = SearchPos + dir * 10000,
				mask = MASK_SHOT
			} )
			timer.Simple(0.1,function()
				local effectdata1 = EffectData()
				effectdata1:SetOrigin(tr.HitPos)
				effectdata1:SetStart(hitPos + hitNormal)
				effectdata1:SetEntity(self)
				effectdata1:SetMagnitude(2)
				util.Effect("eff_tracer", effectdata1)
			end)
		end
	elseif ApproachAngle < MaxRicAngle * .2 and math.random(10) > 1 then
		--if CLIENT then return end
		-- ping whiiiizzzz
		sound.Play("snd_jack_hmcd_ricochet_" .. math.random(1, 2) .. ".wav", hitPos, 75, math.random(90, 100))
		local NewVec = dir:Angle()
		NewVec:RotateAroundAxis(hitNormal, 180)
		NewVec = NewVec:Forward()
		local tBullet = {
			Attacker = self:GetOwner(),
			Damage = (dmg or 1) * .85,
			Force = force / 3,
			Num = 1,
			Tracer = 0,
			TracerName = "nil",
			Dir = -NewVec,
			Spread = Vector(0, 0, 0),
			Src = hitPos + hitNormal,
			Callback = bulletHit,
			DisableLagComp = true,
			Filter = {},
			Penetration = bullet.Penetration,
			Diameter = bullet.Diameter,
			penetrated = bullet.penetrated,
			dmgtype = bullet.dmgtype or DMG_BULLET
		}
		
		self.bullet = tBullet

		self:FireLuaBullets( tBullet )
		
		local tr = util.TraceLine( {
			start = hitPos + hitNormal,
			endpos = hitPos + hitNormal + -NewVec * 10000,
			mask = MASK_SHOT
		} )
		timer.Simple(.1,function()
			local effectdata1 = EffectData()
			effectdata1:SetOrigin(tr.HitPos)
			effectdata1:SetStart(hitPos + hitNormal)
			effectdata1:SetEntity(self)
			effectdata1:SetMagnitude(2)
			util.Effect("eff_tracer", effectdata1)
		end)
	elseif math.random(2) == 1 then
		if CLIENT then return end
		local effectdata1 = EffectData()
		effectdata1:SetOrigin(hitPos)
		effectdata1:SetNormal(tr.Normal)
		effectdata1:SetStart(tr.HitNormal)
		effectdata1:SetEntity(self)
		effectdata1:SetFlags(2)
		effectdata1:SetMagnitude(4)
		util.Effect("eff_bulletdrop", effectdata1)
	end
end

function SWEP:CallbackBullet(self, tr)
	return callbackBullet(self, tr)
end

local potatopc
if CLIENT then
	potatopc = GetConVar("hg_potatopc") or CreateClientConVar("hg_potatopc", "0", true, false, "enable this if you are noob", 0, 1)
end

bulletHit = function(ply, tr, dmgInfo, bullet)
	if CLIENT then return end
	local inflictor = not ply:IsNPC() and ply:GetActiveWeapon() or dmgInfo:GetInflictor()
	local dmg, force = dmgInfo:GetDamage(), dmgInfo:GetDamage()--dmgInfo:GetDamageForce():Length()
	
	--[[local effectdata = EffectData()
	effectdata:SetOrigin( tr.HitPos )
	effectdata:SetEntity( tr.Entity )
	effectdata:SetStart( tr.StartPos )
	effectdata:SetSurfaceProp( tr.SurfaceProps )
	effectdata:SetDamageType( dmgInfo:GetDamageType() )
	effectdata:SetHitBox( tr.HitBox )
	util.Effect( "Impact", effectdata )--]]

	if tr.MatType == MAT_FLESH then
		util.Decal("Impact.Flesh", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal)
	end

	timer.Simple(0,function()
		callbackBullet(inflictor, tr, dmg, force, bullet)
	end)
end

hg.bulletHit = bulletHit
hg.callbackBullet = callbackBullet

local bullet = {}
local empty = {}
local vecCone = Vector(0, 0, 0)
local cone, att, att2, owner, primary, ang
local math_Rand, math_random = math.Rand, math.random
local gun
function SWEP:GetWeaponEntity()
	return IsValid(self.worldModel) and self.worldModel or self
end

SWEP.attPos = Vector(0, 0, 0)
SWEP.attAng = Angle(0, 0, 0)
local gun
local vecZero = Vector(0, 0, 0)
local angZero = Angle(0, 0, 0)
local attTbl = {
	Pos = vecZero,
	Ang = angZero
}

function SWEP:GetMuzzleAtt(ent, trueAtt, supressorAdd)
	local owner = IsValid(self) and self:GetOwner() or ent:GetOwner() or ent
	--do return {Pos=Vector(0,0,0),Ang=Angle(0,0,0)} end
	gun = ent or self:GetWeaponEntity()
	if not IsValid(gun) then return attTbl end

	if SERVER then 
		if owner:IsNPC() then 
			attTbl.Pos = owner:EyePos()
			attTbl.Ang = owner:GetAimVector():Angle()
			return attTbl 
		end
	end

	--if true then return {Pos = self.desiredPos or vector_origin,Ang = self.desiredAng or angle_zero} end

	local att = gun:GetAttachment(gun:LookupAttachment("muzzle"))
	local att = att ~= nil and att or gun:GetAttachment(gun:LookupAttachment("muzzle_flash"))
	--local att = gun:GetAttachment(gun:LookupAttachment("muzzle"))
	--local att = att!=nil and att or gun:GetAttachment(gun:LookupAttachment("muzzle_flash"))
	local attPos = self.attPos
	local attAng = self.attAng

	if not att then
		local angHuy = gun:GetAngles()
		local posHuy = gun:GetPos()
		
		angHuy:RotateAroundAxis(angHuy:Forward(), 90)
		local _,angHuy = LocalToWorld(vecZero,attAng,vecZero,angHuy)
		
		posHuy:Add(angHuy:Up() * attPos[1] + angHuy:Right() * attPos[2] + angHuy:Forward() * attPos[3])
		if supressorAdd and self:HasAttachment("barrel", "supressor") then posHuy:Add(angHuy:Forward() * 10) end
		attTbl.Pos = posHuy
		attTbl.Ang = angHuy
		return attTbl
	end
	
	if trueAtt then
		local pos, ang = att.Pos, att.Ang
		
		local pos, ang = LocalToWorld(attPos, attAng, pos, ang)
		
		att.Pos = pos
		att.Ang = ang
		ang:RotateAroundAxis(ang:Forward(),self.rotatehuy or 0)
		
		--ang:Add(attAng)
		if supressorAdd and self:HasAttachment("barrel", "supressor") then pos:Add(ang:Forward() * 10) end
		--pos:Add(ang:Up() * attPos[1] + ang:Right() * attPos[2] + ang:Forward() * attPos[3])
	end

	return att
end

local tr = {}
local att
local util_TraceLine = util.TraceLine

function SWEP:GetTrace(bCacheTrace,desiredPos,desiredAng)
	if not bCacheTrace and self.cache_trace and not (desiredPos or desiredAng) then return self.cache_trace[1],self.cache_trace[2],self.cache_trace[3] end
	local owner = self:GetOwner()
	if owner:IsNPC() then local att = self:GetMuzzleAtt() return nil,SERVER and owner:GetShootPos() or att.Pos,SERVER and owner:GetAimVector():Angle() or att.Ang end
	local muzzle_local_pos,muzzle_local_ang = self:GetLocalHuynyis()
	
	local gun = self:GetWeaponEntity()
	if not IsValid(gun) then return end

	local gunpos,gunang

	if CLIENT then
		gunpos,gunang = desiredPos or self.desiredPos,desiredAng or self.desiredAng
	else
		if desiredPos then 
			gunpos,gunang = desiredPos,desiredAng
		else
			gunpos,gunang = self:WorldModel_Transform(true)
		end
	end

	gunpos = gunpos or gun:GetPos()
	gunang = gunang or gun:GetAngles()

	local pos,ang

	if self.LocalMuzzlePos then
		pos,ang = LocalToWorld(self.LocalMuzzlePos,self.LocalMuzzleAng,gunpos,gunang)
	else
		pos,ang = self:GetRealDebilAttachment(muzzle_local_pos,muzzle_local_ang)
	end
	
	local dir = ang:Forward()

	local fake = CLIENT and owner.FakeRagdoll or nil
	tr.start = pos
	tr.endpos = pos + dir * 8000
	tr.filter = {gun, not owner.suiciding and owner or NULL,fake}

	if bCacheTrace then self.cache_trace = {util_TraceLine(tr),pos,ang} end

	return util_TraceLine(tr),pos,ang
end

SWEP.ShellEject = "EjectBrass_556"
SWEP.MuzzleEffectType = 1


local images_muzzle = {
	[2] = {"effects/muzzleflash1", "effects/muzzleflash2", "effects/muzzleflash3", "effects/muzzleflash4"},
	[3] = {"effects/gunshipmuzzle","effects/combinemuzzle2"}
}
local vecZero = Vector(0, 0, 0)
local image_distort = "sprites/heatwave"

SWEP.PPSMuzzleEffect = "pcf_jack_mf_mpistol" -- shared in sh_effects.lua
SWEP.PPSMuzzleEffectSuppress = "pcf_jack_mf_suppressed"

function SWEP:GetLocalHuynyis()
	local gun = self:GetWeaponEntity()
	local owner = self:GetOwner()

	local atth = gun:GetAttachment(gun:LookupAttachment("muzzle"))
	local atth = atth ~= nil and atth or gun:GetAttachment(gun:LookupAttachment("muzzle_flash"))
	
	local att2 = self:GetMuzzleAtt(gun,false)
	local muzzle_local_pos,muzzle_local_ang = WorldToLocal(att2.Pos,att2.Ang,gun:GetPos(),gun:GetAngles())
	if atth then
		muzzle_local_pos,muzzle_local_ang = LocalToWorld(self.attPos,self.attAng,muzzle_local_pos,muzzle_local_ang)
	end
	if not IsValid(owner.FakeRagdoll) then
		muzzle_local_ang:RotateAroundAxis(muzzle_local_ang:Up(),-(self.rotatehuy or 0))
	end

	return muzzle_local_pos,muzzle_local_ang
end

function SWEP:GetRealDebilAttachment(muzzle_local_pos,muzzle_local_ang)
	if not IsValid(owner) then return end
	local gun = self:GetWeaponEntity()
	local owner = self:GetOwner()
	local eyeang = owner:GetAimVector():Angle()
	eyeang[3] = eyeang[3] + (owner:EyeAngles()[3])
	local eyeang = eyeang + (self.weaponAngLerp or angZero)
	local _,ang2 = LocalToWorld(vector_origin,muzzle_local_ang,vector_origin,eyeang)
	local pos,ang = LocalToWorld(muzzle_local_pos,muzzle_local_ang,gun:GetPos(),gun:GetAngles())
	local angh = (owner.suiciding or IsValid(owner.FakeRagdoll)) and ang or ang2

	return pos,angh
end

function SWEP:FireBullet()
    local gun = self:GetWeaponEntity()
    local owner = self:GetOwner()
	local ent = owner
	
	if owner:IsPlayer() then
    	ent = hg.GetCurrentCharacter(owner)
	end
    local ammotype = hg.ammotypeshuy[self.Primary.Ammo].BulletSettings
    
    local att = self:GetMuzzleAtt(gun, true)
    if not att then return end
    local pos, ang = att.Pos, att.Ang
    if not owner:IsPlayer() and not owner:IsNPC() then return end
    local fakeGun = self:GetNWEntity("fakeGun")

    local primary = self.Primary

	self:WorldModel_Transform()
	local tr,pos,ang = self:GetTrace(true)

	if owner:IsPlayer() then
		--owner:LagCompensation(true)
	end

    local dir = ang:Forward()

	local dist, point = util.DistanceToLine(pos, pos - dir * 50, owner:EyePos())
	local tr = {}
	tr.start = point
	tr.endpos = pos
	tr.filter = {owner,ent,self.fakeGun,SERVER and hg.ragdollFake[owner]}
	local trace = util.TraceLine(tr)

    local numbullet = ammotype.NumBullet or 1
	
	local head = ent:GetBoneMatrix(ent:LookupBone("ValveBiped.Bip01_Head1"))
	
	--[[local enta = ents.Create("prop_physics")
	enta:SetModel("models/props_c17/lampShade001a.mdl")
	enta:SetPos(head:GetTranslation() + head:GetAngles():Forward() * 15)
	enta:Spawn()
	enta:SetSolidFlags(FSOLID_NOT_SOLID)
	enta:GetPhysicsObject():EnableMotion(false)--]]
	
    local bullet = {}
    bullet.Src = (head:GetTranslation() + head:GetAngles():Forward() * -0.5)
	bullet.Dir = (att.Ang:Forward())
	bullet.Attacker = owner

	if owner:IsNPC() and CLIENT then
		local npcYawOffset = math.Remap( owner:GetPoseParameter("aim_yaw"),0,1,-60,60 )
		local npcPitchOffset = math.Remap( owner:GetPoseParameter("aim_pitch"),0,1,-88,50 )
		bullet.Dir = (owner:GetAngles()+AngleRand(-4,4)+Angle(npcPitchOffset,npcYawOffset,0)):Forward() 
	end

	bullet.Force = ammotype.Force or primary.Force
    bullet.Damage = ammotype.Damage or primary.Damage or 25
	bullet.Damage = bullet.Damage * (self.Supressor and 0.9 or 1) * (self.DamageMultiplier or 1)

	bullet.Spread = (ammotype.Spread or self.Primary.Spread or 0) * 3
	bullet.Num = 1
	
	bullet.AmmoType = primary.Ammo
	bullet.TracerName = self.Tracer or "nil"
    bullet.IgnoreEntity = nil
    bullet.Callback = bulletHit

    bullet.Speed = ammotype.Speed
	bullet.Distance = ammotype.Distance or 56756
	bullet.Filter = {not owner.suiciding and owner or nil, owner:IsPlayer() and owner:InVehicle() and owner:GetVehicle() or nil, owner:IsPlayer() and owner:GetSimfphys() or nil}
	bullet.Inflictor = self

    local tr = {}
    for i = 1, numbullet do
        if true then
			local bullet = table.Copy(bullet)
			bullet.penetrated = 0
			bullet.Penetration = (ammotype.Penetration or (-(-self.Penetration))) * (self.PenetrationMultiplier or 1)
			bullet.Diameter = ammotype.Diameter or 1

			--[[
				local pen = (IsValid(bullet) and bullet.Penetration) or dmg / 2
				local size = IsValid(bullet) and (bullet.PenetrationSize or pen / 50)
				local maxpen = IsValid(bullet) and bullet.MaxPenLen or 0
				print(bullet.Penetration)
				local shockMul = IsValid(bullet) and bullet.ShockMultiplier or 1
				local bleedMul = IsValid(bullet) and bullet.BleedMultiplier or 1
				local painMul = IsValid(bullet) and bullet.PainMultiplier or 1
				local immobilizationMul = IsValid(bullet) and bullet.ImmobilizationMul or 1
				local hurtMul = IsValid(bullet) and bullet.HurtMultiplier or 1
				BulletSettings = {
					Damage = 44,
					Force = 44,
					Penetration = 16,
					Shell = "556x45",
					Speed = 860,
					Diameter = 5.56,
					Mass = 4,
				}
			]]

			if(hg.PhysBullet and self.UsePhysBullets)then
				if(SERVER)then
					hg.PhysBullet.CreateBullet(bullet)
				end
			else
				self:FireLuaBullets(bullet)

				if CLIENT and not GetGlobalBool("PhysBullets_ReplaceDefault") then
					local tr,pos = self:GetTrace()
					
					if tr then
						local effectdata1 = EffectData()
						if tr.HitPos then effectdata1:SetOrigin(tr.HitPos) end
						if tr.StartPos then effectdata1:SetStart(pos) end
						effectdata1:SetEntity(self)
						effectdata1:SetMagnitude(1)
						util.Effect("eff_tracer", effectdata1)
					end
				end
			end

			if owner:IsPlayer() then
				--owner:LagCompensation(false)
			end
		end
    end

	if CLIENT then
		local tr,pos,ang = self:GetTrace()
		local mul = self.MuzzleMul or 1
		mul = mul * (self.Supressor and 0.25 or 1)
		if mul > 0 then
			if not potatopc:GetBool() then

				--local emitter = ParticleEmitter(pos)
				--local particle = emitter:Add(image_distort, pos)
				if particle then
					--particle:SetVelocity((ang:Forward() * 25) + 1.05 * owner:GetVelocity())
					--particle:SetLifeTime(0)
					--particle:SetDieTime(math.Rand(0.1, 0.2))
					--particle:SetStartAlpha(255)
					--particle:SetEndAlpha(0)
					--particle:SetStartSize(math.Rand(7, 10))
					--particle:SetEndSize(0)
					--particle:SetRoll(math.Rand(0, 360))
					--particle:SetRollDelta(math.Rand(-2, 2))
					--particle:SetAirResistance(5)
					--particle:SetGravity(Vector(0, 0, 40))
					--particle:SetColor(255, 255, 255)
				end

				if not self.Supressor then 
					if self.MuzzleEffectType > 1 then
						local particle = emitter:Add(images_muzzle[self.MuzzleEffectType][math.random(#images_muzzle[self.MuzzleEffectType])], pos)

						if particle then
							particle:SetVelocity( 1.05 * owner:GetVelocity())
							particle:SetLifeTime(0)
							particle:SetDieTime(math.Rand(0.05 ,0.1))
							particle:SetStartAlpha(math.Rand(155, 255))
							particle:SetEndAlpha(0)
							particle:SetStartSize(math.Rand(5, 10))
							particle:SetEndSize(math.Rand(15, 20))
							particle:SetLighting(false)
							particle:SetColor(255, 255, 255)
						end
					else
						--[[local effectdata = EffectData()
						effectdata:SetOrigin(att.Pos + (self.Supressor and (att.Ang:Forward() * 15) or vecZero))
						effectdata:SetAngles(ang)
						effectdata:SetScale(mul / 2) 
						effectdata:SetEntity(self)
						effectdata:SetFlags( self.ShootEffect or 1 )
				
						util.Effect(self.ShootEffect and "MuzzleFlash" or "MuzzleEffect", effectdata)--]]
						
						local particle = ParticleEffect(self.PPSMuzzleEffect,pos,ang,self)
						if particle then
							--particle:SetControlPoint( 2, Vector(0.5,0.5,0.5))
						end
					end
				else
					local particle = ParticleEffect(self.PPSMuzzleEffectSuppress,pos,ang,self)
				end

				local dlight = DynamicLight(self:EntIndex())
				dlight.pos = pos
				dlight.r = math_random(245, 255)
				dlight.g = math_random(245, 255)
				dlight.b = math_random(150, 200)
				dlight.brightness = math_Rand(7, 8)
				dlight.Decay = 4000
				dlight.Size = math_Rand(60, 75) * mul
				dlight.DieTime = CurTime() + 1 / 60
			end
		end
	end

	self:PostFireBullet(bullet)
end

function SWEP:PostFireBullet()
end

if CLIENT then
	net.Receive("reject shell",function()
		local ent = net.ReadEntity()
		if ent and ent.RejectShell then
			ent:RejectShell(net.ReadString())
		end
	end)

	function SWEP:RejectShell(shell)
		if not shell then return end
		local gun = self:GetWeaponEntity()
		if not IsValid(gun) then return end
		local attmuzle = self:GetMuzzleAtt(gun, true)
		local att = gun:GetAttachment(gun:LookupAttachment("ejectbrass")) or gun:GetAttachment(gun:LookupAttachment("shell"))
		local pos, ang
		if not att then
			pos, ang = gun:GetPos(), gun:GetAngles()
		else
			pos, ang = att.Pos, att.Ang
		end

		local _
		if gun == self:GetNWEntity("fakeGun") then shell = shell ~= "ShotgunShellEject" and "ShellEject" or "ShotgunShellEject" end
		if self.EjectPos then pos = gun:GetPos() + ang:Right() * self.EjectPos.x + ang:Up() * self.EjectPos.z + ang:Forward() * self.EjectPos.y end
		if self.EjectAng then _,ang = LocalToWorld(vecZero,self.EjectAng,vecZero,ang) end

		local ammotype = hg.ammotypeshuy[self.Primary.Ammo].BulletSettings
		local ejectAng = attmuzle.Ang
		if self.EjectAddAng then
			_,ejectAng = LocalToWorld(vecZero,self.EjectAddAng,vecZero,attmuzle.Ang) 
		end
		if self.CustomSecShell then self:MakeShell(self.CustomSecShell, pos, ejectAng, ang:Forward() * 75) end
		if ammotype.Shell or self.CustomShell then self:MakeShell(ammotype.Shell or self.CustomShell, pos, ejectAng, ang:Forward() * 105) return end
		local effectdata = EffectData()
		effectdata:SetOrigin(pos)
		effectdata:SetAngles(ang)
		effectdata:SetFlags(25)
		util.Effect(shell, effectdata)
	end
else
	util.AddNetworkString("reject shell")
	function SWEP:RejectShell(shell)
		net.Start("reject shell")
			net.WriteEntity(self)
			net.WriteString(shell)
		net.Broadcast()
	end
end