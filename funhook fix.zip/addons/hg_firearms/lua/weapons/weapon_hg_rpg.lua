-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_hg_rpg.lua"

SWEP.Base = "homigrad_base"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "RPG-7"
SWEP.Author = "Degtyarev plant"
SWEP.Instructions = "The RPG-7 is a portable unguided shoulder-launched anti-tank rocket launcher."
SWEP.Category = "Weapons - Grenade Launchers"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/tfa_ins2/w_rpg.mdl"

SWEP.WepSelectIcon2 = Material("vgui/inventory/weapon_rpg7")
SWEP.IconOverride = "vgui/inventory/weapon_rpg7"

SWEP.weight = 6
SWEP.ScrappersSlot = "Primary"

SWEP.weaponInvCategory = 1
SWEP.ShellEject = ""
SWEP.Primary.ClipSize = 1
SWEP.Primary.DefaultClip = 1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "RPG-7 Projectile"--rpg rounds
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 1
SWEP.Primary.Sound = {"snd_jack_impulse.wav", 75, 90, 100}
SWEP.Primary.Force = 75
SWEP.Primary.Wait = 2
SWEP.ReloadTime = 2.3
SWEP.DeploySnd = {"weapons/ins2rpg7/handling/rpg7_fetch.wav", 75, 100, 110}
SWEP.HolsterSnd = {"weapons/ins2rpg7/handling/rpg7_endgrab.wav", 75, 100, 110}
SWEP.HoldType = "rpg"
SWEP.ZoomPos = Vector(-7 + 3, 0.9 - 0, 20)
SWEP.RHandPos = Vector(0,0,0)
SWEP.LHandPos = false--Vector(13,0,0)
SWEP.Ergonomics = 0.5
SWEP.WorldPos = Vector(0,-2,-3)
SWEP.WorldAng = Angle(0, 0, 0)
SWEP.UseCustomWorldModel = true
SWEP.attPos = Vector(0,-3,13)
SWEP.attAng = Angle(0,0,0)
SWEP.lengthSub = 25
SWEP.DistSound = "weapons/ins2rpg7/rpg7_dist.wav"
SWEP.holsteredBone = "ValveBiped.Bip01_Spine2"
SWEP.holsteredPos = Vector(0,-4,0)
SWEP.holsteredAng = Angle(0, 0, 0)
SWEP.OpenBolt = true
SWEP.SprayRand = {Angle(-0.05, -0.01, 0), Angle(-0.1, 0.01, 0)}
SWEP.SprayRandOnly = true
SWEP.Penetration = 10
SWEP.ReloadSound = "weapons/tfa_hl2r/rpg/rpg_reload1.wav"
SWEP.ReloadHold = "pistol"
SWEP.AnimShootMul = 5
SWEP.AnimShootHandMul = 5
SWEP.addSprayMul = 1
SWEP.ReloadTime = 5
SWEP.CanSuicide = false
SWEP.ShootAnimMul = 8
SWEP.punchmul = 8
SWEP.punchspeed = 6
SWEP.podkid = 1
--local to head
SWEP.RHPos = Vector(14,-6,7)
SWEP.RHAng = Angle(0,0,90)
--local to rh
SWEP.LHPos = Vector(-6,0,-4.5)
SWEP.LHAng = Angle(-0,0,-100)

function SWEP:Shoot(override)
	if not self:CanPrimaryAttack() then return false end
	if not self:CanUse() then return false end
	if self:Clip1() == 0 then return end
	local primary = self.Primary
	if not self.drawBullet then
		self.LastPrimaryDryFire = CurTime()
		self:PrimaryShootEmpty()
		primary.Automatic = false
		return false
	end

	if primary.Next > CurTime() then return false end
	if (primary.NextFire or 0) > CurTime() then return false end
	primary.Next = CurTime() + primary.Wait
	self:SetLastShootTime(CurTime())
	primary.Automatic = weapons.Get(self:GetClass()).Primary.Automatic
	
    local gun = self:GetWeaponEntity()
	local att = self:GetMuzzleAtt(gun, true)
	--self:GetOwner():Kick("lol")
	self:TakePrimaryAmmo(1)
	if SERVER then
		local projectile = ents.Create("rpg_projectile")
		projectile:SetPos(att.Pos + att.Ang:Forward() * 0 + att.Ang:Right() * -6)
		projectile:SetAngles(att.Ang)
		projectile:SetOwner(self:GetOwner():InVehicle() and self:GetOwner():GetVehicle() or self:GetOwner())
		projectile:Spawn()
		projectile.Penetration = -(-self.Penetration)

		local phys = projectile:GetPhysicsObject()
		if IsValid(phys) then
			phys:SetVelocity(self:GetOwner():GetVelocity() + att.Ang:Forward() * 200)
		end
		for i,ent in pairs(ents.FindInCone(att.Pos, -att.Ang:Forward(), 128, 0.8)) do
			if not ent:IsPlayer() then continue end
			if ent == hg.GetCurrentCharacter( self:GetOwner() ) then return end
			local d = DamageInfo()
			d:SetDamage( 400 )
			d:SetAttacker( self:GetOwner() )
			d:SetDamageType( DMG_BURN ) 

			ent:TakeDamageInfo( d )
		end
	end

	self:EmitShoot()
	self:PrimarySpread()
	self:GetWeaponEntity():SetBodygroup(1,1)
	self:SetBodygroup(1,1)
end

if CLIENT then
	function SWEP:ReloadStart()
		if not self or not IsValid(self:GetOwner()) then return end
		hook.Run("HGReloading", self)
		self:SetHold(self.ReloadHold or self.HoldType)
		self:GetOwner():SetAnimation(PLAYER_RELOAD)
		if self.ReloadSound then self:GetOwner():EmitSound(self.ReloadSound, 60, 100, 0.8, CHAN_AUTO) end
	end

	function SWEP:ReloadEnd()
		self:GetWeaponEntity():SetBodygroup(1,0)
		self:SetBodygroup(1,0)

		self:InsertAmmo(1)
		self.ReloadNext = CurTime() + self.ReloadCooldown
		self:Draw()
	end

	function SWEP:Unload()
		if SERVER then return end
		
		self:GetWeaponEntity():SetBodygroup(1,1)
		self:SetBodygroup(1,1)
	end

	function SWEP:InitializePost()
		self:GetWeaponEntity():SetBodygroup(1,self:Clip1() == 1 and 0 or 1)
		self:SetBodygroup(1,self:Clip1() == 1 and 0 or 1)
	end

	function SWEP:OwnerChanged()
		self:GetWeaponEntity():SetBodygroup(1,self:Clip1() == 1 and 0 or 1)
		self:SetBodygroup(1,self:Clip1() == 1 and 0 or 1)
	end
end

SWEP.CanSuicide = false

-- RELOAD ANIM AKM
SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(17,2,3),
	Vector(14,0,3),
	Vector(10,1,3),
	Vector(-1,-2,-7),
	Vector(-1,-2,-7),
	Vector(-1,-1,-7),
	Vector(-1,-1,-7),
	"reloadend",
	Vector(0,0,0),
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0)
}

SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0),
	Angle(0,0,0)
}

SWEP.ReloadAnimRHAng = {
	Angle(0,0,0),
}

SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(0,5,25),
	Angle(0,5,25),
	Angle(5,5,25),
	Angle(3,5,25),
	Angle(0,0,0)
}

-- Inspect Assault
SWEP.LocalMuzzlePos = Vector(26.986,-0.2,2.741)
SWEP.LocalMuzzleAng = Angle(-0.3,0,90)
SWEP.WeaponEyeAngles = Angle(0,0,0)
SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(-15,35,5),
	Angle(-15,35,14),
	Angle(-15,34,16),
	Angle(-16,36,15),
	Angle(-15,34,16),
	Angle(-10,25,-15),
	Angle(-2,22,-15),
	Angle(0,25,-22),
	Angle(0,24,-45),
	Angle(0,22,-45),
	Angle(0,20,-35),
	Angle(0,0,0)
}