-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_doublebarrel_short.lua"

SWEP.Base = "weapon_m4super"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "Sawed-off IZh-43" -- сам ты дабл баррел
SWEP.Author = "Izhevsk Mechanical Plant"
SWEP.Instructions = "Illegally sawed-off version of IZH-43. Chambered in 12/70"
SWEP.Category = "Weapons - Shotguns"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/tfa_ins2/w_doublebarrel_sawnoff.mdl"

SWEP.WepSelectIcon2 = Material("entities/tfa_ins2_doublebarrel_sawnoff.png")
SWEP.WepSelectIcon2box = true
SWEP.IconOverride = "entities/tfa_ins2_doublebarrel_sawnoff.png"

SWEP.addSprayMul = 2
SWEP.ShellEject = false
SWEP.ScrappersSlot = "Primary"
SWEP.CustomShell = "12x70"
SWEP.weight = 3
SWEP.weaponInvCategory = 1
SWEP.Primary.ClipSize = 2
SWEP.Primary.DefaultClip = 2
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "12/70 gauge"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 16
SWEP.Primary.Spread = Vector(0.04, 0.04, 0.04)
SWEP.Primary.Force = 12
SWEP.Primary.Sound = {"weapons/tfa_ins2/doublebarrel_sawnoff/doublebarrelsawn_fire.wav", 80, 100, 75}
SWEP.Primary.Wait = 0
SWEP.OpenBolt = true

SWEP.cameraShakeMul = 0.25

SWEP.LocalMuzzlePos = Vector(18.893,0.388,1.648)
SWEP.LocalMuzzleAng = Angle(0,0,90)
SWEP.WeaponEyeAngles = Angle(0,0,0)

SWEP.Chocking = false 

SWEP.punchmul = 1
SWEP.punchspeed = 0.1

SWEP.ReloadDrawTime = 0
SWEP.ReloadDrawCooldown = 0
SWEP.ReloadInsertTime = 0.02
SWEP.ReloadInsertCooldown = 0.2
SWEP.ReloadInsertCooldownFire = 0.2

SWEP.NumBullet = 8
SWEP.AnimShootMul = 2
SWEP.AnimShootHandMul = 10
SWEP.ReloadSound = "weapons/tfa_ins2/doublebarrel/shellinsert1.wav"
SWEP.DeploySnd = {"homigrad/weapons/draw_hmg.mp3", 55, 100, 110}
SWEP.HolsterSnd = {"homigrad/weapons/hmg_holster.mp3", 55, 100, 110}
SWEP.HoldType = "ar2"
SWEP.ZoomPos = Vector(-0.8, 0, 30)
SWEP.RHandPos = Vector(-15, -2, 4)
SWEP.LHandPos = false
SWEP.SprayRand = {Angle(-0.5, -0.2, 0), Angle(-1, 0.2, 0)}
SWEP.Ergonomics = 0.95
SWEP.Penetration = 7
SWEP.WorldPos = Vector(4, -1, -2)
SWEP.WorldAng = Angle(0, 0, 0)
SWEP.UseCustomWorldModel = true
SWEP.attPos = Vector(-19, 0.2, 0)
SWEP.attAng = Angle(0, 0, 0)
SWEP.lengthSub = 20
SWEP.DistSound = "toz_shotgun/toz_dist.wav"

SWEP.IsPistol = false
SWEP.podkid = 2
SWEP.animposmul = 3
SWEP.ReloadTime = 1.2

SWEP.ReloadHold = "pistol"

function SWEP:AnimHoldPost(model)
	self:BoneSetAdd(1, "l_finger0", Vector(0, 0, 0), Angle(0, -28, 0))
	self:BoneSetAdd(1, "l_finger02", Vector(0, 0, 0), Angle(0, 20, 0))

    self:BoneSetAdd(1, "r_finger0", Vector(0, 0, 0), Angle(-5, -5, 50))
end

function SWEP:ReloadStartPost()
	if not self or not IsValid(self:GetOwner()) then return end
	self.reloadMiddle = CurTime() + self.ReloadTime / 2
end
SWEP.Shooted = 0
function SWEP:Shoot(override)
	--self:GetWeaponEntity():ResetSequenceInfo()
	--self:GetWeaponEntity():SetSequence(1)
	if not self:CanPrimaryAttack() then return false end
	if not self:CanUse() then return false end
	if CLIENT and self:GetOwner() != LocalPlayer() and not override then return false end
	local primary = self.Primary

	if primary.Next > CurTime() then return false end
	if (primary.NextFire or 0) > CurTime() then return false end
    if not self.drawBullet or (self:Clip1() == 0 and not override) then
		self.LastPrimaryDryFire = CurTime()
		self:PrimaryShootEmpty()
		primary.Automatic = false
		return false
	end
    self.Shooted = self.Shooted + 1
	
	primary.Next = CurTime() + primary.Wait
	self:SetLastShootTime(CurTime())
	self:PrimaryShoot()
	self:PrimaryShootPost()
end

function SWEP:Step()
	self:CoreStep()
	local owner = self:GetOwner()
	if not IsValid(owner) or not IsValid(self) then return end
	if CLIENT then
		if self.reloadMiddle and self.reloadMiddle < CurTime() then
            if self.Shooted > 0 then
				local ammotype = hg.ammotypes[string.lower( string.Replace( self.Primary and self.Primary.Ammo or "nil"," ", "") )].BulletSettings
			    self:MakeShell(ammotype.Shell, owner:GetBonePosition(owner:LookupBone("ValveBiped.Bip01_L_Hand")), Angle(0,0,0), Vector(0,0,0)) 
                self:EmitSound("weapons/tfa_ins2/doublebarrel/shelleject1.wav",70,100,1,CHAN_AUTO)
                self.Shooted = self.Shooted - 1
            end
			self.reloadMiddle = nil
		end
	end
end

--local to head
SWEP.RHPos = Vector(3,-4,3.5)
SWEP.RHAng = Angle(0,0,90)
--local to rh
SWEP.LHPos = Vector(15,-1,-3.7)
SWEP.LHAng = Angle(-110,-90,-90)
function SWEP:AnimationPost()
	self:BoneSetAdd(1, "l_finger0", Vector(0, 0, 0), Angle(30, 30, 0))
	self:BoneSetAdd(1, "l_finger02", Vector(0, 0, 0), Angle(-10, 30, 0))
end

-- RELOAD ANIM AKM
SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(-2,-5,-5),
	Vector(-2,-5,-5),
	Vector(-2,-5,-12),
	Vector(-2,-4,-8),
	Vector(-2,1,-7),
	Vector(-2,1,-7),
	Vector(-2,1,-5),
	Vector(0,0,0),
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0)
}

SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(0,0,180),
	Angle(0,0,180),
	Angle(0,0,180),
	Angle(0,0,180),
	Angle(0,0,180),
	Angle(0,0,0),
}

SWEP.ReloadAnimRHAng = {
	Angle(0,0,0),
}

SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(2,5,0),
	Angle(2,5,0),
	Angle(5,10,0),
	Angle(5,10,0),
	--Angle(0,0,0)
}

function SWEP:GetAnimPos_Insert(time)
	return 0
end

function SWEP:GetAnimPos_Draw(time)
	return 0
end

-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(-5,15,5),
	Angle(-5,15,15),
	Angle(-5,14,16),
	Angle(-7,16,18),
	Angle(-7,14,20),
	Angle(-6,15,-15),
	Angle(-2,12,-15),
	Angle(0,15,-22),
	Angle(0,14,-45),
	Angle(0,12,-45),
	Angle(0,10,-35),
	Angle(0,0,0)
}