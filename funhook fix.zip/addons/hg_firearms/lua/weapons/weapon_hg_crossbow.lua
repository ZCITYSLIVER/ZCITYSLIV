-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_hg_crossbow.lua"

SWEP.Base = "homigrad_base"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "Homemade Crossbow"
SWEP.Author = "Unknown"
SWEP.Instructions = "A rather weighty homemade crossbow that shoots red-hot armature.\nHas very high damage"
SWEP.Category = "Weapons - Other"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/zcity/weapons/w_crossbow.mdl"

SWEP.WepSelectIcon2 = Material("vgui/wep_jack_hmcd_crossbow")
SWEP.IconOverride = "vgui/wep_jack_hmcd_crossbow"
SWEP.ScrappersSlot = "Primary"
SWEP.weaponInvCategory = 1
SWEP.ShellEject = ""
SWEP.Primary.ClipSize = 1
SWEP.Primary.DefaultClip = 1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "Armature"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 1
SWEP.Primary.Sound = {"weapons/crossbow/fire1.wav", 75, 90, 100}
SWEP.Primary.Force = 25
SWEP.Primary.Wait = 0.1
SWEP.ReloadTime = 4.3
SWEP.DeploySnd = {"weapons/crossbow/crossbow_deploy.wav", 55, 100, 110}
SWEP.HolsterSnd = {"snds_jack_gmod/ez_weapons/amsr/in.wav", 45, 100, 110}
SWEP.HoldType = "ar2"
SWEP.ZoomPos = Vector(-2.3, 26, 0)
SWEP.RHandPos = Vector(0,0,0)
SWEP.LHandPos = Vector(13,0,0)
SWEP.Ergonomics = 0.8
SWEP.WorldPos = Vector(0,1.1,-1)
SWEP.WorldAng = Angle(2, 0, 0)
SWEP.UseCustomWorldModel = true
SWEP.attPos = Vector(0,0,2)
SWEP.attAng = Angle(-90,0,0)
SWEP.lengthSub = 25
SWEP.DistSound = ""
SWEP.holsteredBone = "ValveBiped.Bip01_Spine2"
SWEP.holsteredPos = Vector(15,-5,6)
SWEP.holsteredAng = Angle(170, -5, 90)
SWEP.OpenBolt = true
SWEP.SprayRand = {Angle(-0.05, -0.01, 0), Angle(-0.1, 0.01, 0)}
SWEP.SprayRandOnly = true
SWEP.scopedef = true

SWEP.mat = Material("models/weapons/v_crossbow_new/v_crossbow_lens")
SWEP.scopemat = Material("decals/scope.png")
SWEP.perekrestie = Material("vgui/arc9_eft_shared/reticles/scope_30mm_march_tactical_3-24x42_marks.png")
SWEP.sizeperekrestie = 4200

SWEP.handsAng = Angle(-5, -1, 0)

SWEP.localScopePos = Vector(-14,-0.12,2.35)
SWEP.scope_blackout = 700
SWEP.rot = 0
SWEP.FOVMin = 10
SWEP.FOVMax = 20
SWEP.perekrestieSize = false
SWEP.blackoutsize = 3100

SWEP.ReloadSound = "weapons/crossbow/reload1.wav"
SWEP.ReloadSoundes = {
	"none",
	"weapons/tfa_hl2r/crossbow/crossbow_deploy.wav",
	"none",	
	"weapons/tfa_hl2r/crossbow/bolt_load2.wav",
	"none",
	"weapons/tfa_hl2r/ar2/weapon_movement1.wav",
	"none",
	"none",
	"none"
}
SWEP.AnimShootMul = 2
SWEP.AnimShootHandMul = 5
SWEP.addSprayMul = 2

SWEP.Penetration = 40

SWEP.weight = 3


function SWEP:Shoot(override)
	if not self:CanPrimaryAttack() then return false end
	if not self:CanUse() then return false end
	if self:Clip1() == 0 then return end
	local primary = self.Primary
	if not self.drawBullet then
		self.LastPrimaryDryFire = CurTime()
		self:PrimaryShootEmpty()
		primary.Automatic = false
		return false
	end
	local owner = self:GetOwner()
	if primary.Next > CurTime() then return false end
	if (primary.NextFire or 0) > CurTime() then return false end
	primary.Next = CurTime() + primary.Wait
	self:SetLastShootTime(CurTime())
	primary.Automatic = weapons.Get(self:GetClass()).Primary.Automatic
	
	local tr,pos,ang = self:GetTrace(true)
	local owner = self:GetOwner()
	
	if SERVER then
		local dist, point = util.DistanceToLine(pos, pos - ang:Forward() * 50, owner:EyePos())

		--if(GetGlobalBool("PhysBullets_ReplaceDefault", false))then
		local bullet = {}
			-- bullet.Num = 1
		bullet.Pos = point
		bullet.Dir = ang:Forward()
		bullet.Speed = 110
			-- bullet.Force = ammotype.Force or primary.Force
		bullet.Damage = 350
		bullet.Force = 10
			-- bullet.Size = 0.5
			-- bullet.Spread = ammotype.Spread or self.Primary.Spread or 0
		bullet.AmmoType = "Armature"
		bullet.Attacker = owner.suiciding and Entity(0) or owner
		bullet.IgnoreEntity = not owner.suiciding and (owner.InVehicle and owner:InVehicle() and owner:GetVehicle() or owner) or nil
			-- bullet.Callback = bulletHit
			-- bullet.TracerName = self.Tracer or "nil"
			-- bullet.Speed = ammotype.Speed
			-- bullet.Distance = ammotype.Distance or 56756
		bullet.Penetration = 10

		hg.PhysBullet.CreateBullet(bullet)
			-- self:FireBullets(bullet)
		--else
		--	local projectile = ents.Create("crossbow_projectile")
		--	projectile:SetPos(point)
		--	projectile:SetAngles(ang)
		--	projectile:Spawn()
		--	projectile.Penetration = -(-self.Penetration)
--
		--	local phys = projectile:GetPhysicsObject()
		--	if IsValid(phys) then
		--		phys:SetVelocity(self:GetOwner():GetVelocity() + ang:Forward() * 9000)
		--	end
		--end
	end

	self:EmitShoot()
	self:PrimarySpread()
	self:TakePrimaryAmmo(1)
	self:GetWeaponEntity():SetBodygroup(1,1)
	self:SetBodygroup(1,1)
end

if CLIENT then
	function SWEP:DrawHUDAdd()
		self:DoRT()
	end

	function SWEP:ReloadStart()
		if not self or not IsValid(self:GetOwner()) then return end
		hook.Run("HGReloading", self)
		--self:SetHold(self.ReloadHold or self.HoldType)
		--self:GetOwner():SetAnimation(PLAYER_RELOAD)
	end

	function SWEP:ReloadEnd()
		self:GetWeaponEntity():SetBodygroup(1,0)
		self:SetBodygroup(1,0)

		self:InsertAmmo(1)
		self.ReloadNext = CurTime() + self.ReloadCooldown
		self:Draw()
	end

	function SWEP:InitializePost()
		self:GetWeaponEntity():SetBodygroup(1,self:Clip1() == 1 and 0 or 1)
		self:SetBodygroup(1,self:Clip1() == 1 and 0 or 1)
	end

	function SWEP:OwnerChanged()
		self:GetWeaponEntity():SetBodygroup(1,self:Clip1() == 1 and 0 or 1)
		self:SetBodygroup(1,self:Clip1() == 1 and 0 or 1)
	end
end

function SWEP:AnimHoldPost(model)

end

SWEP.LocalMuzzlePos = Vector(25.041,2.587,3.508)
SWEP.LocalMuzzleAng = Angle(2.264,0,10.02)
SWEP.WeaponEyeAngles = Angle(-2,0,0)

SWEP.CanSuicide = false

--local to head
SWEP.RHPos = Vector(5.5,-7.5,4)
SWEP.RHAng = Angle(0,-5,90)
--local to rh
SWEP.LHPos = Vector(14,-1,-5)
SWEP.LHAng = Angle(-90,-90,-90)

local finger1 = Angle(-15,0,5)
local finger2 = Angle(-15,45,-5)

--RELOAD ANIMS PISTOL

SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(-7,10,-10),
	Vector(-2,-5,0),
	Vector(1,-9,5),
	Vector(1,-7,0),
	"reloadend",
	Vector(-4,-1,0),
	Vector(0,0,0),
	Vector(0,0,0)
}
SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(-180,180,0),
	Angle(-180,180,-45),
	Angle(-180,180,15),
	Angle(-185,185,15),
	Angle(-2,5,0),
	Angle(0,0,0),
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0)
}
SWEP.ReloadAnimRHAng = {
	Angle(0,0,0)
}
SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(-5,16,1),
	Angle(-3,14,2),
	Angle(12,15,-1),
	Angle(-5,14,0),
	Angle(0,16,0),
	Angle(0,-2,-2),
	Angle(0,0,0),
}

-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(15,15,15),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,7,24),
	Angle(10,3,-5),
	Angle(2,3,-15),
	Angle(0,4,-22),
	Angle(0,3,-45),
	Angle(0,3,-45),
	Angle(0,-2,-2),
	Angle(0,0,0)
}