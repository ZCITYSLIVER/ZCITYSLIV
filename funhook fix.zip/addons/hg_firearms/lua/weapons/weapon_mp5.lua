-- "addons\\homigrad-weapons\\lua\\weapons\\weapon_mp5.lua"

SWEP.Base = "homigrad_base"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "HK MP5"
SWEP.Author = "Heckler & Koch"
SWEP.Instructions = "Submachine gun chambered in 9x19 mm\n\nRate of fire 800 rounds per minute"
SWEP.Category = "Weapons - Machine-Pistols"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/zcity/w_mp5_sef.mdl"

SWEP.WepSelectIcon2 = Material("vgui/hud/tfa_ins2_mp5a4.png")
SWEP.IconOverride = "vgui/hud/tfa_ins2_mp5a4.png"

SWEP.CustomShell = "9x19"
--SWEP.EjectPos = Vector(0,-20,5)
--SWEP.EjectAng = Angle(0,90,0)

SWEP.LocalMuzzlePos = Vector(14.706,-0.488,3.525)
SWEP.LocalMuzzleAng = Angle(0.4,-0.1,90)
SWEP.WeaponEyeAngles = Angle(0,0,0)

SWEP.weight = 2.5
SWEP.ScrappersSlot = "Primary"
SWEP.weaponInvCategory = 1
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "9x19 mm Parabellum"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 20
SWEP.Primary.Spread = 0
SWEP.Primary.Force = 20
SWEP.Primary.Sound = {"zcitysnd/sound/weapons/mp5k/mp5k_fp.wav", 75, 120, 130}
SWEP.SupressedSound = {"zcitysnd/sound/weapons/mp5k/mp5k_suppressed_fp.wav", 55, 90, 100}
SWEP.Primary.Wait = 0.07
SWEP.ReloadTime = 4.5
SWEP.ReloadSoundes = {
	"none",
	"none",
	"weapons/kryceks_swep/mp5/boltback.wav",
	"none",
	"none",
	"weapons/kryceks_swep/mp5/magout.wav",
	"none",
	"weapons/kryceks_swep/mp5/magin2.wav",
	"none",
	"weapons/kryceks_swep/mp5/boltslap.wav",
	"none",
	"none",
	"none",
	"none"
}

SWEP.PPSMuzzleEffect = "muzzleflash_mp5" -- shared in sh_effects.lua

SWEP.ShellEject = "EjectBrass_9mm"
SWEP.HoldType = "ar2"
SWEP.ZoomPos = Vector(-2.39,0,30)
SWEP.RHandPos = Vector(0, -1, 0)
SWEP.LHandPos = Vector(7, -2, -2)
SWEP.availableAttachments = {
	barrel = {
		[1] = {"supressor4", Vector(0,0,0), {}},
		[2] = {"supressor6", Vector(0,0,0), {}},
		["mount"] = Vector(-2,0.45,0),
	}
}

SWEP.attPos = Vector(1,0,0)
SWEP.attAng = Angle(-0.02,0,0)

SWEP.Spray = {}
for i = 1, 30 do
	SWEP.Spray[i] = Angle(-0.02 - math.cos(i) * 0.01, math.cos(i * i) * 0.01, 0) * 1
end

SWEP.Ergonomics = 1
SWEP.Penetration = 7
SWEP.WorldPos = Vector(5, -1, -1)
SWEP.WorldAng = Angle(0, 0, 0)
SWEP.UseCustomWorldModel = true
SWEP.lengthSub = 30
SWEP.handsAng = Angle(7, 2, 0)
SWEP.DistSound = "zcitysnd/sound/weapons/mp5k/mp5k_dist.wav"

--local to head
SWEP.RHPos = Vector(3,-7,3.5)
SWEP.RHAng = Angle(0,-8,90)
--local to rh
SWEP.LHPos = Vector(11,1.6,-3)
SWEP.LHAng = Angle(-110,-180,5)

local finger1 = Angle(-15,-22, 20)
local finger2 = Angle(0, 10, 0)
local finger3 = Angle(0, -5, -15)
local finger4 = Angle(-10, -35, 0)
local finger5 = Angle(0, 40, 0)

SWEP.ShootAnimMul = 2

function SWEP:AnimHoldPost(model)
	self:BoneSetAdd(1, "l_finger0", vector_zero, finger1)
	self:BoneSetAdd(1, "l_finger02", vector_zero, finger2)
	self:BoneSetAdd(1, "l_finger1", vector_zero, finger3)
	self:BoneSetAdd(1, "l_finger2", vector_zero, finger4)
	self:BoneSetAdd(1, "l_finger21", vector_zero, finger5)

	if CLIENT and IsValid(model) then
		self.shooanim = LerpFT(0.1,self.shooanim or 0,self:Clip1() > 0 and 0 or 0)
		model:ManipulateBonePosition(8,Vector(0 ,1.8*self.shooanim ,0),false)
		model:ManipulateBonePosition(6,Vector(-0.5*self.ReloadSlideOffset ,0.02*self.ReloadSlideOffset ,-0.02*self.ReloadSlideOffset),false)
		model:ManipulateBoneAngles(7,Angle(-35*self.ReloadSlideOffset/4 ,0 ,0),false)
		--PrintTable(model:GetChildBones())
	end
end


-- RELOAD ANIM AKM
SWEP.ReloadAnimLH = {
	Vector(0,0,0),
	Vector(1,-5,0),
	Vector(1,-5,-5),
	Vector(1,-5,0),
	Vector(-5,2,0),
	Vector(-1,2,-6),
	Vector(-1,2,-6),
	Vector(-1,10,-6),
	Vector(-1,12,-15),
	Vector(-1,5,-6),
	Vector(-1,2,-6),
	Vector(-1,2,-6),
	Vector(-1,2,-6),
	Vector(-1,2,-6),
	Vector(1,-5,-5),
	Vector(1,-5,-3),
	Vector(1,-8,-5),
	Vector(1,-2,-5),
	Vector(0,0,-2),
	"reloadend",
	Vector(0,0,0)
}


SWEP.ReloadSlideAnim = {
	0,
	0,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	0,
	0,
	0
}

SWEP.ReloadAnimRH = {
	Vector(0,0,0)
}

SWEP.ReloadAnimLHAng = {
	Angle(0,0,0),
	Angle(-80,0,110),
	Angle(-80,0,110),
	Angle(-80,0,110),
	Angle(-80,0,110),
	Angle(-80,0,110),
	Angle(-80,0,110),
	Angle(-80,0,120),
	Angle(-80,0,120),
	Angle(-80,0,120),
	Angle(-80,0,120),	
	Angle(0,0,0),
	Angle(0,0,0)
}

SWEP.ReloadAnimRHAng = {
	Angle(0,0,0),
}

SWEP.ReloadAnimWepAng = {
	Angle(0,0,0),
	Angle(-5,0,25),
	Angle(-8,0,20),
	Angle(-5,0,0),
	Angle(5,5,25),
	Angle(-2,5,25),
	Angle(0,5,15),
	Angle(-5,5,5),
	Angle(5,-5,-2),
	Angle(0,0,0),
}

-- Inspect Assault

SWEP.InspectAnimLH = {
	Vector(0,0,0)
}
SWEP.InspectAnimLHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimRH = {
	Vector(0,0,0)
}
SWEP.InspectAnimRHAng = {
	Angle(0,0,0)
}
SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(15,15,15),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,15,24),
	Angle(15,7,24),
	Angle(10,3,-5),
	Angle(2,3,-15),
	Angle(0,4,-22),
	Angle(0,3,-45),
	Angle(0,3,-45),
	Angle(0,-2,-2),
	Angle(0,0,0)
}