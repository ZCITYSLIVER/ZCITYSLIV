-- "addons\\homigrad-weapons\\lua\\entities\\homigrad_gun.lua"

if SERVER then AddCSLuaFile() end
ENT.Type = "anim"
ENT.Author = "huy"
ENT.Category = "ZCity Other"
ENT.PrintName = "gun"
ENT.Spawnable = false
ENT.AdminOnly = true

function ENT:Think()

end