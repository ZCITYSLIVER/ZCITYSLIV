-- "addons\\homigrad-weapons\\lua\\entities\\rpg26_projectile.lua"

if SERVER then AddCSLuaFile() end
ENT.Base = "projectile_base"
ENT.Author = "Sadsalat"
ENT.Category = "ZCity Other"
ENT.PrintName = "Projectile Base"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Model = "models/weapons/fas2/world/explosives/rpg26/rocket.mdl"
ENT.Sound = "fas2/rpg26/rpg26_rockethit.wav"
ENT.SoundFar = "snd_jack_c4splodefar.wav"
ENT.SoundWater = "iedins/water/ied_water_detonate_01.wav"
ENT.Speed = 3000
ENT.TruhstTime = 0.4

ENT.BlastDamage = 200
ENT.BlastDis = 7