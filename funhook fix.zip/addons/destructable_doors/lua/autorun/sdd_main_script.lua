if SERVER then
	CreateConVar("sdd_enable", "1", FCVAR_ARCHIVE, "Enable or disable")
	CreateConVar("sdd_can_destroy_locked_door", "0", FCVAR_ARCHIVE, "Enable or disable")
	CreateConVar("sdd_door_debris_fade_time", "30", FCVAR_ARCHIVE, "sdd_door_debris_fade_time")
	sound.Add( {
		name = "door_destroying",
		channel = CHAN_AUTO,
		volume = 1.0,
		level = 80,
		pitch = { 95, 110 },
		sound = {
			"wood_crate_break1.wav",
			"wood_crate_break2.wav",
			"wood_crate_break3.wav",
			"wood_crate_break4.wav",
			"wood_crate_break5.wav"
			}
	} )
	function make_door_debris_sigma_edition(ent,model,dmginfo)
		local ent4 = ents.Create("prop_physics")
		ent4:SetPos(ent:GetPos() + ent:GetForward() * 3)
		ent4:SetAngles(ent:GetAngles())
		ent4:SetModel(model)
		ent4:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
		ent4:SetSkin(ent:GetSkin())
		ent4:Spawn()
		ent4:EmitSound("door_destroying")
		ent4:TakeDamageInfo(dmginfo)
		SafeRemoveEntityDelayed(ent4,GetConVar("sdd_door_debris_fade_time"):GetFloat())
	end
	hook.Add( "OnEntityCreated", "wastofollowthedamntrainnnnSeeGaye", function( ent )
			if ent:GetClass() == "prop_door_rotating" and GetConVar("sdd_enable"):GetBool() then 
					timer.Simple( 0.01, function() if ent:IsValid() and (ent:GetModel() == "models/props_c17/door01_left.mdl") or (ent:GetModel() == "models/props_doors/door01_dynamic.mdl") then 
					ent.door_Health = 400
					ent.destrutible_door = true
				end 
			end)
		end 
	end )

	hook.Add( "EntityTakeDamage", "wastofollowthedamntrainnnnSeeGaye1", function( ent,dmginfo )
		if ent:GetClass() == "prop_door_rotating" and ent.destrutible_door then  
		if ( ent:GetInternalVariable( "m_bLocked" ) ) == true and GetConVar("SDD_can_destroy_locked_door"):GetBool() == false then
			return
		else
			if dmginfo:IsDamageType(DMG_BLAST) then
				dmginfo:ScaleDamage(3)
			end
			ent.door_Health = ent.door_Health - dmginfo:GetDamage() --do Damage on door
		end

			if ent.door_Health <= 300 and ent.door_Health >= 200 and not ent.gib then
				ent:SetModel("models/noob_dev2323/door/door01_left_damege_01.mdl") 
			end
			if ent.door_Health <= 200 and not ent.gib then
				ent.gib = true
				ent:SetModel("models/noob_dev2323/door/door01_left_damege_02.mdl") 
				ent:EmitSound("door_destroying")
				make_door_debris_sigma_edition(ent,"models/noob_dev2323/door/door_debris_03.mdl",dmginfo)
			end
			if ent.door_Health <= 0 and not ent.breck then
				ent.breck = true
				make_door_debris_sigma_edition(ent,"models/noob_dev2323/door/door_debris_01.mdl",dmginfo)
				make_door_debris_sigma_edition(ent,"models/noob_dev2323/door/door_debris_02.mdl",dmginfo)
				SafeRemoveEntity(ent)
			end
		end
	end )
end
if CLIENT then
    local function Simple_Destructable_Doors()
        spawnmenu.AddToolMenuOption("Options", "Simple_Destructable_Doors", "Simple_Destructable_Doors", "Simple_Destructable_Doors", "", "", function(panel)
            panel:ClearControls()
            panel:Help("--Main Options--")
            panel:CheckBox("sdd enable", "sdd_enable") 
            panel:CheckBox("sdd_can_destroy_locked_door", "sdd_can_destroy_locked_door") 
            panel:NumSlider("sdd door debris fade time", "sdd_door_debris_fade_time", 1, 1000, 0)
        end)
    end
    hook.Add("PopulateToolMenu", "AddSDDSigmaSettings", Simple_Destructable_Doors)
end