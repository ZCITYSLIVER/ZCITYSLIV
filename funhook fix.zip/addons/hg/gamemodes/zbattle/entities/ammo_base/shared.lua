-- \lua\\entities\\ammo_base\\shared.lua"

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.Category = "HG Ammo"
ENT.PrintName = "hg_ammo_base"
ENT.Spawnable = true
ENT.AmmoCount = 10
ENT.AmmoType = "9x19 mm Parabellum" -- 9.19mm parabelum
ENT.Model = "models/zcity/ammo/ammo_9x18_pmm.mdl"
ENT.ModelScale = 1