-- \lua\\entities\\ammo_base\\cl_init.lua"

include("shared.lua")
function ENT:Draw()
	self:SetModel("models/zcity/ammo/ammo_9x18_pmm.mdl")

	self:DrawModel()
end