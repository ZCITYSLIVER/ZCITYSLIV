-- \lua\\entities\\armor_base\\cl_init.lua"

include("shared.lua")
function ENT:Draw()
	self:DrawModel()
end