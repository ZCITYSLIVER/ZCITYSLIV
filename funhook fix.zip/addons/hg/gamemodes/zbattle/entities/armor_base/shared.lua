-- \lua\\entities\\armor_base\\shared.lua"

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "hg_armor_base"
ENT.Spawnable = false
ENT.Model = "models/combataegis/body/ballisticvest_d.mdl"