-- \lua\\entities\\ent_hg_firesmall.lua"

if SERVER then AddCSLuaFile() end
ENT.Base = "ent_hg_fire"
ENT.PrintName = "Fire Small"
ENT.Category = "Разное"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Small = true
ENT.Radius = 50