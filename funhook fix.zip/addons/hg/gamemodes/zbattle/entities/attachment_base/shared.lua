-- \lua\\entities\\attachment_base\\shared.lua"

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "hg_attachment_base"
ENT.Spawnable = false
ENT.Model = "models/weapons/tfa_ins2/upgrades/phy_optic_eotech.mdl"
ENT.SubMatss = {}