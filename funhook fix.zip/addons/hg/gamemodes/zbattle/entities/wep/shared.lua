ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "wep"

ENT.Spawnable = false
DEFINE_BASECLASS( "base_anim" )