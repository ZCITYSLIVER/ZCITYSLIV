include("shared.lua")
include("autorun/loader.lua")

--util.AddNetworkString("CloseEyes")
util.AddNetworkString("hmcd_role")
util.AddNetworkString("round_start")

function GM:PlayerSpawn(ply) 
	ply:Give("weapon_hands_sh")
	ply.Stamina = 100
	ply.Otrub = false
	ply.Fake = false
	ply.Ragdoll = NULL
	ply.HasFlashLight = false 
	ply.IsBleeding = false
	ply.EnableSpectate = false
	ply.SpecMode = false
	ply:SetNWEntity("HeSpectateOn",false)
	ply:UnSpectate()
	ply:RemoveFlags(FL_ONGROUND)
    ply:SetMaterial("")

	ply.organism = {
		["blood"] = 6000,
		["pain"] = 0,
		["pulse"] = 1,
		["meleespeed"] = 0.7,
		["painadd"] = 0,
		["painlosing"] = 1,
		["otrub"] = false,
		["carotartery"] = 1,
		["rartery"] = 1,
		["lartery"] = 1,
		["recoilmul"] = 1,
		["stamina"] = 100,
		["larm"] = 1,
		["rarm"] = 1,
		["brokenribs"] = 0,
		["hunger"] = 0,
		["staminamul"] = 1,
		['brain'] = 5,
		['lungs'] = 40,
		['liver'] = 10,
		['stomach'] = 30,
		['intestines'] = 30,
		['heart'] = 20,
		['spine'] = 5,
		['kidney'] = 2,
		['spleen'] = 4,
		['canmove'] = true
		}
end

function GM:Initialize()
	self:LoadSpawns()
	self.DeathRagdolls = {}
	self:StartNewRound()
	self:LoadMapList()
end

function GM:InitPostEntity()
	self:InitPostEntityAndMapCleanup()
end

function GM:InitPostEntityAndMapCleanup()
	--
end

function GM:PlayerDeathThink(ply)
	local tbl = {}

	for _, ply in ipairs(player.GetAll()) do
		if not ply:Alive() then continue end

		tbl[#tbl + 1] = ply
	end

	local key = ply:KeyDown(IN_RELOAD)
	if key ~= ply.oldKeyWalk and key then
		ply.EnableSpectate = not ply.EnableSpectate
		ply:ChatPrint(ply.EnableSpectate and "Наблюдение за игроками." or "Свободный полёт.")
	end

	ply.oldKeyWalk = key
	ply:SetNWBool("SpecMode",ply.SpecMode)

	local keys = ply:KeyDown(IN_SPEED)
	if keys ~= ply.oldKeyWalk2 and keys and ply.EnableSpectate then
		ply.SpecMode = not ply.SpecMode
		ply:ChatPrint(ply.SpecMode and "Вид от 1-го лица.(Не доделано)" or "Третье лицо.")
	end

	ply.oldKeyWalk2 = keys

	ply.SpectateGuy = ply.SpectateGuy or 0
	if ply.SpectateGuy > #tbl then
		ply.SpectateGuy = #tbl
	end

	if ply.EnableSpectate and ply.SpecMode == false then
		ply:Spectate(OBS_MODE_CHASE)
		local key1 = ply:KeyDown(IN_ATTACK)
		local key2 = ply:KeyDown(IN_ATTACK2)

		if ply.oldKeyAttack1 ~= key1 and key1 then
			ply.SpectateGuy = ply.SpectateGuy + 1
			if ply.SpectateGuy > #tbl then ply.SpectateGuy = 1 end
		elseif ply.oldKeyAttack2 ~= key2 and key2 then
			ply.SpectateGuy = ply.SpectateGuy - 1
			if ply.SpectateGuy == 0 then ply.SpectateGuy = #tbl end
		end

		--ply:ChatPrint(tostring(ply.SpectateGuy))

		local spec = tbl[ply.SpectateGuy]
		if not IsValid(spec) then ply.SpectateGuy = 1 return end
		ply:SetPos(spec:GetPos() + Vector(0,0,50))
		local spec = spec
		ply:SetNWEntity("HeSpectateOn",spec)
		ply:SpectateEntity(spec)
		ply:SetMoveType(MOVETYPE_NONE)
		ply.oldKeyAttack1 = key1
		ply.oldKeyAttack2 = key2
	elseif ply.EnableSpectate and ply.SpecMode == true then
		--ply:Spectate(OBS_MODE_NONE)
		--local key1 = ply:KeyDown(IN_ATTACK)
		--local key2 = ply:KeyDown(IN_ATTACK2)
--
		--if ply.oldKeyAttack1 ~= key1 and key1 then
		--	ply.SpectateGuy = ply.SpectateGuy + 1
		--	if ply.SpectateGuy > #tbl then ply.SpectateGuy = 1 end
		--elseif ply.oldKeyAttack2 ~= key2 and key2 then
		--	ply.SpectateGuy = ply.SpectateGuy - 1
		--	if ply.SpectateGuy == 0 then ply.SpectateGuy = #tbl end
		--end
--
		--local spec = tbl[ply.SpectateGuy]
		--if not IsValid(spec) then ply.SpectateGuy = 1 return end
		--local spec = spec
		--ply:SetPos(spec:GetPos() + Vector(0,0,43) + spec:EyeAngles():Up() * 3 + spec:EyeAngles():Forward() * 110)
		--ply:SetNWEntity("HeSpectateOn",spec)
		--ply:SetMoveType(MOVETYPE_NONE)
		--ply.oldKeyAttack1 = key1
		--ply.oldKeyAttack2 = key2
	else
		ply:UnSpectate()
		ply:SetMoveType(MOVETYPE_NOCLIP)
		ply:SetNWEntity("HeSpectateOn",false)

		if ply:KeyDown(IN_ATTACK) then
			local tr = {}
			tr.start = ply:GetPos()
			tr.endpos = tr.start + ply:GetAimVector() * 128
			tr.filter = ply

			local traceResult = util.TraceLine(tr)
			local bot = traceResult.Entity
		end
	end
end

function GM:PlayerDisconnected(ply) end

function GM:PlayerDeathSound() return true end

local function PlayerCanJoinTeam(ply,teamID)
	local addT,addCT = 0,0
	if teamID == 1 then addT = 1 end
	if teamID == 2 then addCT = 1 end

	local favorT,count = NeedAutoBalance(addT,addCT)

	if count and ((teamID == 1 and favorT) or (teamID == 2 and not favorT)) then
		ply:ChatPrint("Команда полная.")

		return false
	end

	return true
end

function GM:PlayerCanJoinTeam(ply,teamID)
	if teamID == 1002 then ply.NEEDKILLNOW = 1 end
	if ply:Team() == 1002 then ply.NEEDKILLNOW = 2 end
	if teamID == 1002 then return true end

	local result = TableRound().PlayerCanJoinTeam(ply,teamID)
	if result ~= nil then return result end

	local result = PlayerCanJoinTeam(ply,teamID)
	if result ~= nil then return result end
end

function GM:PostPlayerDeath(ply)
	ply:SetPos(ply:GetPos() + Vector(0,0,50))
end

function GM:PlayerInitialSpawn(ply)
	ply.KillSilent = true
	timer.Simple(0.3,function()
		ply:KillSilent()
	end)
end

hook.Add("PlayerInitialSpawn","SetAppearance",function(ply)
    ApplyAppearance(ply)
end)
hook.Add("PreCalcView","PlayerClass",function(ply,vec,ang,fov,znear,zfar)
    return ply:PlayerClassEvent("CalcView",vec,ang,fov,znear,zfar)
end)
hook.Add("PlayerSpawn","SetAppearance",function(ply)
    if PLYSPAWN_OVERRIDE or ply.Fake then return end
    ApplyAppearance(ply)
	ply:Give("weapon_hands_sh")
end)