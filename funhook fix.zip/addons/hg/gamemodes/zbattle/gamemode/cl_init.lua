include("shared.lua")

hook.Add("PreCalcView", "SpectateSystem", function(lply, pos, ang, fov, znear, zfar)
	if lply:Alive() then return end
    lply = LocalPlayer()

    if lply:Alive() or GetViewEntity() ~= lply then return end

    local view = {}

    local spec = lply:GetNWEntity("HeSpectateOn")
    if not IsValid(spec) or not spec:Alive() then
        view.origin = lply:EyePos()
        view.angles = ang
        view.fov = fov
        return view
    end

    spec = IsValid(spec:GetNWEntity("Ragdoll")) and spec:GetNWEntity("Ragdoll") or spec

    view.origin = spec:EyePos()
    view.angles = spec:EyeAngles()
    view.fov = fov

    return view
end)

local gradient_d = Material("vgui/gradient-d")
hook.Add("HUDPaint", "spectate", function()
	local lply = LocalPlayer()
	local spec = lply:GetNWEntity("HeSpectateOn")
	if lply:Alive() then
		if IsValid(flashlight) then
			flashlight:Remove()
			flashlight = nil
		end
	end

	if (((not lply:Alive() or lply:Team() == 1002 or spec and lply:GetObserverMode() ~= OBS_MODE_NONE) or lply:GetMoveType() == MOVETYPE_NOCLIP) and not lply:InVehicle()) or result or hook.Run("CanUseSpectateHUD") then
		local ent = spec
		if IsValid(ent) then
			surface.SetFont("HomigradFont")
			local tw = surface.GetTextSize(ent:GetName())
			draw.SimpleText(ent:GetName(), "HomigradFont", ScrW() / 2 - tw / 2, ScrH() - 100, TEXT_ALING_CENTER, TEXT_ALING_CENTER)
			tw = surface.GetTextSize("Здоровье: " .. ent:Health())
			draw.SimpleText("Здоровье: " .. ent:Health(), "HomigradFont", ScrW() / 2 - tw / 2, ScrH() - 75, TEXT_ALING_CENTER, TEXT_ALING_CENTER)
		end

		local key = lply:KeyDown(IN_WALK)
		if keyOld ~= key and key then
			SpectateHideNick = not SpectateHideNick
		end

		keyOld = key
		draw.SimpleText("Отключение / Включение отображение ников на ALT", "HomigradFont", 15, ScrH() - 15, showRoundInfoColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
		local key = input.IsButtonDown(KEY_F)
		if not lply:Alive() and keyOld2 ~= key and key then
			flashlightOn = not flashlightOn
			if flashlightOn then
				if not IsValid(flashlight) then
					flashlight = ProjectedTexture()
					flashlight:SetTexture("effects/flashlight001")
					flashlight:SetFarZ(900)
					flashlight:SetFOV(70)
					flashlight:SetEnableShadows(false)
				end
			else
				if IsValid(flashlight) then
					flashlight:Remove()
					flashlight = nil
				end
			end
		end

		keyOld2 = key
		if flashlight then
			flashlight:SetPos(EyePos())
			flashlight:SetAngles(EyeAngles())
			flashlight:Update()
		end

		if not SpectateHideNick then
			for _, v in ipairs(player.GetAll()) do --ESP
				if not v:Alive() or v == ent then continue end
				local ent = IsValid(v:GetNWEntity("Ragdoll")) and v:GetNWEntity("Ragdoll") or v
				local screenPosition = ent:GetPos():ToScreen()
				local x, y = screenPosition.x, screenPosition.y
				local teamColor = v:GetPlayerColor():ToColor()
				local distance = lply:GetPos():Distance(v:GetPos())
				local factor = 1 - math.Clamp(distance / 1024, 0, 1)
				local size = math.max(10, 32 * factor)
				local alpha = math.max(255 * factor, 80)
				local text = v:Name()
				surface.SetFont("Trebuchet18")
				local tw, th = surface.GetTextSize(text)
				surface.SetDrawColor(teamColor.r, teamColor.g, teamColor.b, alpha * 0.5)
				surface.SetMaterial(gradient_d)
				surface.DrawTexturedRect(x - size / 2 - tw / 2, y - th / 2, size + tw, th)
				surface.SetTextColor(255, 255, 255, alpha)
				surface.SetTextPos(x - tw / 2, y - th / 2)
				surface.DrawText(text)
				local barWidth = math.Clamp((v:Health() / 100) * (size + tw), 0, size + tw)
				local healthcolor = v:Health() / 100 * 255
				surface.SetDrawColor(255, healthcolor, healthcolor, alpha)
				surface.DrawRect(x - barWidth / 2, y + th / 1.5, barWidth, ScreenScale(1))
			end
		end
	end
end)

surface.CreateFont("HomigradFont",{
	font = "Roboto",
	size = 18,
	weight = 1100,
	outline = false
})

net.Receive("HeadShot", function()
    sound.PlayFile("sound/headshot.wav", "", function(station)
        if IsValid(station) then
            station:SetVolume(2.5)
            station:Play()
        end
    end)
end)

surface.CreateFont( "MersText1" , {
	font = "Tahoma",
	size = 36,
	weight = 1000,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersText2" , {
	font = "coolvetica",
	size = 46,
	weight = 1000,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersHead1" , {
	font = "coolvetica",
	size = 74,
	weight = 500,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersRadial" , {
	font = "coolvetica",
	size = math.ceil(ScrW() / 34),
	weight = 500,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersRadial_QM" , {
	font = "coolvetica",
	size = math.ceil(ScrW() / 38),
	weight = 500,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersRadialS" , {
	font = "coolvetica",
	size = math.ceil(ScrW() / 45),
	weight = 400,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersRadialSemiSuperS" , {
	font = "coolvetica",
	size = math.ceil(ScrW() / 55),
	weight = 125,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersRadialSuperS" , {
	font = "coolvetica",
	size = math.ceil(ScrW() / 80),
	weight = 100,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersRadialBig" , {
	font = "coolvetica",
	size = math.ceil(ScrW() / 24),
	weight = 500,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersRadialSmall" , {
	font = "coolvetica",
	size = math.ceil(ScrW() / 60),
	weight = 100,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersRadialMedium" , {
	font = "coolvetica",
	size = math.ceil(ScrW() / 42),
	weight = 100,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersRadialSmall_QM" , {
	font = "coolvetica",
	size = math.ceil(ScrW() / 80),
	weight = 100,
	antialias = true,
	italic = false
})

surface.CreateFont( "MersDeathBig" , {
	font = "coolvetica",
	size = math.ceil(ScrW() / 18),
	weight = 500,
	antialias = true,
	italic = false
})

surface.CreateFont("HomigradFontBig",{
	font = "Roboto",
	size = 25,
	weight = 1100,
	outline = false,
	shadow = true
})

surface.CreateFont("HomigradFontInv",{
	font = "Roboto",
	size = 15,
	weight = 1100,
	outline = false,
	shadow = true
})

surface.CreateFont("HomigradFontInvSmall",{
	font = "Roboto",
	size = 12,
	weight = 1100,
	outline = false,
	shadow = true
})

surface.CreateFont("HomigradFontInvSmallest",{
	font = "Roboto",
	size = 9,
	weight = 1100,
	outline = false,
	shadow = true
})

surface.CreateFont("HomigradFontLarge",{
	font = "Roboto",
	size = ScreenScale(30),
	weight = 1100,
	outline = false
})

surface.CreateFont("HomigradFontSmall",{
	font = "Roboto",
	size = ScreenScale(10),
	weight = 1100,
	outline = false
})

net.Receive("round_start", function()
    RoundStartTime = CurTime()
	local Music = net.ReadString()

	surface.PlaySound(Music)

    local ply = LocalPlayer()
    ply:ScreenFade(SCREENFADE.IN, Color(0, 0, 0, 255), 1,7)
end)

hook.Add("Initialize", "KysVoiceIcons", function()
	GM = GM or GAMEMODE

	function GM:PlayerStartVoice(ply)
		return
	end
end)

hook.Add("HUDDrawPickupHistory", "KysHistory", function()
	return true 
end)

hook.Add( "HUDItemPickedUp", "KysHistory", function()
    return true
end )

function notification.AddLegacy() return end

net.Receive("hmcd_role",function()
	local role = net.ReadFloat()

	if role == 1 then
		LocalPlayer().RoleT = true
		LocalPlayer().RoleCT = false
	elseif role == 2 then
		LocalPlayer().RoleCT = true
		LocalPlayer().RoleT = false
	else
		LocalPlayer().RoleCT = false
		LocalPlayer().RoleT = false
	end
end)

function RoleGetName()
	if LocalPlayer().RoleT then
		return "Traitor"
	else
		return "Bystander"
	end
end

hook.Add("HUDPaint", "RoundStart", function()
	if not RoundStartTime then return end
	local ply = LocalPlayer()
	local startRound = RoundStartTime + 7 - CurTime()
	local color = (ply.RoleT and Color(200,0,10) or Color(4, 138, 247))
	local name = RoleGetName()
	if startRound > 0 then
		draw.DrawText( "You are an " .. name, "MersText2", ScrW() / 2, ScrH() / 2, Color( color.r,color.g,color.b,math.Clamp(startRound - 0.5,0,1) * 255 ), TEXT_ALIGN_CENTER )
        draw.DrawText( "Homicide | Standart", "MersHead1", ScrW() / 2, ScrH() / 8, Color( 16, 168, 250,math.Clamp(startRound - 0.5,0,1) * 255 ), TEXT_ALIGN_CENTER )
	if ply.RoleCT then
		draw.DrawText( "You have a large-sized weapon, try to neutralize the traitor", "MersRadialMedium", ScrW() / 2, ScrH() / 1.2, Color( 154,31,255,math.Clamp(startRound - 0.5,0,1) * 255 ), TEXT_ALIGN_CENTER )
	elseif ply.RoleT then
		draw.DrawText( "You're geared up with explosives, firearms and melee weapon, murder everyone here before the police arrive.", "MersRadialMedium", ScrW() / 2, ScrH() / 1.2, Color( 212,0,0,math.Clamp(startRound - 0.5,0,1) * 255 ), TEXT_ALIGN_CENTER )
	else
		draw.DrawText( "You are innocent, rely only on yourself, but stick with the crowd to make the traitor's job harder.", "MersRadialSmall", ScrW() / 2, ScrH() / 1.2, Color( 255,255,255,math.Clamp(startRound - 0.5,0,1) * 255 ), TEXT_ALIGN_CENTER )
	end
	end
end)

--[[net.Receive("CloseEyes", function()
    local displayTime = 6.5
    local startTime = CurTime() + 2

    hook.Add("HUDPaint", "TextScreen", function()
        local elapsedTime = CurTime() - startTime
        if elapsedTime > displayTime then
            hook.Remove("HUDPaint", "TextScreen")
            return
        end

        local linearElap = math.Clamp(elapsedTime / displayTime, 0, 1)
        
        local elap = 0.5 - (1 - linearElap) * (1 - linearElap)

        draw.RoundedBox(0, 0, 0, ScrW(), (ScrH() + 100) * elap, Color(0, 0, 0))
        
        draw.RoundedBox(0, 0, ScrH() * (1 - elap), ScrW(), (ScrH() + 100) * elap, Color(0, 0, 0))
    end)
end)]]--
