ROUND_STATE_WAITING = 1
ROUND_STATE_ACTIVE = 2
ROUND_STATE_ENDING = 3
ROUND_ACTIVE = false
ROUND_ENDED = false
TRAITOR = nil
GUNMAN = nil
local TRAITORLOADOUT = {
    "weapon_p22",
    "weapon_sog"
}

local GUNMLOADOUT = {
    "weapon_remington870",
    "weapon_w1894"
}
 
function SetTraitor()
    TRAITOR = table.Random(player.GetAll())
    TRAITOR.RoleT = true

    net.Start("hmcd_role")
    net.WriteFloat(1)--1 traitor/2 gunman
    net.Send(TRAITOR)

    for _, wep in ipairs(TRAITORLOADOUT) do
        local gun = TRAITOR:Give(wep)
    end
    hg.GiveAttachment(TRAITOR, "supressor4")
end

function RetryGun()
    SetGunMan()
end

function SetGunMan()
    local plygun = table.Random(player.GetAll())

    if plygun.RoleT then
        plygun = nil
        RetryGun()
        return
    end

    GUNMAN = plygun
    GUNMAN.RoleCT = true

    net.Start("hmcd_role")
    net.WriteFloat(2)
    net.Send(GUNMAN)

    local gun = GUNMAN:Give(table.Random(GUNMLOADOUT))
end

function StartRound()
    game.CleanUpMap(false)
    ROUND_ENDED = false
    TRAITOR = nil
    for _, ply in ipairs(player.GetAll()) do
        ply:KillSilent()
    end
    for _, ply in ipairs(player.GetAll()) do
        ply:Spawn()
        ply.RoleT = false
        ply.RoleCT = false
    end

    SetTraitor()
    SetGunMan()

    net.Start("round_start")
    net.WriteString("snd_jack_hmcd_shining.mp3")
    net.Broadcast()

    for _, ply in ipairs(player.GetAll()) do
        if ply.RoleT or ply.RoleCT then continue end
        net.Start("hmcd_role")
        net.WriteFloat(0)
        net.Send(ply)
    end

    if roundState == ROUND_STATE_WAITING then
        roundState = ROUND_STATE_ACTIVE
        roundStartTime = CurTime()
        SetRoundTimer()
    end
end

function EndRound(winner)
    if winner == 1 then
    PrintMessage(3,"Traitor wins.")
    timer.Simple(1,function()
        PrintMessage(3,"Traitor was: "..TRAITOR:Name())
    end)
    elseif winner == 2 then
    PrintMessage(3,"All traitors was stopped.")
    timer.Simple(1,function()
        PrintMessage(3,"Traitor was: "..TRAITOR:Name())
    end)    
    else
    PrintMessage(3,"?")
    end
end

function ResetRound()
    roundState = ROUND_STATE_WAITING
end

function SetRoundTimer()
    timer.Create("roundTimer", 1, 0, function()
        if roundState == ROUND_STATE_ACTIVE then
            local timeRemaining = roundTimeLimit - (CurTime() - roundStartTime)
        end
    end)
end

function CheckRoundEndCondition()
    if #player.GetAll() < 2 then return end
    local CTAlive = 0
    local TAlive = 0
    for _, ply in ipairs(player.GetAll()) do
        if ply:Alive() and !ply.RoleT then
            CTAlive = CTAlive + 1
        elseif ply:Alive() and ply.RoleT then
            TAlive = TAlive + 1
        end
    end

    if CTAlive == 0 and not ROUND_ENDED then
        ROUND_ENDED = true
        EndRound(1)
        timer.Simple(5,function()
        ROUND_ACTIVE = false
        end)
    end

    if TAlive == 0 and not ROUND_ENDED then
        ROUND_ENDED = true
        EndRound(2)
        timer.Simple(5,function()
        ROUND_ACTIVE = false
        end)
    end

    if not ROUND_ACTIVE then
        ROUND_ACTIVE = true
        StartRound()
    end
end

hook.Add("Think", "RoundEndCheck", function()
    CheckRoundEndCondition()
end)