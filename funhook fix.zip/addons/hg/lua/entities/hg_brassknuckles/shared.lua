-- "addons\\homigrad\\lua\\entities\\hg_brassknuckles\\shared.lua"

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "hg_brassknuckles"
ENT.Spawnable = true
ENT.Model = "models/hunter/plates/plate025.mdl" --!! PLACEHOLDER
ENT.Color = Color(105,105,95)
ENT.Material = "models/shiny"