-- "addons\\homigrad\\lua\\entities\\zbox_lootbox\\shared.lua"

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "loot_crate"
ENT.Spawnable = true

ENT.Model = "models/kali/props/cases/hard case c.mdl"
ENT.LootTable = {}
ENT.CanGenerate = true