-- "addons\\homigrad\\lua\\entities\\hg_sling\\cl_init.lua"

include("shared.lua")
function ENT:Draw()
	self:DrawModel()
end

function ENT:Think()
end

function ENT:Initialize()
end

function ENT:OnRemove()
end