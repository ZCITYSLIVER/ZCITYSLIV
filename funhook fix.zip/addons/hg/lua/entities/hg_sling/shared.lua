-- "addons\\homigrad\\lua\\entities\\hg_sling\\shared.lua"

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "hg_sling"
ENT.Spawnable = true
ENT.Model = "models/tourniquet/tourniquet.mdl"
ENT.Color = Color(65,55,40)
ENT.Material = "models/shiny"