-- "addons\\homigrad\\lua\\entities\\bomb\\shared.lua"

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "hg_bomb"
ENT.Spawnable = true
ENT.Model = "models/jmod/explosives/bombs/c4/w_c4_planted.mdl"

ENT.ExplodeTime = 90