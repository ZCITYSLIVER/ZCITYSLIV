-- "addons\\homigrad\\lua\\entities\\hg_flashlight\\shared.lua"

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Flashlight"
ENT.Spawnable = true
ENT.Model = "models/runaway911/props/item/flashlight.mdl"
