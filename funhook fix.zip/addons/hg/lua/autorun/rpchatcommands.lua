-- "addons\\homigrad\\lua\\autorun\\rpchatcommands.lua"

if engine.ActiveGamemode() == "zbattle" then -- Now this check is real as Zelensky snort coke. 
    if SERVER then
        util.AddNetworkString("RPChatcmd")
    end

    if CLIENT then
        local commands = {
            ["/qa "] = function(msg)
                return "¿" .. msg .. "?", Color(128, 0, 128) -- 
            end,
            ["!me "] = function(msg)
                return "[Действие] " .. msg, Color(255, 255, 0) 
            end,
            ["/it "] = function(msg)
                return "[Окружение] *" .. msg .. "*", Color(0, 0, 255) 
            end,
            ["/try"] = function(msg)
                return "[Попытка] *" .. msg .. "*", Color(66, 164, 239) 
            end,
            ["/roll"] = function(msg)
				if not isnumber(msg) then return end
				local rnd = math.random(tonumber(msg)) -- Надеюсь сработает, хотя для кого я это делаю...
                return "[Roll] " .. tonumber(rnd) ..  "", Color(66, 164, 239) 
            end
        }

        hook.Add("OnPlayerChat", "RPChatcmd", function(ply, text)
            local cmd = string.lower(string.sub(text, 1, 4))
            local msg = string.sub(text, 6)

            if commands[cmd] then
                local message, color = commandscmd
                net.Start("RPChatcmd")
                net.WriteString(message)
                net.WriteColor(color)
                net.SendToServer()
                return true
            end
        end)
    end

    if SERVER then
        net.Receive("RPChatcmd", function(len, ply)
            local msg = net.ReadString()
            local color = net.ReadColor()

            for _, v in player.Iterator() do
                v:ChatPrint(msg)
                v:ChatPrint(color)
            end
        end)
    end
end
