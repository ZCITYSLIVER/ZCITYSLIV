-- "addons\\homigrad\\lua\\autorun\\shitdecals.lua"

local decalsNormal = {}
local decalsArterial = {}
for i=1, 10 do
    game.AddDecal( "Normal.blood"..i, "decals/z_blood"..i )
    game.AddDecal( "Arterial.blood"..i, "decals/arterial_blood"..i)
end