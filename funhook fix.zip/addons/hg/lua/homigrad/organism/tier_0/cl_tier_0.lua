-- "addons\\homigrad\\lua\\homigrad\\organism\\tier_0\\cl_tier_0.lua"

hg.organism = hg.organism or {}