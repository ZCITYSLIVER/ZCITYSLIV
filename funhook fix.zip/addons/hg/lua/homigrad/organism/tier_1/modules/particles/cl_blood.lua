-- "addons\\homigrad\\lua\\homigrad\\organism\\tier_1\\modules\\particles\\cl_blood.lua"

﻿bloodparticels1 = bloodparticels1 or {}
bloodparticels_hook = bloodparticels_hook or {}

local tr = {
	filter = function(ent) return not ent:IsPlayer() and not ent:IsRagdoll() end
}

local col_red_darker = Color(122,0,0)
local col_red = Color(200,0,0)
local vecDown = Vector(0, 0, -40)
local vecZero = Vector(0, 0, 0)
local LerpVector = LerpVector
local math_random = math.random
local table_remove = table.remove
local util_Decal = util.Decal
local util_TraceLine = util.TraceLine
local render_SetMaterial = render.SetMaterial
local render_DrawSprite = render.DrawSprite

local hg_blood_draw_distance = ConVarExists("hg_blood_draw_distance") and GetConVar("hg_blood_draw_distance") or CreateClientConVar("hg_blood_draw_distance", 1024, true, nil, "distance to draw blood", 0, 4096)
local hg_blood_sprites = ConVarExists("hg_blood_sprites") and GetConVar("hg_blood_sprites") or CreateClientConVar("hg_blood_sprites", 1, true, nil, "blood is sprites or trails", 0, 1)
local lply = LocalPlayer()

hook.Add("PostCleanupMap","removeblooddroplets",function()
	bloodparticels1 = {}
end)

local Wetblood = Material("effects/blood_core")

local mat_huy = Material("sprites/mat_jack_irregularcircle")

bloodparticels_hook[1] = function(anim_pos,mul)
	lply = lply or LocalPlayer()
	local int = hg_blood_draw_distance:GetInt()
	local pos = lply:EyePos()
	for i = 1, #bloodparticels1 do
		local part = bloodparticels1[i]
		if not part then continue end
		if (part[2] - pos):LengthSqr() > math.pow(int,2) then continue end
		--if !hg.isVisible(part[1],LocalPlayer():GetShootPos(),LocalPlayer(),MASK_VISIBLE) then continue end
		--render_SetMaterial(part[4])
		local pos = LerpVector(anim_pos, part[2], part[1])
		
		if (part[4] == Wetblood) or part.kishki or hg_blood_sprites:GetBool() then
			render_SetMaterial(part[4])
			render_DrawSprite(pos, part[5], part[6], color_white)
		else
			render_SetMaterial(mat_huy)
			render.DrawBeam(pos - (part[2] - part[1]) * 0.75 / mul / 24,pos + (part[2] - part[1]) * 0.75 / mul / 24, 1, 0, 1, part[9] or (part.artery and col_red or col_red_darker) )
		end
	end
end

local function decalblood(pos, normal, hitTexture, artery)
	local decal = ( artery and "Arterial.blood" or "Normal.blood")..math_random(10)
	util.Decal(decal, pos + normal, pos - normal, ents.FindInSphere(pos, 1))
end

local tr2 = { collisiongroup = COLLISION_GROUP_WORLD, output = {} }

function util.IsInWorld( pos )
	tr2.start = pos
	tr2.endpos = pos

	return not util.TraceLine( tr2 ).HitWorld
end

bloodparticels_hook[2] = function(mul)
	for i = 1, #bloodparticels1 do
		local part = bloodparticels1[i]
		if not part then break end
		
		local pos = part[1]
		local posSet = part[2]
		--if bit.band( util.PointContents( part[3] ), CONTENTS_WATER ) == CONTENTS_WATER then
		--	mul = 0
		--end
		tr.start = posSet
		tr.endpos = tr.start + part[3] * mul
		--tr.filter = nil
		result = util_TraceLine(tr)
		local hitPos = result.HitPos
		if not util.IsInWorld( hitPos ) then table_remove(bloodparticels1,i) continue end
		
		if result.Hit then
			table_remove(bloodparticels1, i)
			local dir = result.HitNormal
			decalblood(result.HitPos, dir, result.HitTexture, part.artery)
			sound.Play("homigrad/blooddrip" .. math_random(1, 4) .. ".wav", hitPos, math.random(10, 60), math.random(80, 120))
			continue
		else
			pos:Set(posSet)
			posSet:Set(hitPos)
		end

		--if bit.band( util.PointContents( pos ), CONTENTS_WATER ) == CONTENTS_WATER then
		--	part[9] = part[9] or Color(115,0,0,250)
		--	part[9].a = Lerp(0.25,part[9].a or 250, 0)
		--	if part[4]~= Wetblood then part[4] = Wetblood end
		--	part[5] = Lerp(0.01,part[5], 25)
		--	part[6] = Lerp(0.01,part[6], 25)
		--	part[3] = LerpVector(0.25 * 3, part[3], vecZero)
		--	part[8] = part[8] or VectorRand() * 0.5
		--	part[3]:Add((VectorRand() * 1) + part[8])
		--	if part[9].a < 5 then table_remove(bloodparticels1,i) continue end
		--else
			part[3] = LerpVector(0.25 * mul, part[3], vecZero)
			part[3]:Add(vecDown * mul * (math.max(0.1,GetConVar("sv_gravity"):GetInt()/30)))
		--end
	end
end