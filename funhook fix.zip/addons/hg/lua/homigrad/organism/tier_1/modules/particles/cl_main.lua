-- "addons\\homigrad\\lua\\homigrad\\organism\\tier_1\\modules\\particles\\cl_main.lua"

local fps = 1 / 24
local delay = 0
local math_min = math.min
local CurTime, FrameTime = CurTime, FrameTime
bloodparticels_hook = bloodparticels_hook or {}
local bloodparticels_hook = bloodparticels_hook

local hg_blood_fps = ConVarExists("hg_blood_fps") and GetConVar("hg_blood_fps") or CreateClientConVar("hg_blood_fps", 24, true, nil, "fps to draw anims", 12, 165)

hook.Add("PostDrawOpaqueRenderables", "bloodpartciels", function()
	local time = CurTime()
	local fps = 1 / hg_blood_fps:GetInt()
	if not bloodparticels_hook then return end
	local animpos = math_min((delay - time) / fps, 1)
	if not bloodparticels_hook[1] then return end
	
	bloodparticels_hook[1](animpos,fps)
	bloodparticels_hook[3](animpos,fps)

	if delay < time then
		delay = time + fps

		bloodparticels_hook[2](fps)
		bloodparticels_hook[4](fps)
	end
end)

hook.Add("PostCleanupMap","remove_decals",function()
	table.Empty(bloodparticels1)
	table.Empty(bloodparticels2)
end)