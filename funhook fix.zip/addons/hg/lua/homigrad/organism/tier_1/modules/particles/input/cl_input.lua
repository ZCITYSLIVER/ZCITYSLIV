-- "addons\\homigrad\\lua\\homigrad\\organism\\tier_1\\modules\\particles\\input\\cl_input.lua"

local mats = {}
for i = 1, 6 do
	mats[i] = Material("decals/blood" .. i)
end

--local mat_huy = Material("sprites/mat_jack_irregularcircle")
local mat_huy = Material("decals/z_blood1")
local cloudmat = Material("effects/smoke_b")

--оставь это лучше выглядит
--[[for i = 4, 6 do
	mats[i-3] = Material("homigrad/decals/bld" .. i)
end]]
local countmats = #mats
bloodparticels1 = bloodparticels1 or {}
bloodparticels2 = bloodparticels2 or {}
local vecZero = Vector(0, 0, 0)
local function addbloodPart(pos, vel, mat, w, h, artery, kishki)
	if not mat then mat = mat_huy end
	pos = pos + vecZero
	vel = vel + vecZero
	local pos2 = Vector()
	pos2:Set(pos)
	bloodparticels1[#bloodparticels1 + 1] = {pos, pos2, vel, mat, w or 3, h or 3, artery = artery, kishki = kishki}
end

local function addbloodPart2(pos,vel,mat,w,h,time)
	pos = pos + vecZero
	vel = vel + vecZero
	local pos2 = Vector()
	pos2:Set(pos)
	
	bloodparticels2[#bloodparticels2 + 1] = {pos,pos2,vel,mat,w,h,CurTime() + time,time}
end

hg.addbloodPart = addbloodPart
hg.addbloodPart2 = addbloodPart2

net.Receive("blood particle", function() addbloodPart(net.ReadVector(), net.ReadVector(), mats[math.random(#mats)], math.random(2, 3), math.random(2, 3)) end)
local min, max = math.min, math.max
net.Receive("blood particle2", function()
	local ent = net.ReadEntity()
	if not IsValid(ent) then return end
	local wound = net.ReadTable()
	local dir = net.ReadVector()
	local artery = net.ReadBool()
	local bone = wound[4]
	local bonePos, boneAng = ent:GetBonePosition(bone)
	if not wound[2] or not wound[3] or not bonePos or not boneAng then return end
	local pos = LocalToWorld(wound[2], wound[3], bonePos, boneAng)
	local size = math.random(1, 2) * max(min(wound[1], 1), 0.5)
	addbloodPart(pos, dir, mat_huy, size, size, artery)
end)

local Rand = math.Rand
net.Receive("blood particle more", function()
	local pos, vel = net.ReadVector(), net.ReadVector()
	for i = 1, math.random(10, 15) do
		addbloodPart(pos, vel + Vector(Rand(-15, 15), Rand(-15, 15)), mat_huy, math.random(10, 15), math.random(10, 15))
	end
end)

local function impact(pos,vel,mul)
	local max = math.min(mul,8)
	local iters = math.ceil(math.random(1, max) * 2.5)
	for i = 1, iters do
		local size = 1--math.random(2, 4) * 1
		addbloodPart(pos, -vel * i / iters + Vector(Rand(-50, 50) * (i / iters), Rand(-50, 50) * (i / iters), i / iters * 50), mat_huy, size, size)
	end
end

net.Receive("hg_bloodimpact", function()
	local pos = net.ReadVector()
	local vel = net.ReadVector() * 300
	local mul = net.ReadFloat()
	local amt = net.ReadInt(8)
	amt = math.Clamp(amt,0,32)
	for i = 1, amt do impact(pos,vel,mul) end
end)

hook.Add("PostEntityFireBullets","kishki",function(ent,bullet)
	local tr = bullet.Trace
	local hitEnt = tr.Entity
	local dmg = bullet.Damage
	
	if hitEnt.organism then
		--impact(tr.HitPos,tr.Normal * dmg,dmg / 10)
	end
end)

local function explode(pos, size)
	size = size or 1
	local xx, yy = 12, 12
	local w, h = 360 / xx, 360 / yy
	for x = 1, xx * size do
		for y = 1, yy * size do
			addbloodPart2(pos + VectorRand(-10,10),VectorRand(-100,100) * size,cloudmat,25,25,1)
			
			local dir = Vector(0, 0, -1)
			dir:Rotate(Angle(h * y * Rand(0.9, 1.1), w * x * Rand(0.9, 1.1), 0))
			dir[3] = dir[3] + Rand(0.5, 1.5)
			dir:Mul(250 * size)
			addbloodPart(pos, dir, mat_huy, 5, 5, false, true)
		end
	end
end

hg.fountains = hg.fountains or {}
local function fountain(ent,bone,lpos,lang)
	if not IsValid(ent) or (not ent:IsRagdoll() and not ent:IsPlayer()) then return end
	hg.fountains[ent] = {bone = bone,lpos = lpos,lang = lang}

	ent:CallOnRemove("removefountain",function()
		hg.fountains[ent] = nil
	end)
end

net.Receive("addfountain",function()
	local ent = net.ReadEntity()
	
	--local bone = net.ReadInt(8)
	--local lpos = net.ReadVector()
	--local lang = net.ReadAngle()

	if not IsValid(ent) then return end

	local bone = ent:LookupBone("ValveBiped.Bip01_Neck1")
	if bone then
		local mat = ent:GetBoneMatrix(bone)
		if mat then
			explode(mat:GetTranslation() + mat:GetAngles():Forward() * 8,0.5)
			fountain(ent, bone, ThatPlyIsFemale(ent) and Vector(4,0,0) or Vector(5,0,0), Angle(0,0,0))
		end
	end
end)


hg.fountain = fountain

net.Receive("blood particle explode", function() explode(net.ReadVector()) end)
net.Receive("blood particle headshoot", function()
	local pos, vel = net.ReadVector(), net.ReadVector()
	local dir = Vector()
	dir:Set(vel)
	dir:Normalize()
	dir:Mul(25)
	local l1, l2 = pos - dir / 2, pos + dir / 2
	local r = math.random(10, 15)
	for i = 1, r do
		local vel = Vector(vel[1], vel[2], vel[3])
		vel:Rotate(Angle(Rand(-15, 15) * Rand(0.9, 1.1), Rand(-15, 15) * Rand(0.9, 1.1)))
		addbloodPart(Lerp(i / r * Rand(0.9, 1.1), l1, l2), vel, mat_huy, math.random(10, 15), math.random(10, 15))
	end
end)

concommand.Add("testpart", function()
	local pos = Vector(0, 0, 0)
	addbloodPart(pos, Vector(25, 0, 0), mat_huy, math.random(10, 15), math.random(10, 15))
end)