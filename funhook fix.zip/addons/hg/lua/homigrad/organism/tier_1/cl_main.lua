-- "addons\\homigrad\\lua\\homigrad\\organism\\tier_1\\cl_main.lua"

local sounds = {}
for i = 1, 4 do
	sounds[i] = "ambient/water/drip" .. i .. ".wav"
	hg.PrecahceSound(sounds[i]) --garrys mod moment
end

local mat = {Material("homigrad/decals/blood1"), Material("homigrad/decals/blood1"), Material("homigrad/decals/blood1")}
mat[#mat] = nil
local paint = Color(0, 0, 0)
net.Receive("blood decal", function()
	local pos, normal, ent, artery = net.ReadVector(), net.ReadVector(), net.ReadEntity(), net.ReadBool()
	sound.Play("homigrad/blooddrip" .. math.random(1, 4) .. ".wav", pos, math.random(40, 60), math.random(80, 120))
	local r = not artery and math.random(25, 35) or math.random(65, 95)
	paint.r = r
	paint.g = 0
	paint.b = 0
	paint.a = math.random(220, 250)
	local w = math.Rand(1, 1.5) / 16 / (artery and 4 or 1)
	local h = w --+ math.Rand(-0.25,0.25) / 4
	util.DecalEx(mat[math.random(1, #mat)], game.GetWorld(), pos + normal, -normal * 20, paint, w, h)
end)

hook.Add("ScalePlayerDamage", "remove-effects", function(ent, hitgroup, dmgInfo) if dmgInfo:IsDamageType(DMG_BUCKSHOT + DMG_BULLET + DMG_SLASH) then return true end end)
local lply = LocalPlayer()
local min = math.min
local breathe = 0

local FemPlayerModels = {
}
for i = 1, 6 do
	table.insert(FemPlayerModels,"models/player/group01/female_0" .. i .. ".mdl")
end

net.Receive("pulse", function()
	--[[local lply = LocalPlayer() -- bomboclaat
	local organism = lply.organism or {}

	if not organism.o2 then return end

	local pulse = organism.pulse or 0
	breathe = breathe + 1
	if pulse > 80 then
		lply:EmitSound("snd_jack_hmcd_heartpound.wav", min(pulse/3, 45), 100, pulse > 80 and (pulse - 80) / 90 or 0.1)
		--sound.Play("snd_jack_hmcd_heartpound.wav",lply:GetPos(),min(pulse,15),100,pulse / 200)
		if breathe % 2 == 0 and organism.o2.curregen > organism.timeValue and not organism.holdingbreath then
			if lply.armors then 
				local armors = lply.armors -- предавать всю таблицу это же бред?
				local muffed = lply.armors["face"] == "mask2" or lply.PlayerClassName == "Combine"
				lply:EmitSound("snds_jack_hmcd_breathing/" .. (ThatPlyIsFemale(lply) and "f" or "m") .. math.random(4) .. ".wav", min(pulse/ ( muffed and 2.5 or 4), 55), 100, pulse > 80 and (pulse - 80) / 10 or 0.5, CHAN_AUTO, 0, muffed and 16 or 0)
				--sound.Play("snds_jack_hmcd_breathing/" .. (ThatPlyIsFemale(lply) and "f" or "m") .. math.random(4) .. ".wav",lply:GetPos(),min(pulse,15),100,pulse / 200)
			end
		end
	end--]]
end)


local pain_mat = Material("sprites/mat_jack_hmcd_narrow")

local tab = {
	["$pp_colour_addr"] = 0,
	["$pp_colour_addg"] = 0,
	["$pp_colour_addb"] = 0,
	["$pp_colour_brightness"] = 0,
	["$pp_colour_contrast"] = 1,
	["$pp_colour_colour"] = 1,
	["$pp_colour_mulr"] = 0,
	["$pp_colour_mulg"] = 0,
	["$pp_colour_mulb"] = 0,
}

local tabblood = {
	["$pp_colour_addr"] = 0,
	["$pp_colour_addg"] = 0,
	["$pp_colour_addb"] = 0,
	["$pp_colour_brightness"] = 0,
	["$pp_colour_contrast"] = 1,
	["$pp_colour_colour"] = 1,
	["$pp_colour_mulr"] = 0,
	["$pp_colour_mulg"] = 0,
	["$pp_colour_mulb"] = 0,
}

local tab2 = {
	["$pp_colour_addr"] = 0.00,
	["$pp_colour_addg"] = 0.00,
	["$pp_colour_addb"] = 0.04,
	["$pp_colour_brightness"] = -0.02,
	["$pp_colour_contrast"] = 1,
	["$pp_colour_colour"] = 0.7,
	["$pp_colour_mulr"] = 0.1,
	["$pp_colour_mulg"] = 0.1,
	["$pp_colour_mulb"] = 0.25,
}

local k1, k2, k3

local lply

local upDir = Vector(0, 0, 1)
local fwdDir = Vector(0, 2.5, 0)
local rightDir = Vector(2.5, 0, 0)

local function MegaDSP(ply)
		local trDist = 3000
		local view = render.GetViewSetup()
		local viewent = GetViewEntity()
		local filter = {ply.FakeRagdoll,ply,viewent}
		local trUp = util.TraceLine({
			start = view.origin,
			endpos = view.origin + upDir * trDist,
			filter = filter
		})
		local trUpFwdL = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (upDir + fwdDir - rightDir) * trDist,
			filter = filter
		})
		local trUpFwd = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (upDir + fwdDir + rightDir / 2) * trDist,
			filter = filter
		})
		local trUpFwdR = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (upDir + fwdDir + rightDir) * trDist,
			filter = filter
		})
		local trUpBackL = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (upDir - fwdDir - rightDir) * trDist,
			filter = filter
		})
		local trUpBack = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (upDir - fwdDir + rightDir / 2) * trDist,
			filter = filter
		})
		local trUpBackR = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (upDir - fwdDir + rightDir) * trDist,
			filter = filter
		})
		local trRight = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (upDir + rightDir) * trDist,
			filter = filter
		})
		local trLeft = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (upDir - rightDir) * trDist,
			filter = filter
		})
	
		local trDown = util.TraceLine({
			start = view.origin,
			endpos = view.origin - upDir * trDist,
			filter = filter
		})
		local trDownFwdL = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (-upDir + fwdDir - rightDir) * trDist,
			filter = filter
		})
		local trDownFwd = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (-upDir + fwdDir + rightDir / 2) * trDist,
			filter = filter
		})
		local trDownFwdR = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (-upDir + fwdDir + rightDir) * trDist,
			filter = filter
		})
		local trDownBackL = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (-upDir - fwdDir - rightDir) * trDist,
			filter = filter
		})
		local trDownBack = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (-upDir - fwdDir + rightDir / 2) * trDist,
			filter = filter
		})
		local trDownBackR = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (-upDir - fwdDir + rightDir) * trDist,
			filter = filter
		})
		local trDownRight = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (-upDir + rightDir) * trDist,
			filter = filter
		})
		local trDownLeft = util.TraceLine({
			start = view.origin,
			endpos = view.origin + (-upDir - rightDir) * trDist,
			filter = filter
		})
	
		local avgUpDist = 0
		local avgDownDist = 0
		local avgDist
		local upTraces = {trUp, trUpFwdL, trUpFwd, trUpFwdR, trUpBackL, trUpBack, trUpBackR, trRight, trLeft}
		local downTraces = {trDown, trDownFwdL, trDownFwd, trDownFwdR, trDownBackL, trDownBack, trDownBackR, trDownRight, trDownLeft}
		local shouldCompute = true
	
		for _, tr in ipairs(upTraces) do
			-- debugoverlay.Line(view.origin, tr.HitPos, 0.1)
			if not tr.Hit or tr.HitSky then
				shouldCompute = false
				break
			end
		end
		for _, tr in ipairs(downTraces) do
			-- debugoverlay.Line(view.origin, tr.HitPos, 0.1)
			if not tr.Hit or tr.HitSky then
				shouldCompute = false
				break
			end
		end
	
		if shouldCompute then
			for _, tr in ipairs(upTraces) do
				avgUpDist = avgUpDist + (tr.Hit and (tr.HitPos - view.origin):LengthSqr() or 0)
			end
			avgUpDist = avgUpDist / #upTraces
	
			for _, tr in ipairs(downTraces) do
				avgDownDist = avgDownDist + (tr.Hit and (tr.HitPos - view.origin):LengthSqr() or 0)
			end
			avgDownDist = avgDownDist / #downTraces
			
			avgDist = avgUpDist > avgDownDist and avgUpDist or avgDownDist
		else
			avgDist = 10 ^ 8
		end
	
		-- Do not set to 0 for no effect; it causes DSP allocation error.
		--print(avgDist)
		if avgDist > 50000000 then
			RunConsoleCommand("dsp_player", 0)
			RunConsoleCommand("room_type", 21)
		elseif avgDist > 5000000 then
			RunConsoleCommand("dsp_player", 105)
			RunConsoleCommand("room_type", 50)
		elseif avgDist > 500000 then
			RunConsoleCommand("dsp_player", 3)
			RunConsoleCommand("room_type", 50)
		elseif avgDist > 50000 then
			RunConsoleCommand("dsp_player", 2)
			RunConsoleCommand("room_type", 50)
		elseif avgDist > 5000 then
			RunConsoleCommand("dsp_player", 104)
			RunConsoleCommand("room_type", 50)
		elseif avgDist <= 5000 then
			RunConsoleCommand("dsp_player", 102)
			RunConsoleCommand("room_type", 50)
		end
end

local function plyCommand(ply,cmd)
	local time = CurTime()
	ply.cmdtimer = ply.cmdtimer or time
	if ply.cmdtimer < time then
		ply.cmdtimer = time + 0.1

		ply:ConCommand(cmd)
	end
end

local clr_black1 = Color( 0, 0, 0, 255)
local clr_black2 = Color( 0, 0, 0, 255)
hook.Add("RenderScreenspaceEffects", "organism-effects", function()
	lply = lply or LocalPlayer()

	--DrawColorModify(tab2)

	local spect = IsValid(lply:GetNWEntity("spect")) and lply:GetNWEntity("spect")
	local organism = lply:Alive() and lply.organism or (viewmode == 1 and IsValid(spect) and spect.organism) or {}
	local new_organism = lply:Alive() and lply.new_organism or (viewmode == 1 and IsValid(spect) and spect.new_organism) or {}
	
	--LerpVariables(FrameTime(),organism,new_organism)

	if not organism then return end
	local alive = lply:Alive() or (spect and spect:Alive())

	local health = (lply:Alive() and lply:Health()) or 100
	if not alive or follow then end
	local org = organism
	local adrenaline = org.adrenaline or 0
	local pulse = org.pulse or 70
	local pain = org.pain or 0
	local hurt = org.hurt or 0
	local blood = org.blood or 5000
	local bleed = org.bleed or 0
	local o2 = org.o2 and org.o2[1] or 30
	local brain = org.brain or 0
	local otrub = lply:Alive() and org.otrub or false
	local anesthetics = organism.anesthetics or 0
	local health = health
	local disorientation = org.disorientation or 0
	local immobilization = org.immobilization or 0
	local incapacitated = org.incapacitated or false
	local critical = org.critical or false

	local adrenK = math.min(math.max(1 + adrenaline, 1), 1.2)
	
	if lply.suiciding and lply:Alive() then lply:SetDSP(130) end

	if org.otrub then
		if otrub then
			clr_black1.a = math.Clamp(pain / 50 * 255, 250, 255)
			if pain < 50 and not incapacitated and not critical then
				lply:ScreenFade( SCREENFADE.IN, clr_black1, 2, 0.5 )
			else
				lply:ScreenFade( SCREENFADE.IN, clr_black2, 2, 0.5 )
			end
			--lply:ScreenFade( SCREENFADE.IN, Color(0,0,0,255), 2, 0.5 )

			if isnumber(zb.ROUND_STATE) and (zb.ROUND_STATE ~= 1) then
				lply:SetDSP(0)
				plyCommand(lply,"soundfade 0 1")
			else
				lply:SetDSP(17)
				if pain < 50 and not incapacitated and not critical then
					plyCommand(lply,"soundfade 100 99999")
					--plyCommand(lply,"soundfade "..tostring(pain / 50).." 99999")
				else
					plyCommand(lply,"soundfade 100 99999")
				end
			end
		else
			surface.SetTextPos(ScrW()/2,ScrH() * 9 / 10)
			surface.SetFont("HomigradFontLarge")
			surface.DrawText("Unconscious")
		end
	else
		plyCommand(lply,"soundfade 0 1")

		if org.disorientation and org.disorientation > 3 and lply:Alive() then
			lply:SetDSP(130)
		elseif org.adrenaline and org.adrenaline > 0.5 and lply:Alive() then
			--lply:SetDSP(6)
		elseif lply.flashed then

		else
			local armor = lply:GetNetVar("Armor")
			if armor then
				local Ears = armor["ears"]
				local sndparms = Ears and hg.armor.ears[Ears]
				local sndBool = Ears and sndparms
				--if not sndBool then
					--MegaDSP(lply)
				--else
					lply:SetDSP(0)
				--end
			end
		end
	end

	if not alive then
		return false
	end
	
	k1 = Lerp(FrameTime() * 15, k1 or 0, math.min(math.min(adrenaline / 1, 1.2),1.5))
	k2 = (30 - (o2 or 30)) / 30-- + brain * 2
	k3 = ((5000 / math.max(blood, 1000)) - 1) * 1.5

	DrawSharpen(k1 * 1.5, k1 * 1)
	local lowpulse = math.max((70 - pulse) / 70, 0) + math.max(3000 * ((math.cos(CurTime()/2) + 1) / 2 * 0.1 + 1) - (blood * adrenK - 300),0) / 400

	local amount = 1 - math.Clamp(lowpulse + disorientation / 4 + k2 * 2,0,1)

	if (disorientation > 0) or (k2 > 0) or (lowpulse > 0) and lply:Alive() or brain > 0 then
		--DrawMotionBlur(0.25 + amount, k2 + lowpulse + disorientation / 8 + math.max(pain - 30,0) / 10, 0.01 + disorientation / 100)
	end

	if (pain > 0) or (hurt > 0) or (immobilization > 0) or (brain > 0) then
		local k = ((hurt + immobilization / 15) / 2)
		--DrawToyTown(1, k * ScrH())
		local newpain = pain - 10
		if newpain > 0 then
			surface.SetDrawColor(0, 0, 0, (newpain / 30) * 255 - math.cos(CurTime()) * 50)
			surface.SetMaterial(pain_mat)
			surface.DrawTexturedRect(-1, -1, ScrW()+1, ScrH()+1)
			local blur = math.max((newpain / 30 + brain * 10) - math.cos(CurTime()),0) / 50
			if blur > 0 then
				DrawMaterialOverlay( "sprites/mat_jack_hmcd_scope_aberration", blur )
			end
		end
	end

	if (k1 > 0) or (k2 > 0) or (k3 > 0) or brain > 0 then
		DrawToyTown(2, (k3 * 3 + k2 * 2 + brain * 10) * ScrH() / 2)
	end

	--DrawMaterialOverlay( "homigrad/vgui/bloodblur.png", 0)
	local view = render.GetViewSetup()
	--RenderSuperDoF(view.origin,view.angles,0)
	if anesthetics > 1 then
		DrawMaterialOverlay( "particle/warp4_warp_noz", -(anesthetics - 0.5) / 150 )
	end
	
	tabblood["$pp_colour_colour"] = Lerp(FrameTime() * 30, tabblood["$pp_colour_colour"], math.min(health / 100, 1) - (anesthetics > 1 and (anesthetics - 1) * 1 + (anesthetics - 1) * math.cos((CurTime()%360) * 1) + (anesthetics - 1) * math.sin((CurTime()%180) * 0.5) * 8 or 0))
	tabblood["$pp_colour_contrast"] = Lerp(FrameTime() * 30, tabblood["$pp_colour_contrast"], health < 80 and math.max(1.5 * ( 1 - math.min(health / 50, 1) ), 1 ) or 1)
	tabblood["$pp_colour_brightness"] = Lerp(FrameTime() * 30, tabblood["$pp_colour_brightness"],health < 80 and -0.3 * ( 1 - math.min(health / 50, 1) ) or 0 )
	--tab["$pp_colour_addb"] = k1 > 1 and (k1 - 1) / 60 or 0
	--tab["$pp_colour_brightness"] = k1 > 1 and -(k1 - 1) / 20 or 0
	--tab["$pp_colour_contrast"] = k1 > 1 and -(k1 - 1) / 10 + 1 or 1
	DrawColorModify(tab)
	DrawColorModify(tabblood)
	--DrawBloom( 0.80, 2, 9, 9, 1, 1, 1, 1, 1 )

	local ent = hg.GetCurrentCharacter(lply)

	if otrub then
		render.PushFilterMag( TEXFILTER.ANISOTROPIC )
		render.PushFilterMin( TEXFILTER.ANISOTROPIC )

		local textOtrub = "You are unconscious. "
		local textOtrub2 =  
			( critical and "You can't be saved." ) or 
			( incapacitated and "You will not get up without someone's help." ) or 
			( 
				"You will probably wake up in "
				..( 	
					( pain < 50 and "about a minute." ) or 
					( pain < 100 and "about two minutes." ) or 
					"a few minutes."
				) 
			)

		local parsed = markup.Parse( 
			"<font=HomigradFontMedium>"..
			( critical and "You're criticaly injured." or textOtrub )..
			"\n<colour=255,"..( critical and 25 or 255 )..","..( critical and 25 or 255 ) ..",255>"..
			( textOtrub2 ).."</colour></font>" 
		)
		--((critical and "You can not be saved.") or 
		--(incapacitated and "You will not get up without someone's help.") or 
		--( "You will probably wake up in " .. (pain < 50 and "about a minute.") ) or 
		--((pain < 100 and "about two minutes.") or "a few minutes.")) -- WTF???
		
		--surface.SetTextColor(255,255,255,255)
		--surface.SetFont("HomigradFontMedium")
		--local txtSizeX, txtSizeY = surface.GetTextSize(textOtrub)
		--surface.SetTextPos(ScrW()/2 - (txtSizeX/2),ScrH()/1.1 - (txtSizeY/2))
		--surface.DrawText(textOtrub)

		parsed:Draw( ScrW()/2, ScrH()/1.1, TEXT_ALIGN_CENTER, nil, nil, TEXT_ALIGN_CENTER )
		
		render.PopFilterMag()
		render.PopFilterMin()
	end

	if IsValid(ent) and ent.Blinking and lply:Alive() then
		surface.SetDrawColor(0,0,0,255)
		--surface.DrawRect(-1,-1,ScrW()+1,ent.Blinking * ScrH())
		--surface.DrawRect(-1,ScrH() + 1,ScrW()+1,-ent.Blinking * ScrH())
	end
end)

hook.Add("OnNetVarSet","wounds_netvar",function(index, key, var)
	if key == "wounds" then
		local ent = Entity(index)
		local ent = hg.RagdollOwner(ent) or ent

		if IsValid(ent) then
			ent.wounds = var
			if IsValid(ent.FakeRagdoll) then
				ent.FakeRagdoll.wounds = ent.wounds
			end
		end
	end
end)

hook.Add("OnNetVarSet","wounds_netvar2",function(index, key, var)
	if key == "arterialwounds" then
		local ent = Entity(index)
		local ent = hg.RagdollOwner(ent) or ent

		if IsValid(ent) then
			ent.arterialwounds = var
			if IsValid(ent.FakeRagdoll) then
				ent.FakeRagdoll.arterialwounds = ent.arterialwounds
			end
		end
	end
end)

hook.Add("Fake", "huyhuyhuy235", function(ply,ragdoll)
	if not IsValid(ragdoll) then return end
	ragdoll.organism = ply.organism
	ragdoll.wounds = ply.wounds
	ragdoll.arterialwounds = ply.arterialwounds
end)

hook.Add("Player Death", "huyhuyhuy22", function(ply)
	ply.wounds = nil
	ply.arterialwounds = nil
end)

hook.Add("Player-Ragdoll think", "organism-think-client-blood", function(ply,time)	
	local ent = hg.GetCurrentCharacter(ply)
	local organism = ply.organism
	local new_organism = ply.new_organism
	
	hg.LerpVariables(FrameTime(),organism,new_organism)
	
	local org = ent.organism or {}
	local owner = ent

	ent.wounds = ent.wounds or ply.wounds or {}
	ent.arterialwounds = ent.arterialwounds or ply.arterialwounds or {}

	local beatsPerSecond = math.max(min(60 / math.max(org.pulse or 70,2), 7), 0.3)
	
	ent.lastpulse = ent.lastpulse or CurTime()
	
	if org.pulse and ent.lastpulse < CurTime() then
		ent.lastpulse = CurTime() + (1 / math.Clamp(org.pulse,1,200)) * 120
		local pulse = org.pulse or 0
		ent.breathe = (ent.breathe or 0) + 1
		if pulse > 80 then
			ent:EmitSound("augmented_heartbeat1.wav", min(pulse/2, 45), 100, pulse > 80 and (pulse - 80) / 20 or 0.1)
			
			if org and org.o2 and ent.breathe % 2 == 0 and org.o2.curregen and org.timeValue and org.o2.curregen > org.timeValue and not org.holdingbreath then
				if ent.armors then
					local armors = ent.armors
					local muffed = ent.armors["face"] == "mask2" or ent.PlayerClassName == "Combine"
					ent:EmitSound("snds_jack_hmcd_breathing/" .. (ThatPlyIsFemale(ent) and "f" or "m") .. math.random(4) .. ".wav", min(pulse * 1.5 / ( muffed and 2.5 or 4), 55), 100, pulse > 80 and (pulse - 80) / 10 or 0.5, CHAN_AUTO, 0, muffed and 16 or 0)
				end
			end
		end
	end

	if hg.fountains[ent] then
		local tbl = hg.fountains[ent]
		if (tbl.time or 0) < CurTime() and org.pulse then
			local mul = 1 / math.max(org.pulse / 5,5)
			local mul2 = math.max(org.pulse,5) / 70
			local forward = mul2 * 150
			tbl.time = CurTime() + mul
			local mat = ent:GetBoneMatrix(tbl.bone)
			if mat then
				local pos, ang = LocalToWorld(tbl.lpos, tbl.lang, mat:GetTranslation(), mat:GetAngles())
				hg.addbloodPart(pos, ang:Forward() * forward * 2 + VectorRand(-25,25) * mul2,nil,nil,nil,true)
				hg.addbloodPart(pos + VectorRand(-1,1), ang:Forward() * forward + VectorRand(-25,25) * mul2)
				hg.addbloodPart(pos + VectorRand(-1,1), ang:Forward() * forward + VectorRand(-25,25) * mul2)
			end
		end
	end

	if #ent.wounds > 0 then
		for i, wound in pairs(ent.wounds) do
			local rand = math.Rand(0, 2)
			local size = math.random(1, 2) * math.max(math.min(wound[1], 1), 0.5)

			if wound[5] + beatsPerSecond + rand < time then
				wound[5] = time

				if (owner:IsPlayer() and owner:Alive()) or not owner:IsPlayer() then
					local bone = wound[4]
					local bonePos, boneAng = ent:GetBonePosition(bone)
					if not wound[2] or not wound[3] or not bonePos or not boneAng then return end
					local pos = LocalToWorld(wound[2], wound[3], bonePos, boneAng)

					hg.addbloodPart(pos, ent:GetVelocity() + VectorRand(-15, 15), nil, size / 2, size / 2, false)
				end
			end
		end
	end

	for i, wound in pairs(ent.arterialwounds) do
		if wound[5] + 1 / math.Clamp(org.pulse or 70, 1,15) < time then
			local pos, ang = ent:GetBonePosition(wound[4])
			wound[5] = time
			if (owner:IsPlayer() and owner:Alive()) or not owner:IsPlayer() then
				local size = math.random(1, 2) * math.max(math.min(wound[1], 1), 0.5)
				local bone = wound[4]
				local bonePos, boneAng = ent:GetBonePosition(bone)
				if not wound[2] or not wound[3] or not bonePos or not boneAng then return end
				local pos = LocalToWorld(wound[2], wound[3], bonePos, boneAng)

				local dir = wound[6]
				local len = dir:Length() * (org.pulse or 70) / 70
				local _, dir = LocalToWorld(vector_origin, dir:Angle(), vector_origin, ang)
				dir = -dir:Forward() * len
				hg.addbloodPart(pos, ent:GetVelocity() + VectorRand(-5, 5) + dir, nil, size / 2, size / 2, true)
			end
		end
	end
end)

local red = Color(255, 0, 0)

local AdminAbuse = CreateClientConVar("zb_adminabuse", "0", false)


hook.Add("SetupOutlines", "ZB_AdminAbuse_Outlines", function(Add)
	local ply = LocalPlayer()
	if not ply:IsAdmin() then return end
	if not AdminAbuse:GetBool() then return end

	local targets = {}
	for _, target in ipairs(player.GetAll()) do
		if IsValid(target) and target:Alive() and target:Team() ~= TEAM_SPECTATOR then
			table.insert(targets, target)
		end
	end

	outline.Add(targets, red, OUTLINE_MODE_BOTH)
end)

local UpVector = Vector(0, 0, 80)


hook.Add("PreDrawHUD", "ZB_AdminAbuse_ESP", function()
	local ply = LocalPlayer()
	if not ply:IsAdmin() then return end
	if not AdminAbuse:GetBool() then return end

	for _, target in ipairs(player.GetAll()) do
		if not IsValid(target) or not target:Alive() or target:Team() == TEAM_SPECTATOR then
			continue
		end

		if target == ply then continue end

		local eyePos = target:EyePos()
		local eyeDir = target:EyeAngles():Forward()
		local endPos = eyePos + eyeDir * 10000

		cam.Start3D()
			render.DrawLine(eyePos, endPos, red, true)
		cam.End3D()

		local ScreenPos = (target:GetPos() + UpVector):ToScreen()

		cam.Start2D()
			draw.SimpleText(target:Nick(), "TargetIDSmall", ScreenPos.x, ScreenPos.y, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		cam.End2D()
	end
end)

local prank = {}
local time_troll = 100

local DontCallMe = false
hook.Add("HG.InputMouseApply","zzzzzzzzzzzzbrain_death",function(tbl)
	local lply = LocalPlayer()

	if lply:Alive() and lply.organism and (lply.organism.brain or 0) > 0.1 then
		if #prank < time_troll then table.insert(prank,1,{tbl.x,tbl.y}) end
		if #prank >= time_troll then table.remove(prank,#prank) end
		
		local amt = lply.organism.brain / 0.3

		local xa = Lerp(1 * amt,tbl.x,prank[#prank][1])
		local ya = Lerp(1 * amt,tbl.y,prank[#prank][2])

		tbl.angle.pitch = math.Clamp(tbl.angle.pitch + tbl.y / 100 + ya / 100, -89, 89)
		tbl.angle.yaw = tbl.angle.yaw - tbl.x / 100 - xa / 100
		tbl.override_angle = true
	end

	--[[local actwep = LocalPlayer():GetActiveWeapon()
	if not actwep or not actwep.GetTrace then return end
	local hitpos,pos,ang = actwep:GetTrace()

	local ply = hg.GetCurrentCharacter(Entity(2))
	local dist = ply:EyePos():Distance(LocalPlayer():EyePos())
	ply:SetupBones()
	scr = ply:GetBoneMatrix(ply:LookupBone("ValveBiped.Bip01_Head1")):GetTranslation():ToScreen()

	angle.pitch = math.Clamp(angle.pitch + (scr.y - (pos+ang:Forward() * dist):ToScreen().y) / 50, -89, 89)
	angle.yaw = angle.yaw - (scr.x - (pos+ang:Forward() * dist):ToScreen().x) / 50
	cmd:SetViewAngles(angle)

	return true--]]
end)