-- "addons\\homigrad\\lua\\homigrad\\admin_tools\\derma\\cl_mainbar.lua"

-- ehh когда нибудь...
local PANEL = {}

function PANEL:Init()
    self:SetSize(ScrW()/4, ScrH())
end