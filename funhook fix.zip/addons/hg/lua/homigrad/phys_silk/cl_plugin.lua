-- "addons\\homigrad\\lua\\homigrad\\phys_silk\\cl_plugin.lua"

hg.PhysSilk = hg.PhysSilk or {}
local PLUGIN = hg.PhysSilk