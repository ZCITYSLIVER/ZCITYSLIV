-- "addons\\homigrad\\lua\\homigrad\\sh_util.lua"

if CLIENT then
	local plymeta = FindMetaTable("Player")
	hg.GetAimVector = hg.GetAimVector or plymeta.GetAimVector
	function plymeta:GetAimVector()
		if self == LocalPlayer() then
			return hg.GetAimVector(self)
		elseif self:InVehicle() then
			local ang = self:EyeAngles()
			--ang:Add(-self:GetVehicle():GetAngles())
			return ang:Forward()
		end

		return hg.GetAimVector(self)
	end
end

--\\Is Changed
local ChangedTable = {}

function hg.GetCurrentCharacter(ply)

    return ply
end

function hg.IsChanged(val, id, meta)
	if(meta == nil)then
		meta = ChangedTable
	end

	if(meta.ChangedTable == nil)then
		meta["ChangedTable"] = {}
	end

	if(meta.ChangedTable[id] == val)then
		return false
	end

	meta.ChangedTable[id] = val
	return true
end
--//

function ishgweapon(wep)
	if not wep or not IsValid(wep) then return false end
	return wep.ishgweapon
end

function hg.isVisible(pos1, pos2, filter, mask)
	return not util.TraceLine({
		start = pos1,
		endpos = pos2,
		filter = filter,
		mask = mask
	}).Hit
end

--hg.DeathCam = true

if SERVER then
	util.AddNetworkString("keyDownply2")
	hook.Add("KeyPress", "huy-hg", function(ply, key)
		net.Start("keyDownply2")
		net.WriteInt(key, 26)
		net.WriteBool(true)
		net.WriteEntity(ply)
		net.Broadcast()
	end)

	hook.Add("KeyRelease", "huy-hg2", function(ply, key)
		net.Start("keyDownply2")
		net.WriteInt(key, 26)
		net.WriteBool(false)
		net.WriteEntity(ply)
		net.Broadcast()
	end)
else
	net.Receive("keyDownply2", function(len)
		local key = net.ReadInt(26)
		local down = net.ReadBool()
		local ply = net.ReadEntity()
		if not IsValid(ply) then return end
		ply.keydown = ply.keydown or {}
		ply.keydown[key] = down
		if ply.keydown[key] == false then ply.keydown[key] = nil end
	end)
end

function hg.KeyDown(owner,key)
	if not IsValid(owner) then return false end
	owner.keydown = owner.keydown or {}
	local localKey
	if CLIENT then
		if owner == LocalPlayer() then
			localKey = owner:KeyDown(key)
		else
			localKey = owner.keydown[key]
		end
	end
	return SERVER and owner:IsPlayer() and owner:KeyDown(key) or CLIENT and localKey
end

if CLIENT then
	local cached_children = {}

	function hg.get_children(ent, bone, endbone)
		local bones = {}

		local mdl = ent:GetModel()
		if cached_children[mdl] and cached_children[mdl][bone] then return cached_children[mdl][bone] end

		hg.recursive_get_children(ent, bone, bones, endbone)

		cached_children[mdl] = cached_children[mdl] or {}
		cached_children[mdl][bone] = bones

		return bones
	end

	function hg.recursive_get_children(ent, bone, bones, endbone)
		local bone = isstring(bone) and ent:LookupBone(bone) or bone

		if not bone or isstring(bone) or bone == -1 then return end
		
		local children = ent:GetChildBones(bone)
		if #children > 0 then
			local id
			for i = 1,#children do
				id = children[i]
				if id == endbone then continue end
				hg.recursive_get_children(ent, id, bones, endbone)
				table.insert(bones, id)
			end
		end
	end

	function hg.bone_apply_matrix(ent, bone, new_matrix, endbone)
		local bone = isstring(bone) and ent:LookupBone(bone) or bone

		if not bone or isstring(bone) or bone == -1 then return end

		local matrix = ent:GetBoneMatrix(bone)
		if not matrix then return end
		local inv_matrix = matrix:GetInverse()
		if not inv_matrix then return end

		local children = hg.get_children(ent, bone, endbone)

		local id
		for i = 1,#children do
			id = children[i]
			local mat = ent:GetBoneMatrix(id)
			if not mat then continue end
			ent:SetBoneMatrix(id, new_matrix * (inv_matrix * mat))
		end

		ent:SetBoneMatrix(bone, new_matrix)
	end

	local hand_poses = {
		["ak_hold"] = {
			['ValveBiped.Anim_Attachment_LH'] = Matrix({
				{-0.00000,	0.00000,	1.00000,	2.67615},
				{1.00000,	-0.00000,	0.00000,	-1.71252},
				{0.00000,	1.00000,	-0.00000,	0.00006},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger22'] = Matrix({
				{-0.52175,	0.84870,	-0.08646,	5.02594},
				{-0.85309,	-0.51873,	0.05618,	-2.04166},
				{0.00283,	0.10308,	0.99467,	0.41785},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger21'] = Matrix({
				{-0.20632,	0.97375,	-0.09616,	5.27545},
				{-0.97848,	-0.20511,	0.02245,	-0.85849},
				{0.00214,	0.09873,	0.99511,	0.41528},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger2'] = Matrix({
				{0.81034,	0.58292,	-0.05964,	3.88208},
				{-0.58595,	0.80683,	-0.07543,	0.14908},
				{0.00414,	0.09607,	0.99537,	0.40814},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger12'] = Matrix({
				{-0.57005,	0.69819,	-0.43310,	4.84900},
				{-0.79915,	-0.59360,	0.09491,	-2.36978},
				{-0.19082,	0.40021,	0.89634,	1.46698},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger11'] = Matrix({
				{-0.07765,	0.87264,	-0.48215,	4.93420},
				{-0.99482,	-0.09964,	-0.02013,	-1.27579},
				{-0.06561,	0.47809,	0.87585,	1.53925},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger1'] = Matrix({
				{0.61997,	0.63004,	-0.46764,	3.86823},
				{-0.77310,	0.59229,	-0.22697,	0.05350},
				{0.13398,	0.50224,	0.85428,	1.30878},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger02'] = Matrix({
				{0.57850,	0.57237,	0.58114,	2.85675},
				{-0.72954,	0.04441,	0.68249,	-2.27423},
				{0.36483,	-0.81879,	0.44326,	2.29254},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger01'] = Matrix({
				{0.60608,	0.53433,	0.58921,	2.12543},
				{-0.73469,	0.09221,	0.67210,	-1.38745},
				{0.30479,	-0.84023,	0.44845,	1.92474},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger0'] = Matrix({
				{0.72334,	0.53463,	0.43698,	0.83063},
				{-0.60060,	0.17492,	0.78018,	-0.31253},
				{0.34067,	-0.82679,	0.44763,	1.31494},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),

		},
		["ak_hold2"] = {
			[17] = Matrix({
				{-0.00000,	0.00000,	1.00000,	2.67603},
				{1.00000,	0.00000,	0.00000,	-1.71243},
				{0.00000,	1.00000,	-0.00000,	0.00000},
				{0.00000,	0.00000,	0.00000,	1.00000},
			}),
			[34] = Matrix({
				{-0.52175,	0.84870,	-0.08646,	5.02588},
				{-0.85309,	-0.51873,	0.05618,	-2.04156},
				{0.00283,	0.10308,	0.99467,	0.41776},
				{0.00000,	0.00000,	0.00000,	1.00000},
			}),
			[33] = Matrix({
				{-0.20632,	0.97375,	-0.09616,	5.27521},
				{-0.97848,	-0.20511,	0.02245,	-0.85841},
				{0.00214,	0.09873,	0.99511,	0.41519},
				{0.00000,	0.00000,	0.00000,	1.00000},
			}),
			[32] = Matrix({
				{0.81034,	0.58292,	-0.05964,	3.88190},
				{-0.58595,	0.80683,	-0.07543,	0.14920},
				{0.00414,	0.09607,	0.99537,	0.40802},
				{0.00000,	0.00000,	0.00000,	1.00000},
			}),
			[37] = Matrix({
				{-0.57005,	0.69819,	-0.43310,	4.84900},
				{-0.79915,	-0.59360,	0.09491,	-2.36967},
				{-0.19082,	0.40021,	0.89634,	1.46701},
				{0.00000,	0.00000,	0.00000,	1.00000},
			}),
			[36] = Matrix({
				{-0.07765,	0.87264,	-0.48215,	4.93439},
				{-0.99482,	-0.09964,	-0.02013,	-1.27568},
				{-0.06561,	0.47809,	0.87585,	1.53915},
				{0.00000,	0.00000,	0.00000,	1.00000},
			}),
			[35] = Matrix({
				{0.61997,	0.63004,	-0.46764,	3.86829},
				{-0.77310,	0.59229,	-0.22697,	0.05362},
				{0.13398,	0.50224,	0.85428,	1.30878},
				{0.00000,	0.00000,	0.00000,	1.00000},
			}),
			[40] = Matrix({
				{0.72882,	0.60441,	0.32173,	2.13348},
				{-0.66408,	0.73843,	0.11714,	-2.99207},
				{-0.16677,	-0.29903,	0.93956,	1.49228},
				{0.00000,	0.00000,	0.00000,	1.00000},
			}),
			[39] = Matrix({
				{0.38117,	0.86502,	0.32626,	1.67340},
				{-0.92401,	0.36803,	0.10375,	-1.87679},
				{-0.03033,	-0.34101,	0.93957,	1.52890},
				{0.00000,	0.00000,	0.00000,	1.00000},
			}),
			[38] = Matrix({
				{0.47089,	0.86062,	0.19391,	0.83057},
				{-0.87405,	0.42534,	0.23478,	-0.31242},
				{0.11957,	-0.28004,	0.95251,	1.31488},
				{0.00000,	0.00000,	0.00000,	1.00000},
			}),
		},
		["pistol_hold"] = {
			['ValveBiped.Anim_Attachment_LH'] = Matrix({
				{-0.00000,	0.00000,	1.00000,	2.67621},
				{1.00000,	-0.00000,	0.00000,	-1.71246},
				{0.00000,	1.00000,	-0.00000,	0.00003},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger22'] = Matrix({
				{-0.01749,	0.99334,	0.11387,	6.02985},
				{-0.97449,	-0.04242,	0.22040,	-1.66858},
				{0.22376,	-0.10711,	0.96874,	0.55327},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger21'] = Matrix({
				{0.51410,	0.85003,	0.11468,	5.40814},
				{-0.84802,	0.48365,	0.21666,	-0.64301},
				{0.12871,	-0.20863,	0.96949,	0.39767},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger2'] = Matrix({
				{0.88753,	0.44555,	0.11738,	3.88190},
				{-0.46071,	0.86152,	0.21339,	0.14917},
				{-0.00605,	-0.24347,	0.96989,	0.40808},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger12'] = Matrix({
				{-0.09313,	0.95159,	-0.29292,	5.74945},
				{-0.98149,	-0.03829,	0.18766,	-1.67291},
				{0.16736,	0.30498,	0.93754,	2.22884},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger11'] = Matrix({
				{0.42919,	0.85458,	-0.29240,	5.27753},
				{-0.85153,	0.49078,	0.18449,	-0.73663},
				{0.30116,	0.16981,	0.93833,	1.89777},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger1'] = Matrix({
				{0.81943,	0.49413,	-0.29047,	3.86847},
				{-0.45961,	0.86925,	0.18211,	0.05353},
				{0.34248,	-0.01572,	0.93939,	1.30884},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger02'] = Matrix({
				{0.45101,	0.46180,	0.76376,	0.99359},
				{-0.89058,	0.28921,	0.35103,	-2.93256},
				{-0.05879,	-0.83851,	0.54171,	2.74484},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger01'] = Matrix({
				{0.11163,	0.71261,	0.69263,	0.85889},
				{-0.90098,	-0.22147,	0.37307,	-1.84503},
				{0.41925,	-0.66569,	0.61732,	2.23883},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger0'] = Matrix({
				{0.01574,	0.63272,	0.77422,	0.83069},
				{-0.85632,	-0.39123,	0.33713,	-0.31244},
				{0.51620,	-0.66829,	0.53565,	1.31491},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
		},
		["pistol_hold2"] = {
			['ValveBiped.Anim_Attachment_LH'] = Matrix({
				{0.00000,	0.00000,	1.00000,	2.67624},
				{1.00000,	0.00000,	0.00000,	-1.71219},
				{0.00000,	1.00000,	0.00000,	0.00125},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger22'] = Matrix({
				{-0.01749,	0.99334,	0.11387,	6.02979},
				{-0.97449,	-0.04242,	0.22040,	-1.66882},
				{0.22376,	-0.10711,	0.96874,	0.55479},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger21'] = Matrix({
				{0.51410,	0.85003,	0.11468,	5.40826},
				{-0.84802,	0.48365,	0.21666,	-0.64151},
				{0.12871,	-0.20863,	0.96949,	0.39841},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger2'] = Matrix({
				{0.88753,	0.44555,	0.11738,	3.88205},
				{-0.46071,	0.86152,	0.21339,	0.14990},
				{-0.00605,	-0.24347,	0.96989,	0.40967},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger12'] = Matrix({
				{0.04883,	0.93152,	0.36040,	5.93692},
				{-0.94806,	-0.07033,	0.31021,	-1.68707},
				{0.31431,	-0.35683,	0.87971,	1.06296},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger11'] = Matrix({
				{0.53655,	0.76259,	0.36135,	5.34744},
				{-0.84070,	0.44598,	0.30712,	-0.76180},
				{0.07304,	-0.46857,	0.88040,	0.98254},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger1'] = Matrix({
				{0.85928,	0.35981,	0.36356,	3.86862},
				{-0.47470,	0.82571,	0.30475,	0.05447},
				{-0.19054,	-0.43444,	0.88032,	1.30991},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger02'] = Matrix({
				{0.96372,	-0.25079,	0.09129,	3.71692},
				{-0.23753,	-0.65006,	0.72180,	-0.67805},
				{-0.12168,	-0.71731,	-0.68605,	2.00784},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger01'] = Matrix({
				{0.96779,	0.00605,	0.25170,	2.54880},
				{-0.18421,	-0.66437,	0.72434,	-0.45737},
				{0.17162,	-0.74738,	-0.64186,	1.80225},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger0'] = Matrix({
				{0.95950,	0.11401,	0.25760,	0.83066},
				{-0.08016,	-0.76613,	0.63767,	-0.31189},
				{0.27007,	-0.63250,	-0.72596,	1.31686},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				
		},
		["grip_hold"] = {
			['ValveBiped.Anim_Attachment_LH'] = Matrix({
				{-0.00000,	0.00000,	1.00000,	2.67603},
				{1.00000,	-0.00000,	0.00000,	-1.71242},
				{0.00000,	1.00000,	-0.00000,	-0.00003},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger22'] = Matrix({
				{-0.97924,	0.20271,	-0.00014,	3.74866},
				{-0.20076,	-0.96973,	0.13898,	-2.21208},
				{0.02804,	0.13613,	0.99029,	0.41345},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger21'] = Matrix({
				{-0.73487,	0.67761,	-0.02840,	4.63727},
				{-0.67613,	-0.72870,	0.10877,	-1.39452},
				{0.05301,	0.09914,	0.99366,	0.34940},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger2'] = Matrix({
				{0.43925,	0.89832,	-0.00901,	3.88190},
				{-0.89772,	0.43853,	-0.04240,	0.14917},
				{-0.03413,	0.02671,	0.99906,	0.40808},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger12'] = Matrix({
				{-0.99956,	-0.01974,	-0.02234,	3.86542},
				{0.01938,	-0.99968,	0.01623,	-2.35136},
				{-0.02265,	0.01579,	0.99962,	1.09308},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger11'] = Matrix({
				{-0.63952,	0.75470,	-0.14642,	4.56860},
				{-0.76220,	-0.64730,	-0.00734,	-1.51318},
				{-0.10032,	0.10691,	0.98920,	1.20340},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger1'] = Matrix({
				{0.40735,	0.87616,	-0.25768,	3.86835},
				{-0.91121,	0.37097,	-0.17910,	0.05359},
				{-0.06132,	0.30776,	0.94949,	1.30881},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger02'] = Matrix({
				{0.85313,	-0.04293,	0.51993,	2.97278},
				{-0.41533,	0.54722,	0.72667,	-2.11815},
				{-0.31571,	-0.83589,	0.44902,	2.23587},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger01'] = Matrix({
				{0.76975,	0.35296,	0.53189,	2.04376},
				{-0.63041,	0.28937,	0.72031,	-1.35727},
				{0.10032,	-0.88977,	0.44525,	2.11478},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_L_Finger0'] = Matrix({
					{0.94183,	0.32924,	-0.06756,	0.83057},
					{-0.17855,	0.66041,	0.72936,	-0.31244},
					{0.28475,	-0.67487,	0.68078,	1.31494},
					{0.00000,	0.00000,	0.00000,	1.00000},
				}),
			},
	}

	local hand_posesrh = {
		["pistol_hold"] = {
			['ValveBiped.Anim_Attachment_RH'] = Matrix({
				{0.00000,	0.00000,	1.00000,	2.67606},
				{-1.00000,	0.00000,	0.00000,	-1.71246},
				{-0.00000,	-1.00000,	0.00000,	0.00002},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger22'] = Matrix({
				{-0.72247,	-0.69045,	0.03619,	3.59613},
				{0.68088,	-0.71960,	-0.13627,	-2.10107},
				{0.12013,	-0.07381,	0.99001,	-0.70821},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger21'] = Matrix({
				{-0.81663,	0.57602,	0.03631,	4.58354},
				{-0.57506,	-0.80666,	-0.13638,	-1.40582},
				{-0.04927,	-0.13225,	0.98999,	-0.64864},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger2'] = Matrix({
				{0.40803,	0.91223,	0.03655,	3.88191},
				{-0.90229,	0.40904,	-0.13621,	0.14581},
				{-0.13920,	0.02260,	0.99001,	-0.40927},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger12'] = Matrix({
				{0.38305,	0.89067,	0.24489,	6.36687},
				{-0.87335,	0.43556,	-0.21806,	-0.71552},
				{-0.30089,	-0.13035,	0.94471,	-2.29142},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger11'] = Matrix({
				{0.82500,	0.46776,	0.31714,	5.45959},
				{-0.43831,	0.88385,	-0.16339,	-0.23364},
				{-0.35672,	-0.00421,	0.93420,	-1.89915},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger1'] = Matrix({
				{0.92545,	0.20620,	0.31783,	3.86839},
				{-0.16063,	0.97334,	-0.16376,	0.04260},
				{-0.34312,	0.10050,	0.93390,	-1.30919},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger02'] = Matrix({
				{0.91919,	0.01437,	-0.39356,	2.56244},
				{-0.22476,	0.83975,	-0.49427,	-2.46594},
				{0.32339,	0.54278,	0.77512,	-1.12394},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger01'] = Matrix({
				{0.89306,	0.24370,	-0.37822,	1.48447},
				{-0.39602,	0.82473,	-0.40371,	-1.98792},
				{0.21354,	0.51032,	0.83305,	-1.38169},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger0'] = Matrix({
				{0.36535,	0.67044,	-0.64578,	0.83058},
				{-0.93006,	0.23399,	-0.28325,	-0.32336},
				{-0.03880,	0.70410,	0.70904,	-1.31224},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),

		},
		["pistol_hold2"] = {
			['ValveBiped.Anim_Attachment_RH'] = Matrix({
				{-0.00000,	-0.00000,	1.00000,	2.67590},
				{-1.00000,	0.00000,	0.00000,	-1.71245},
				{-0.00000,	-1.00000,	0.00000,	-0.00018},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger22'] = Matrix({
				{-0.72247,	-0.69045,	0.03619,	3.59595},
				{0.68088,	-0.71960,	-0.13627,	-2.10101},
				{0.12013,	-0.07381,	0.99001,	-0.70869},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger21'] = Matrix({
				{-0.81663,	0.57602,	0.03631,	4.58325},
				{-0.57506,	-0.80666,	-0.13638,	-1.40576},
				{-0.04927,	-0.13225,	0.98999,	-0.64896},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger2'] = Matrix({
				{0.40803,	0.91223,	0.03655,	3.88184},
				{-0.90229,	0.40904,	-0.13621,	0.14584},
				{-0.13920,	0.02260,	0.99001,	-0.40953},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger12'] = Matrix({
				{-0.64674,	0.67462,	0.35582,	5.34323},
				{-0.72666,	-0.68676,	-0.01868,	-1.51030},
				{0.23174,	-0.27064,	0.93437,	-1.63513},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger11'] = Matrix({
				{-0.13709,	0.89443,	0.42567,	5.49384},
				{-0.99051,	-0.11955,	-0.06781,	-0.42105},
				{-0.00976,	-0.43093,	0.90233,	-1.62455},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger1'] = Matrix({
				{0.94541,	0.27139,	0.18037,	3.86847},
				{-0.26957,	0.96235,	-0.03501,	0.04260},
				{-0.18308,	-0.01552,	0.98298,	-1.30880},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger02'] = Matrix({
				{0.99624,	0.06471,	-0.05769,	2.81659},
				{-0.08661,	0.77220,	-0.62945,	-2.12851},
				{0.00382,	0.63207,	0.77490,	-1.95563},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger01'] = Matrix({
				{0.96151,	0.27211,	-0.03794,	1.65674},
				{-0.24833,	0.80174,	-0.54364,	-1.82861},
				{-0.11751,	0.53214,	0.83846,	-1.81313},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger0'] = Matrix({
				{0.46226,	0.81687,	-0.34503,	0.83054},
				{-0.84134,	0.28111,	-0.46166,	-0.32336},
				{-0.28012,	0.50369,	0.81720,	-1.31165},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				
		},
		["ak_hold"] = {
			['ValveBiped.Anim_Attachment_RH'] = Matrix({
				{0.00000,	0.00000,	1.00000,	2.67609},
				{-1.00000,	0.00000,	0.00000,	-1.71246},
				{-0.00000,	-1.00000,	0.00000,	0.00001},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger22'] = Matrix({
				{-0.93110,	0.35667,	-0.07637,	5.55057},
				{-0.31636,	-0.89387,	-0.31766,	-1.13599},
				{-0.18157,	-0.27162,	0.94512,	-0.15542},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger21'] = Matrix({
				{-0.01361,	0.98969,	-0.14256,	5.56694},
				{-0.99768,	-0.02294,	-0.06406,	0.07037},
				{-0.06667,	0.14136,	0.98771,	-0.07480},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger2'] = Matrix({
				{0.97992,	0.04619,	-0.19397,	3.88194},
				{-0.04384,	0.99890,	0.01639,	0.14563},
				{0.19451,	-0.00755,	0.98087,	-0.40927},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger12'] = Matrix({
				{-0.79259,	0.58780,	0.16215,	5.92789},
				{-0.55895,	-0.80666,	0.19203,	-1.24103},
				{0.24368,	0.06157,	0.96790,	-1.39973},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger11'] = Matrix({
				{0.34147,	0.92588,	0.16172,	5.55243},
				{-0.93122,	0.30995,	0.19173,	-0.21698},
				{0.12739,	-0.21607,	0.96803,	-1.53982},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger1'] = Matrix({
				{0.97941,	0.12047,	0.16201,	3.86839},
				{-0.15089,	0.96993,	0.19095,	0.04248},
				{-0.13414,	-0.21146,	0.96814,	-1.30919},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger02'] = Matrix({
				{0.99105,	-0.07199,	0.11238,	3.21292},
				{0.12515,	0.79369,	-0.59531,	-1.61768},
				{-0.04634,	0.60405,	0.79560,	-2.40306},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger01'] = Matrix({
				{0.93794,	0.33772,	0.07876,	2.08080},
				{-0.22747,	0.77058,	-0.59537,	-1.34314},
				{-0.26176,	0.54050,	0.79958,	-2.08714},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),
				['ValveBiped.Bip01_R_Finger0'] = Matrix({
				{0.69854,	0.71442,	0.04055,	0.83058},
				{-0.56973,	0.58957,	-0.57255,	-0.32349},
				{-0.43295,	0.37685,	0.81887,	-1.31225},
				{0.00000,	0.00000,	0.00000,	1.00000},
				}),

		},
	}

	function hg.set_hold(ent, hold)
		local lhmat = ent:GetBoneMatrix(ent:LookupBone("ValveBiped.Bip01_L_Hand"))
		for bone,invmat in pairs(hand_poses[hold]) do
			bone = isstring(bone) and ent:LookupBone(bone) or bone
			if not bone or isstring(bone) or bone == -1 then continue end
			if not ent:GetBoneMatrix(bone) then continue end
			ent:SetBoneMatrix(bone,lhmat * invmat)
		end
	end

	function hg.set_holdrh(ent,hold)
		local lhmat = ent:GetBoneMatrix(ent:LookupBone("ValveBiped.Bip01_R_Hand"))
		for bone,invmat in pairs(hand_posesrh[hold]) do
			bone = isstring(bone) and ent:LookupBone(bone) or bone
			if not bone or isstring(bone) or bone == -1 then continue end
			if not ent:GetBoneMatrix(bone) then continue end
			ent:SetBoneMatrix(bone,lhmat * invmat)
		end
	end

	function hg.copy_hold(ply)
		local lh = ply:LookupBone("ValveBiped.Bip01_L_Hand")
		local lhmat = ply:GetBoneMatrix(lh)
		print("\n")
		for i,bone in pairs(hg.get_children(ply,lh)) do
			local bon = ply:GetBoneName(bone)
			print("['"..bon.."'] = Matrix({\n"..string.Replace(string.Replace(tostring(lhmat:GetInverse() * ply:GetBoneMatrix(bone)),"[","{"),"]","},").."\n}),")
		end
		print("\n")
	end

	function hg.copy_holdrh(ply)
		local lh = ply:LookupBone("ValveBiped.Bip01_R_Hand")
		local lhmat = ply:GetBoneMatrix(lh)
		print("\n")
		for i,bone in pairs(hg.get_children(ply,lh)) do
			local bon = ply:GetBoneName(bone)
			print("['"..bon.."'] = Matrix({\n"..string.Replace(string.Replace(tostring(lhmat:GetInverse() * ply:GetBoneMatrix(bone)),"[","{"),"]","},").."\n}),")
		end
		print("\n")
	end

	local hg_tpik_distance = ConVarExists("hg_tpik_distance") and GetConVar("hg_tpik_distance") or CreateClientConVar("hg_tpik_distance",1024,true,false,"The distance (in hammer units) at which the third person inverse kinematics enables, 0 = inf",0,2048)

	function hg.ShouldTPIK(ply,wpn)
		local int = hg_tpik_distance:GetInt()
		if (int == 0 or ply == LocalPlayer() or ply == LocalPlayer():GetNWEntity("spect")) then return true end
		local view = render.GetViewSetup(true)
		if (ply:GetPos():DistToSqr(view.origin) > int*int) then return false end
		return true
	end

	--copy hold делаешь когда нужно скопировать пальчики левой руки
	--set hold когда хочешь чтобы пальчики встали ровно как надо по копии (и не двигались)
	--hg.copy_hold(Entity(1))
end

--\\Weighted Random Select
function hg.WeightedRandomSelect(tab, mul)
	if not tab or not istable(tab) then return end
	mul = mul or 1
	local total_weight = 0
	
	for i = 1, #tab do
		total_weight = total_weight + tab[i][1]
	end
	
	local random_weight = math.Rand(total_weight * (mul - 1), total_weight)
	local current_weight = 0
	
	for i = 1, #tab do
		current_weight = current_weight + tab[i][1]
		
		if(current_weight >= random_weight)then
			return i, tab[i][2]
		end
	end	
end
--//

if CLIENT then
	hg.oldClientsideModel = hg.oldClientsideModel or ClientsideModel

	hg.ClientsideModels = hg.ClientsideModels or {}

	function ClientsideModel(...)
		local model = hg.oldClientsideModel(...)

		table.insert(hg.ClientsideModels,model)

		return model
	end

	function hg.PrintModels()
		for i,mdl in ipairs(hg.ClientsideModels) do
			if not IsValid(mdl) then continue end
			print(mdl,mdl:GetModel())
		end
	end

	function hg.ClearClientsideModels()
		for i,mdl in pairs(hg.ClientsideModels) do
			if not IsValid(mdl) then table.remove(hg.ClientsideModels,i) continue end
			mdl:Remove()
			table.remove(hg.ClientsideModels,i)
		end
	end

	hook.Add("PostCleanupMap","fuckclientsidemodels",hg.ClearClientsideModels)
end

function qerp(delta, a, b)
    local qdelta = -(delta ^ 2) + (delta * 2)
    qdelta = math.Clamp(qdelta, 0, 1)

    return Lerp(qdelta, a, b)
end

local queue = {} -- i follow you
hg.prechachesound = hg.prechachesound or {}
function hg.PrecahceSound(name)
	if hg.prechachesound[name] then return end
	if not hg.initents then
		queue[#queue + 1] = name
	else
		game.GetWorld():EmitSound(name, 75, 100, 1, CHAN_AUTO, SND_STOP)
	end
	--hg.prechachesound[name] = true
end

hook.Add("Initialize", "homigrad-prechache", function()
	for i, name in pairs(queue) do
		game.GetWorld():EmitSound(name)
	end
end)

FrameTimeClamped = 1/66
ftlerped = 1/66

local def = 1 / 144

local FrameTime, TickInterval, engine_AbsoluteFrameTime = FrameTime, engine.TickInterval, engine.AbsoluteFrameTime
local Lerp, LerpVector, LerpAngle = Lerp, LerpVector, LerpAngle
local math_min = math.min
local math_Clamp = math.Clamp

local host_timescale = game.GetTimeScale

hook.Add("Think", "Mul lerp", function()
	local ft = FrameTime()
	ftlerped = Lerp(0.5,ftlerped,math_Clamp(ft,0.001,0.1))
end)

function hg.FrameTimeClamped(ft)
	--do return math.Clamp(ft or ftlerped,0.001,0.1) end
	return math_Clamp(1 - math.exp(-0.5 * (ft or ftlerped) * host_timescale()), 0.000, 0.01)
end

--[[function hg.FrameTimeClamped(ft)
	--do return math.Clamp(ftlerped,0.001,0.016) end
	return math_Clamp(1 - (0.5 ^ (ft or ftlerped)), 0.001, 0.016)
end--]]

local FrameTimeClamped_ = hg.FrameTimeClamped

local perf = physenv.GetPerformanceSettings()
perf.MaxVelocity = 100000 --default 2000
physenv.SetPerformanceSettings(perf)
--physenv.SetAirDensity(2)
--PrintTable(physenv.GetPerformanceSettings())

local function lerpFrameTime(lerp,frameTime)
	return math_Clamp(1 - lerp ^ (frameTime or FrameTime()), 0, 1)-- * (host_timescale())
end

local function lerpFrameTime2(lerp,frameTime)
	--do return math_Clamp(lerp * ftlerped * 150,0,1) end
	--do return math_Clamp(1 - lerp ^ ftlerped,0,1) end
	return math_Clamp(lerp * FrameTimeClamped_(frameTime) * 150, 0, 1)-- * (host_timescale())
end

hg.lerpFrameTime2 = lerpFrameTime2
hg.lerpFrameTime = lerpFrameTime

function LerpFT(lerp, source, set)
	return Lerp(lerpFrameTime2(lerp), source, set)
end

function LerpVectorFT(lerp, source, set)
	return LerpVector(lerpFrameTime2(lerp), source, set)
end

function LerpAngleFT(lerp, source, set)
	return LerpAngle(lerpFrameTime2(lerp), source, set)
end

local max, min = math.max, math.min
function util.halfValue(value, maxvalue, k)
	k = maxvalue * k
	return max(value - k, 0) / k
end

function util.halfValue2(value, maxvalue, k)
	k = maxvalue * k
	return min(value / k, 1)
end

function util.safeDiv(a, b)
	if a == 0 and b == 0 then
		return 0
	else
		return a / b
	end
end

function player.GetListByName(name)
	local list = {}
	if name == "^" then
		return
	elseif name == "*" then
		return player.GetAll()
	end

	for i, ply in pairs(player.GetAll()) do
		if string.find(string.lower(ply:Name()), string.lower(name)) then list[#list + 1] = ply end
	end
	return list
end

function hg.spiralGrid(rings)
	local grid = {}
	local col, row

	for ring=1, rings do -- For each ring...
		row = ring
		for col=1-ring, ring do -- Walk right across top row
			table.insert( grid, {col, row} )
		end

		col = ring
		for row=ring-1, -ring, -1 do -- Walk down right-most column
			table.insert( grid, {col, row} )
		end

		row = -ring
		for col=ring-1, -ring, -1 do -- Walk left across bottom row
			table.insert( grid, {col, row} )
		end

		col = -ring
		for row=1-ring, ring do -- Walk up left-most column
			table.insert( grid, {col, row} )
		end
	end

	return grid
end

function hg.clamp(vecOrAng, val)
	vecOrAng[1] = math.Clamp(vecOrAng[1], -val, val)
	vecOrAng[2] = math.Clamp(vecOrAng[2], -val, val)
	vecOrAng[3] = math.Clamp(vecOrAng[3], -val, val)
	return vecOrAng
end

if CLIENT then
	local PUNCH_DAMPING = 9
	local PUNCH_SPRING_CONSTANT = 95
	vp_punch_angle = vp_punch_angle or Angle()
	local vp_punch_angle_velocity = Angle()
	vp_punch_angle_last = vp_punch_angle_last or vp_punch_angle

	vp_punch_angle2 = vp_punch_angle2 or Angle()
	local vp_punch_angle_velocity2 = Angle()
	vp_punch_angle_last2 = vp_punch_angle_last2 or vp_punch_angle2

	local PLAYER = FindMetaTable("Player")

	local seteyeangles = PLAYER.SetEyeAngles
	local fuck_you_debil = 0

	hook.Add("Think", "viewpunch_think", function()
		--if LocalPlayer():InVehicle() then return end

		if not vp_punch_angle:IsZero() or not vp_punch_angle_velocity:IsZero() then
			vp_punch_angle = vp_punch_angle + vp_punch_angle_velocity * ftlerped
			local damping = 1 - (PUNCH_DAMPING * ftlerped)
			if damping < 0 then damping = 0 end
			vp_punch_angle_velocity = vp_punch_angle_velocity * damping
			local spring_force_magnitude = PUNCH_SPRING_CONSTANT * ftlerped
			vp_punch_angle_velocity = vp_punch_angle_velocity - vp_punch_angle * spring_force_magnitude
			local x, y, z = vp_punch_angle:Unpack()
			vp_punch_angle = Angle(math.Clamp(x, -89, 89), math.Clamp(y, -179, 179), math.Clamp(z, -89, 89))
		else
			vp_punch_angle = Angle()
			vp_punch_angle_velocity = Angle()
		end

		local ang = LocalPlayer():EyeAngles() + vp_punch_angle - vp_punch_angle_last
		--LocalPlayer():SetEyeAngles(ang)

		--

		if not vp_punch_angle2:IsZero() or not vp_punch_angle_velocity2:IsZero() then
			vp_punch_angle2 = vp_punch_angle2 + vp_punch_angle_velocity2 * ftlerped
			local damping = 1 - (PUNCH_DAMPING * ftlerped)
			if damping < 0 then damping = 0 end
			vp_punch_angle_velocity2 = vp_punch_angle_velocity2 * damping
			local spring_force_magnitude = PUNCH_SPRING_CONSTANT * ftlerped
			vp_punch_angle_velocity2 = vp_punch_angle_velocity2 - vp_punch_angle2 * spring_force_magnitude
			local x, y, z = vp_punch_angle2:Unpack()
			vp_punch_angle2 = Angle(math.Clamp(x, -89, 89), math.Clamp(y, -179, 179), math.Clamp(z, -89, 89))
		else
			vp_punch_angle2 = Angle()
			vp_punch_angle_velocity2 = Angle()
		end

		--if not LocalPlayer():Alive() then vp_punch_angle:Zero() vp_punch_angle_velocity:Zero() vp_punch_angle2:Zero() vp_punch_angle_velocity2:Zero() end

		if vp_punch_angle:IsZero() and vp_punch_angle_velocity:IsZero() and vp_punch_angle2:IsZero() and vp_punch_angle_velocity2:IsZero() then return end
		local ang = LocalPlayer():EyeAngles() + vp_punch_angle - vp_punch_angle_last

		LocalPlayer():SetEyeAngles(ang + vp_punch_angle2 - vp_punch_angle_last2)
		vp_punch_angle_last = vp_punch_angle
		vp_punch_angle_last2 = vp_punch_angle2
	end)

	function SetViewPunchAngles(angle)
		if not angle then
			print("[Local Viewpunch] SetViewPunchAngles called without an angle. wtf?")
			return
		end

		vp_punch_angle = angle
	end

	function SetViewPunchVelocity(angle)
		if not angle then
			print("[Local Viewpunch] SetViewPunchVelocity called without an angle. wtf?")
			return
		end

		vp_punch_angle_velocity = angle * 20
	end

	function Viewpunch(angle)
		if not angle then
			print("[Local Viewpunch] Viewpunch called without an angle. wtf?")
			return
		end

		vp_punch_angle_velocity = vp_punch_angle_velocity + angle * 20
	end

	function Viewpunch2(angle)
		if not angle then
			print("[Local Viewpunch] Viewpunch called without an angle. wtf?")
			return
		end

		vp_punch_angle_velocity2 = vp_punch_angle_velocity2 + angle * 20
	end

	function ViewPunch(angle)
		Viewpunch(angle)
	end

	function ViewPunch2(angle)
		Viewpunch2(angle)
	end

	function GetViewPunchAngles()
		return vp_punch_angle
	end

	function GetViewPunchAngles2()
		return vp_punch_angle2
	end

	function GetViewPunchVelocity()
		return vp_punch_angle_velocity
	end

	local angle_hitground = Angle(0, 0, 0)
	hook.Add("OnPlayerHitGround", "sadsafsafas", function(ply, water, floater, speed)
		--[[if ply == LocalPlayer() then
			angle_hitground.p = speed / 50
			ViewPunch(angle_hitground)
		end--]]
	end)

	local prev_on_ground,current_on_ground,speedPrevious,speed = false,false,0,0
	local angle_hitground = Angle(0,0,0)
	hook.Add("Think", "CP_detectland", function()
		prev_on_ground = current_on_ground
		current_on_ground = LocalPlayer():OnGround()

		speedPrevious = speed
		speed = -LocalPlayer():GetVelocity().z

		if prev_on_ground != current_on_ground and current_on_ground and LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP then
			angle_hitground.p = math.Clamp(speedPrevious / 25, 0, 20)

			ViewPunch(angle_hitground)
		end
	end)
end

function GAMEMODE:HandlePlayerLanding( ply, velocity, WasOnGround )
	if SERVER then return end
	if ply == LocalPlayer() and ply == GetViewEntity() then return end

	if ( ply:GetMoveType() == MOVETYPE_NOCLIP ) then return end

	if ( ply:IsOnGround() && !WasOnGround ) then
		ply:AnimRestartGesture( GESTURE_SLOT_JUMP, ACT_LAND, true )
	end

end

function hg.IsOnGround(ent)
	local tr = {}
	tr.start = ent:GetPos()
	tr.endpos = ent:GetPos() - vector_up * 10
	tr.filter = ent
	tr.mask = MASK_PLAYERSOLID
	return util.TraceEntityHull(tr,ent).Hit
end

local vecOffsetDuck = Vector(0, 0, 38)
local hull = 10
gameevent.Listen("player_spawn")
DEFAULT_JUMP_POWER = 1000
hook.Add("player_spawn", "homigrad-spawn3", function(data)
	local ply = Player(data.userid)
	if not IsValid(ply) then return end
	if CLIENT and ply == LocalPlayer() then
		vp_punch_angle = Angle()
		vp_punch_angle_last = Angle()
		vp_punch_angle2 = Angle()
		vp_punch_angle_last2 = Angle()
	end

	timer.Simple(0, function()
		ply:SetWalkSpeed(100)
		ply:SetRunSpeed(350)

		if CurrentRound and CurrentRound() and CurrentRound().Type and CurrentRound().Type == "supermario" then

		else
			ply:SetJumpPower(DEFAULT_JUMP_POWER)
		end

		ply:SetSlowWalkSpeed(60)
		ply:SetLadderClimbSpeed(150)
		ply:SetCrouchedWalkSpeed(60)
		ply:SetDuckSpeed(0.4)
		ply:SetUnDuckSpeed(0.4)
		ply:AddEFlags(EFL_NO_DAMAGE_FORCES)
	end)

	ply:SetNWEntity("spect", NULL)
	if CLIENT and ply:Alive() then ply:BoneScaleChange() end

	ply:SetHull(-Vector(hull, hull, 0), Vector(hull, hull, 72))
	ply:SetHullDuck(-Vector(hull, hull, 0), Vector(hull, hull, 36))
	ply:SetViewOffset(Vector(0, 0, 64))
	ply:SetViewOffsetDucked(Vector(0, 0, 34))
	ply:DrawShadow(true)
	ply:SetRenderMode(RENDERMODE_NORMAL)
	local ang = ply:EyeAngles()
	ang[3] = 0
	ply:SetEyeAngles(ang)
	ply.suiciding = false

	ply.RenderOverride = function(self)
		local ent = hg.GetCurrentCharacter(self)
		if ent ~= self then return end
		self:SetupBones()
		hook.Run("PreDrawPlayerRagdoll", ent, self)
		hook.Run("DrawPlayerRagdoll", ent, self)

		--hook.Run("TPIKDrawPlayerRagdoll",ent,self)

		hook.Run("PostDrawPlayerRagdoll", ent, self)

		--hook.Run("DrawPlayerOverlay", ent, self)

		if not ply.headmat then self:DrawModel() end
		hook.Run("DrawAppearance", ent, self)
		if ply.headmat then self:DrawModel() end
	end

	hook.Run("Player Getup", ply)

	local override = (CLIENT and hg.override[ply]) or (SERVER and OverrideSpawn)
	
	if not override then
		hook.Run("Player Spawn", ply)
		ply:RemoveFlags(FL_NOTARGET)
	end

	if IsValid(ply) and ply:Alive() and not IsValid(ply.bull) and SERVER then
		timer.Simple(1, function()
			if not IsValid(ply) or not ply:Alive() then return end
			ply.bull = ents.Create("npc_bullseye")
			local bull = ply.bull
			local bon = ply:LookupBone("ValveBiped.Bip01_Head1")
			local mat = bon and ply:GetBoneMatrix(bon)
			local pos = mat and mat:GetTranslation() or ply:EyePos()
			local ang = mat and mat:GetAngles() or ply:EyeAngles()
			bull:SetPos(pos)
			bull:SetAngles(ang)
			bull:SetMoveType(MOVETYPE_OBSERVER)
			bull:SetKeyValue("targetname", "Bullseye")
			bull:SetParent(ply, ply:LookupBone("ValveBiped.Bip01_Head1"))
			bull:SetKeyValue("health", "9999")
			bull:SetKeyValue("spawnflags", "256")
			bull:Spawn()
			bull:Activate()
			bull:SetNotSolid(true)
			--bull:SetSolidFlags(FSOLID_TRIGGER)
			--bull:SetCollisionGroup(COLLISION_GROUP_PLAYER)

			bull.ply = ply
			for i, ent in ipairs(ents.FindByClass("npc_*")) do
				if not IsValid(ent) or not ent.AddEntityRelationship then continue end
				ent:AddEntityRelationship(bull, ent:Disposition(ply))
			end
		end)
	end
end)



hook.Add("HomigradRun","igroki_nasral",function()
	local entities = ents.FindByClass("prop_ragdoll")
	table.Add(entities, player.GetAll())
	for i,ply in ipairs(entities) do
		ply.RenderOverride = function(self)
			local ent = hg.GetCurrentCharacter(self)
			if ent ~= self then return end
			self:SetupBones()
			hook.Run("PreDrawPlayerRagdoll",ent,self)
			hook.Run("DrawPlayerRagdoll",ent,self)
			
			--hook.Run("TPIKDrawPlayerRagdoll",ent,self)

			hook.Run("PostDrawPlayerRagdoll",ent,self)

			--hook.Run("DrawPlayerOverlay", ent, self)

			--hook.Run("SetposAppearance",ent,self)--nah
			if not ply.headmat then self:DrawModel() end
			hook.Run("DrawAppearance",ent,self)
			if ply.headmat then self:DrawModel() end
		end
	end
end)

if CLIENT then
	hook.Add("NetworkEntityCreated", "network_ragdoll_created", function(ent)
		local index = ent:EntIndex()
		if IsValid(ent) and zb.net and zb.net[index] and zb.net[index].waiting then
			zb.net[index].waiting = nil
			for key,var in pairs(zb.net[index]) do
				hook.Run("OnNetVarSet", index, key, var)
			end
		end
	end)
end

hook.Add("Player Think", "homigrad-viewoffset", function(ply)
	if not ply:Alive() then
		if IsValid(ply.bull) then
			ply.bull:Remove()
			ply.bull = nil
		end
	end
	--[[if not IsValid(ply.FakeRagdoll) then
		local tr = hg.eyeTrace(ply)
		if not tr then return end
		local offset = tr.StartPos - ply:GetPos()
		local eyepos = ply:EyePos() - ply:GetPos()
		eyepos[3] = offset[3]
		ply:SetCurrentViewOffset(eyepos)
		--ply:SetViewOffset(eyepos)
		--ply:SetViewOffsetDucked(eyepos)
	else
		local bon = ply.FakeRagdoll:LookupBone("ValveBiped.Bip01_Head1")
		if not bon then return end
		local mat = ply.FakeRagdoll:GetBoneMatrix(bon)
		if not mat then return end
		local offset = mat:GetTranslation() - ply:GetPos()
		ply:SetCurrentViewOffset(offset)
		--ply:SetViewOffset(offset)
		--ply:SetViewOffsetDucked(offset)
	end--]]
end)

if CLIENT then
	oldlean = oldlean or 0
	lean_lerp = lean_lerp or 0
	curlean = curlean or 0
	unmodified_angle = unmodified_angle or 0
	hook.Add("Think", "leanin", function()
		local ply = LocalPlayer()
		local angles = ply:EyeAngles()

		local lean = (ply.lean or 0)
		lean_lerp = Lerp(10 * FrameTime(),lean_lerp,lean)

		if IsValid(ply.FakeRagdoll) then ply.lean = 0 lean_lerp = 0 end

		angles[3] = angles[3] + lean_lerp * 10 - oldlean
		oldlean = lean_lerp * 10

		ply:SetEyeAngles(angles)
	end)
end

hook.Add("Player Spawn","default-thingies",function(ply)
	if OverrideSpawn then return false end
end)

gameevent.Listen("player_disconnect")
hook.Add("player_disconnect", "hg-disconnect", function(data)
	hook.Run("Player Disconnected",data)
end)

gameevent.Listen( "player_activate" )
hook.Add("player_activate","player_activatehg",function(data)
	local ply = Player(data.userid)
	if not IsValid(ply) then return end

	hook.Run("Player Activate", ply)
	if SERVER and ply.SyncVars then ply:SyncVars() end
end)

gameevent.Listen("entity_killed")
hook.Add("entity_killed", "homigrad-death", function(data)
	local ply = Entity(data.entindex_killed)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	hook.Run("Player Death", ply)
end)

--\\supression

if CLIENT then
	local function IsLookingAt(ply, targetVec)
		if not IsValid(ply) or not ply:IsPlayer() then return false end
		local diff = targetVec - ply:GetShootPos()
		return ply:GetAimVector():Dot(diff) / diff:Length() >= 0.8
	end
	suppressionVec = Vector(0, 0, 0)
	suppressionDist = 0
	suppressionDistAdd = 0
	local angSupr = Angle(0, 0, 0)
	net.Receive("add_supression", function()
		local lply = LocalPlayer()
		if not IsValid(lply) or not lply:IsPlayer() then return end
		local pos = net.ReadVector()
		local eyePos = LocalPlayer():EyePos()
		local dist = pos:Distance(eyePos)
		local side = (LocalPlayer():EyePos() - pos):GetNormalized()
		local ang = angSupr
		if dist > 500 then return end
		local isVisible = not util.TraceLine({
			start = pos,
			endpos = eyePos,
			filter = {lply},
			mask = MASK_SHOT
		}).Hit
		if not isVisible then dist = dist * 2 end

		Suppress((dist*25))
		ViewPunch(AngleRand(-1,1)*dist/100)
		ViewPunch2(AngleRand(-1,1)*dist/100)
	end)

	local anguse = Angle(0,0,0)
	s_suppression = s_suppression or 0
	hook.Add("PostEntityFireBullets","bulletsuppression2",function(ent,bullet)
		local lply = LocalPlayer()
		if not lply:Alive() then return end
		if not IsValid(lply) or not lply:IsPlayer() then return end
		local tr = bullet.Trace
		--debugoverlay.Line(tr.StartPos,tr.HitPos,1,color_white)
		local self = ent
		if tr.Entity == hg.GetCurrentCharacter(lply) then
			ViewPunch(AngleRand(-3,2))
			ViewPunch2(AngleRand(-2,3))
			Suppress((10))
			return
		end

		if not IsValid(self) then return end

		local eyePos = lply:EyePos()
		local dis, pos = util.DistanceToLine(tr.StartPos, tr.HitPos, eyePos)
		local isVisible = not util.TraceLine({
			start = pos,
			endpos = eyePos,
			filter = {self, lply, self:GetOwner(), hg.GetCurrentCharacter(lply)},
			mask = MASK_SHOT
		}).Hit

		if not isVisible then return end
		local dist = pos:Distance(eyePos)
		local shooterdist = tr.StartPos:Distance(eyePos)
		local mr = math.random(9)

		if shooterdist < 200 and not IsLookingAt(self:GetOwner(),eyePos) then return end
		if dist < 180 then EmitSound("cracks/light/light_crack_0" .. mr .. ".ogg", pos, 0, CHAN_AUTO, 1,65) end
		if dist > 120 then return end

		EmitSound("cracks/light/light_crack_0" .. mr .. ".ogg", pos, 0, CHAN_AUTO, 1,85)

		dist = dist / math.abs((tr.HitPos - tr.StartPos):GetNormalized():Dot((tr.StartPos - eyePos):GetNormalized()))
		dist = math.Clamp(1 / dist, 0.05,0.25)
		local localpos = (eyePos - pos):GetNormalized()

		local ang_yaw = localpos:Dot(lply:EyeAngles():Right())
		local ang_pitch = localpos:Dot(lply:EyeAngles():Up())

		anguse[2] = -ang_yaw / (dist * 30)
		anguse[1] = -ang_pitch / (dist * 30)

		local badass = lply.organism and lply.organism.recoilmul or 1

		ViewPunch(anguse * badass)
		ViewPunch2(anguse * badass)
		Suppress((dist * 45) * badass)
	end)
	-- SIB - Salatis Imersive Base
	--black fart
	SIB_suppress = SIB_suppress or {}
	SIB_suppress.Force = 0

	function Suppress(force)
		SIB_suppress.Force = math.Clamp(SIB_suppress.Force + force/1,0,10)
	end

	local pain_mat = Material("sprites/mat_jack_hmcd_narrow")

	local colormodify = {
		[ "$pp_colour_addr" ] = 0,
		[ "$pp_colour_addg" ] = 0,
		[ "$pp_colour_addb" ] = 0,
		[ "$pp_colour_brightness" ] = 0,
		[ "$pp_colour_contrast" ] = 1,
		[ "$pp_colour_colour" ] = 0,
		[ "$pp_colour_mulr" ] = 0,
		[ "$pp_colour_mulg" ] = 0,
		[ "$pp_colour_mulb" ] = 0
	}

	hook.Add("RenderScreenspaceEffects","SIB_Suppresss",function()
		if not LocalPlayer():Alive() then return end

		local fraction = math.Clamp(SIB_suppress.Force/5,0,1)

		local force = SIB_suppress.Force - 1
		if force > 0 then
			--local blur = math.max(force,0) / 100
			--if blur > 0 then
				--DrawMaterialOverlay( "sprites/mat_jack_hmcd_scope_aberration", blur )
			--end
			surface.SetDrawColor(0, 0, 0, math.min((force/7) * 255,255))
			surface.SetMaterial(pain_mat)
			surface.DrawTexturedRect(-1, -1, ScrW()+1, ScrH()+1)
		end
		if force > 6 then
			colormodify["$pp_colour_colour"] = math.max(2 - force/6,.4)
			DrawColorModify(colormodify)
		end

		DrawToyTown(fraction,ScrH() * fraction / 1.5)

		--DrawSharpen(8,SIB_suppress.Force / 7)
	end)

	hook.Add("Think","SIB_Suppresss_Think",function()
		SIB_suppress.Force = Lerp(0.25*FrameTime(),SIB_suppress.Force,0)
	end)

	hook.Add("PlayerDeath","huyDeathRemoveSuppression",function()
		SIB_suppress.Force = 0
	end)

	hook.Add("InitPostEntity", "SIB_ShootEffects_load", function()
		if not GetConVar("mat_motion_blur_enabled"):GetBool() then
			LocalPlayer():ConCommand("mat_motion_blur_enabled 1")
			LocalPlayer():ConCommand("mat_motion_blur_strength 2")
		end
	end)

end

--//

local lend = 2
local vec = Vector(lend,lend,lend)
local traceBuilder = {
	mins = -vec,
	maxs = vec,
	mask = MASK_SOLID,
	collisiongroup = COLLISION_GROUP_DEBRIS
}

local util_TraceHull = util.TraceHull

function hg.hullCheck(startpos,endpos,ply)
	if ply:InVehicle() then return {HitPos = endpos} end
	traceBuilder.start = IsValid(ply.FakeRagdoll) and endpos or startpos
	traceBuilder.endpos = endpos
	traceBuilder.filter = {ply,hg.GetCurrentCharacter(ply)}
	local trace = util_TraceHull(traceBuilder)

	return trace
end

local lpos = Vector(0,0,0)--Vector(5,0,7)
local lang = Angle(0,0,0)

function hg.torsoTrace(ply, dist, ent, aim_vector)
	local ent = IsValid(ent) and ent or hg.GetCurrentCharacter(ply)
	local bon = ent:LookupBone("ValveBiped.Bip01_Spine4")
	if not bon then return end
	local mat = ent:GetBoneMatrix(bon)
	if not mat then return end

	local aim_vector = aim_vector or ply:GetAimVector()

	local pos, ang = LocalToWorld(lpos, lang, mat:GetTranslation(), aim_vector:Angle())

	return hg.eyeTrace(ply, dist, ent, aim_vector, pos)
end

function hg.eyeTrace(ply, dist, ent, aim_vector, startpos)
	local fakeCam = IsValid(ply.FakeRagdoll)
	local ent = IsValid(ent) and ent or hg.GetCurrentCharacter(ply)
	local bon = ent:LookupBone("ValveBiped.Bip01_Head1")
	if not bon then return end
	if not IsValid(ply) then return end
	if not ply.GetAimVector then return end
	
	local aim_vector = aim_vector or ply:GetAimVector()

	if not bon or not ent:GetBoneMatrix(bon) then
		local tr = {
			start = ply:EyePos(),
			endpos = ply:EyePos() + aim_vector * (dist or 60),
			filter = ply
		}
		return util.TraceLine(tr)
	end

	if (ply.InVehicle and ply:InVehicle() and IsValid(ply:GetVehicle())) then
		local veh = ply:GetVehicle()
		local vehang = veh:GetAngles()
		local tr = {
			start = ply:EyePos() + vehang:Right() * -6 + vehang:Up() * 4,
			endpos = ply:EyePos() + aim_vector * (dist or 60),
			filter = ply
		}
		return util.TraceLine(tr), nil, headm
	end

	local headm = ent:GetBoneMatrix(bon)

	if CLIENT and ply.headmat then headm = ply.headmat end

	--local att_ang = ply:GetAttachment(ply:LookupAttachment("eyes")).Ang
	--ply.lerp_angle = LerpFT(0.1, ply.lerp_angle or Angle(0,0,0), ply:GetNWBool("TauntStopMoving", false) and att_ang or aim_vector:Angle())
	--aim_vector = ply.lerp_angle:Forward()

	local eyeAng = aim_vector:Angle()

	local eyeang2 = aim_vector:Angle()
	eyeang2.p = 0

	local pos = startpos or headm:GetTranslation() + (fakeCam and (headm:GetAngles():Forward() * 2 + headm:GetAngles():Up() * -2 + headm:GetAngles():Right() * 3) or (eyeAng:Up() * 1 + eyeang2:Forward() * 4))
	
	local trace = hg.hullCheck(ply:EyePos(),pos,ply)

	--[[if CLIENT then
		cam.Start3D()
			render.DrawWireframeBox(trace.HitPos,angle_zero,traceBuilder.mins,traceBuilder.maxs,color_white)
		cam.End3D()
	end--]]
	
	local tr = {}
	if !ply:IsPlayer() then return false end
	tr.start = trace.HitPos
	tr.endpos = tr.start + aim_vector * (dist or 60)
	tr.filter = {ply,ent}

	return util.TraceLine(tr), trace, headm
end

local chairclasses = {
	["prop_vehicle_prisoner_pod"] = true,
}

function hg.isdriveablevehicle(veh)
	if not IsValid(veh) then return false end
	
	if chairclasses[veh:GetClass()] then return false end

	return true
end

local hook_Run = hook.Run
local CurTime = CurTime
local player_GetAll = player.GetAll

lastcall = SysTime() - 0.01

function hg.RagdollOwner(ply)
	if not ply:IsPlayer() then return end

	return ply.FakeRagdoll or ply
end

hook.Add("Think", "hg-playerthink", function()
	--local players = player_GetAll()
	local time = CurTime()

	local dtime = SysTime() - lastcall
	lastcall = SysTime()

	local entities = ents.FindByClass("prop_ragdoll")
	table.Add(entities, player.GetAll())

	if CLIENT then
		for _, ply in ipairs(entities) do
			if not IsValid(ply) then continue end
			--if IsValid(ply.FakeRagdoll) then continue end
			--if hg.RagdollOwner(ply) and hg.RagdollOwner(ply):Alive() then continue end
			if ply:IsPlayer() and not ply:Alive() then continue end

			if ply:GetClass() ~= "prop_ragdoll" then
				hook_Run("Player Think", ply, time, dtime)
				hook_Run("Player-Ragdoll think", ply, time)
			else
				hook_Run("Player-Ragdoll think", ply, time)
			end
		end
	else
		for _, ply in player.Iterator() do
			hook_Run("Player Think", ply, time, dtime)
			hook_Run("Player-Ragdoll think", hg.GetCurrentCharacter(ply), time)
		end

		for _, ent in ipairs(ents.FindByClass("prop_ragdoll")) do
			if hg.RagdollOwner(ent) then continue end
			hook_Run("Player-Ragdoll think", ent, time)
		end
	end
end)

hook.Add("Player Think","FUCKING FUCK YOU",function(ply,time)		
	if (ply.FUCKYOU_TIMER or 0) < time then
		ply.FUCKYOU_TIMER = time + 1

		ply:SetRenderMode(IsValid(ply:GetNWEntity("FakeRagdoll")) and RENDERMODE_NONE or RENDERMODE_NORMAL)
	end
end)

if CLIENT then
	concommand.Add("suicide", function(ply)
		ply.suiciding = not (ply.suiciding or false)
		if not hg.CanSuicide(ply) then ply.suiciding = false return end
		net.Start("suicidehg")
		net.WriteBool(ply.suiciding)
		net.SendToServer()
	end)
	net.Receive("suicidehg", function()
		ply = net.ReadEntity()
		ply.suiciding = net.ReadBool()
	end)
else
	util.AddNetworkString("suicidehg")
	net.Receive("suicidehg", function(len, ply)
		ply.suiciding = net.ReadBool()
		if not hg.CanSuicide(ply) then ply.suiciding = false return end
		if ply.suiciding then ply:SetNetVar("suicide_time",CurTime()+1) end
		net.Start("suicidehg")
		net.WriteEntity(ply)
		net.WriteBool(ply.suiciding)
		net.Broadcast()
	end)
end

function hg.CanSuicide(ply)
	if not IsValid(ply) or not ply.GetActiveWeapon then return false end
	local wep = ply:GetActiveWeapon()
	return ishgweapon(wep) and wep.CanSuicide
end

function hg.CalculateWeight(ply,maxweight)
	local weight = 0

	local weps = ply:GetWeapons()

	for i,wep in ipairs(weps) do
		weight = weight + (wep.weight or 1)
	end

	weight = math.max(weight - 1,0)

	local ammo = ply:GetAmmo()
	for id,count in pairs(ammo) do
		weight = weight + (game.GetAmmoForce(id) * count) / 1500
	end

	ply.armors = ply:GetNetVar("Armor",{})
	for plc,arm in pairs(ply.armors) do
		weight = weight + (hg.armor[plc][arm].mass or 1)
	end

	local weightmul = (1 / (weight / maxweight + 1))
	return weightmul
end

--\\
hook.Add("OnPlayerHitGround", "Movement", function(ply, inWater, onFloater, speed)
	local vel = ply:GetVelocity()

	if(ply.MovementInertia and vel:LengthSqr() > 10000)then
		ply.MovementInertia = ply.MovementInertia + vel * 0.5
	end
end)
--//

--\\Сайд мувы калькуляция для движения ниже
--; Математический анал (не анализ)
local function calc_vector2d_angle(vector)
	return math.deg(math.atan2(vector.y, vector.x))
end

local function calc_forward_side_moves(inertia, ply_angles)
	local ply_angle = ply_angles.y
	local inertia_angle = calc_vector2d_angle(inertia)
	local angdiff = math.AngleDifference(inertia_angle, ply_angle)

	return math.cos(math.rad(angdiff)), -math.sin(math.rad(angdiff))
end

local function calc_forward_side_moves_to_vector2d(fm, sm, ply_angles)
	local ply_angle = ply_angles.y

	local vec = Vector(fm * math.cos(math.rad(ply_angle)) - sm * math.cos(math.rad(ply_angle + 90)), fm * math.sin(math.rad(ply_angle)) - sm * math.sin(math.rad(ply_angle + 90)), 0)

	return vec:GetNormalized()
end

local function approach_vector(vector_from, vector_to, change)
	return Vector(math.Approach(vector_from.x, vector_to.x, change), math.Approach(vector_from.y, vector_to.y, change), math.Approach(vector_from.z, vector_to.z, change))
end

hg.approach_vector = approach_vector
--//

local k = 1
local vecZero = Vector(0, 0, 0)

hg.IdealMassPlayer = {
	["ValveBiped.Bip01_Pelvis"] = 12.775918006897,
	["ValveBiped.Bip01_Spine2"] = 24.36336517334,
	["ValveBiped.Bip01_R_UpperArm"] = 3.4941370487213,
	["ValveBiped.Bip01_L_UpperArm"] = 3.441034078598,
	["ValveBiped.Bip01_L_Forearm"] = 1.7655730247498,
	["ValveBiped.Bip01_L_Hand"] = 1.0779889822006,
	["ValveBiped.Bip01_R_Forearm"] = 1.7567429542542,
	["ValveBiped.Bip01_R_Hand"] = 1.0214320421219,
	["ValveBiped.Bip01_R_Thigh"] = 10.212161064148,
	["ValveBiped.Bip01_R_Calf"] = 4.9580898284912,
	["ValveBiped.Bip01_Head1"] = 5.169750213623,
	["ValveBiped.Bip01_L_Thigh"] = 10.213202476501,
	["ValveBiped.Bip01_L_Calf"] = 4.9809679985046,
	["ValveBiped.Bip01_L_Foot"] = 2.3848159313202,
	["ValveBiped.Bip01_R_Foot"] = 2.3848159313202
}

local taunt_function_start = {
	[ACT_GMOD_TAUNT_CHEER] = function(ply) ply:SetNWBool("TauntStopMoving", true) ply:SetNWBool("TauntHolsterWeapons", true) end,
	[ACT_GMOD_TAUNT_LAUGH] = function(ply) ply:SetNWBool("TauntStopMoving", true) ply:SetNWBool("TauntHolsterWeapons", true) end,
	[ACT_GMOD_TAUNT_MUSCLE] = function(ply) ply:SetNWBool("TauntStopMoving", true) ply:SetNWBool("TauntHolsterWeapons", true) end,
	[ACT_GMOD_TAUNT_DANCE] = function(ply) print(ply) ply:SetNWBool("TauntStopMoving", true) ply:SetNWBool("TauntHolsterWeapons", true) end,
	[ACT_GMOD_TAUNT_PERSISTENCE] = function(ply) ply:SetNWBool("TauntStopMoving", true) ply:SetNWBool("TauntHolsterWeapons", true) end,
	[ACT_GMOD_GESTURE_TAUNT_ZOMBIE] = function(ply) ply:SetNWBool("TauntStopMoving", true) ply:SetNWBool("TauntHolsterWeapons", true) end,
	[ACT_GMOD_GESTURE_BOW] = function(ply) ply:SetNWBool("TauntStopMoving", true) ply:SetNWBool("TauntHolsterWeapons", true) end,
	[ACT_GMOD_TAUNT_ROBOT] = function(ply) ply:SetNWBool("TauntStopMoving", true) ply:SetNWBool("TauntHolsterWeapons", true) end,
	[ACT_GMOD_GESTURE_AGREE] = function(ply) ply:SetNWBool("TauntLeftHand", true) end,
	[ACT_SIGNAL_HALT] = function(ply) ply:SetNWBool("TauntLeftHand", true) end,
	[ACT_GMOD_GESTURE_BECON] = function(ply) ply:SetNWBool("TauntLeftHand", true) end,
	[ACT_GMOD_GESTURE_DISAGREE] = function(ply) ply:SetNWBool("TauntLeftHand", true) end,
	[ACT_GMOD_TAUNT_SALUTE] = function(ply) ply:SetNWBool("TauntLeftHand", true) end,
	[ACT_GMOD_GESTURE_WAVE] = function(ply) ply:SetNWBool("TauntLeftHand", true) end,
	[ACT_SIGNAL_FORWARD] = function(ply) ply:SetNWBool("TauntLeftHand", true) end,
	[ACT_SIGNAL_GROUP] = function(ply) ply:SetNWBool("TauntLeftHand", true) end,
}

local randomGestures = {
	"wave",
	"salute",
	"halt",
	"group",
	"forward",
	"disagree",
	"agree",
}

local function randomGesture()
	RunConsoleCommand("act", randomGestures[math.random(#randomGestures)])
end

if CLIENT then
	concommand.Add("hg_randomgesture",function()
		randomGesture()
	end)
end

hook.Add("radialOptions", "radialAddGestures", function()
    local ply = LocalPlayer()
    local organism = ply.organism or {}

    if not organism.otrub and hg.GetCurrentCharacter(ply) == ply then
        local tbl = {randomGesture, "Random Gesture"}
        hg.radialOptions[#hg.radialOptions + 1] = tbl
    end
end)

local function stop_taunt(ply)
	ply:SetNWBool("TauntStopMoving", false)
	ply:SetNWBool("TauntLeftHand", false)
	ply:SetNWBool("TauntHolsterWeapons", false)
	ply:SetNWBool("IsTaunting", false)

	if timer.Exists("TauntHG"..ply:EntIndex()) then
		timer.Remove("TauntHG"..ply:EntIndex())
	end

	ply.CurrentActivity = nil
end

hook.Add("PlayerSpawn", "TauntEndHG", function(ply, act, length)
	stop_taunt(ply)
end)

hook.Add("Fake", "TauntEndHG", function(ply)
	stop_taunt(ply)
end)

function GAMEMODE:PlayerShouldTaunt( ply, actid )

	return true

end

hook.Add("PlayerStartTaunt", "TauntRecordHG", function(ply, act, length)
	--print(ply, act, ACT_GMOD_GESTURE_BECON)
	if not taunt_function_start[act] then return end
	
	taunt_function_start[act](ply, act, length)
	ply:SetNWBool("IsTaunting", true)

	ply.CurrentActivity = act

	timer.Create("TauntHG"..ply:EntIndex(), length - 0.3, 1, function()
		if not ply:GetNWBool("IsTaunting", false) then return end

		stop_taunt(ply)

		ply:SetNWBool("IsTaunting", false)
	end)
end)

-- MANUAL PICKUP
hook.Add( "PlayerCanPickupWeapon", "CanPickup", function( ply, weapon )
	if weapon.IsSpawned then
		if not ply:KeyPressed(IN_USE) then return false end
	end
	if ( ply:HasWeapon( weapon:GetClass() ) ) then
		return false
	end
end )

hook.Add("PlayerDroppedWeapon", "ManualPickup", function(owner, wep)
	wep.IsSpawned = true
end)

hook.Add("PlayerSpawnedSWEP", "ManualPickup", function(ply, wep) wep.IsSpawned = true end)

--function GAMEMODE:PlayerStartTaunt( ply, act, length )

--end

--[[hook.Add("VehicleMove","fuckyougordon",function(ply,veh,mv)
	local wep = ply:GetActiveWeapon()
	print(IsValid(wep) and ishgweapon(wep) and wep.reload,CLIENT)
	if IsValid(wep) and ishgweapon(wep) and wep.reload then
		mv:SetSideSpeed(0)
		return true
	end
end)--]]--говно не работает

hook.Add("StartCommand", "HG(StartCommand)", function(ply, cmd)
	-- if(1)then return end
	
	--\\DeltaTime
	ply.LastStartCommand = ply.LastStartCommand or SysTime()
	local delta_time = SysTime() - ply.LastStartCommand--FrameTime()
	ply.LastStartCommand = SysTime()
	--//

	if(not IsValid(ply) or not ply:Alive())then
		return
	end

	local org = ply.organism

	if( ( not org ) )then
		return
	end

	if(ply:GetMoveType() == MOVETYPE_NOCLIP)then
		return
	end

	local wep = ply:GetActiveWeapon()
	local vel = ply:GetVelocity()
	local velLen = vel:Length()
	local fm = cmd:GetForwardMove() * (org.brain and org.brain > 0.1 and math.sin(CurTime() / 2) or 1)
	local sm = cmd:GetSideMove() * (org.brain and org.brain > 0.1 and math.sin(CurTime() / 2) or 1)
	local runnin = ply:KeyDown(IN_SPEED) and not ply:Crouching()
	local slow_walking = ply:KeyDown(IN_WALK)
	local aiming = ply:KeyDown(IN_ATTACK2) and wep and IsValid(wep) and ishgweapon(wep)
	local walk_speed = ply:GetWalkSpeed()
	local slow_walk_speed = ply:GetSlowWalkSpeed()
	local crouch_walk_speed = ply:GetCrouchedWalkSpeed()
	local weightmul = hg.CalculateWeight(ply, 140)
	ply.weightmul = weightmul
	weightmul = math.max(weightmul > 0.9 and 1 or weightmul / 0.9, 0.1)
	
	if ply:GetNWBool("TauntStopMoving", false) then
		fm = 0
		sm = 0
	end

	if ply:GetNWBool("TauntHolsterWeapons", false) then
		cmd:SelectWeapon(ply:GetWeapon("weapon_hands_sh"))
	end

	--\\Running
	ply.CurrentSpeed = ply.CurrentSpeed or walk_speed
	ply.CurrentFrictionMul = ply.CurrentFrictionMul or 1
	ply.FrictionGainMul = 0.01
	ply.FrictionLoseMul = 0.2
	ply.SpeedGainMul = 240 * weightmul * (ply.organism.superfighter and 5 or 1) * (ply.SpeedGainClassMul or 1)
	ply.SpeedLoseMul = 240
	ply.SpeedSharpLoseMul = 0.007
	ply.InertiaBlend = 2000 * weightmul * ply.CurrentFrictionMul * (ply.organism.superfighter and 100 or 1)
	ply.DuckingSlowdown = ply.DuckingSlowdown or 0
	-- ply.InertiaBlend = 15 * weightmul * ply.CurrentFrictionMul
	local inertia_blend_mul = 1

	-- if(ply:KeyPressed(IN_FORWARD))then
		-- ply.startgaycum = SysTime()
	-- elseif(ply.CurrentSpeed >= 130 and ply.startgaycum)then
		-- print(SysTime() - ply.startgaycum)
		-- ply.startgaycum = nil
	-- end

	if(velLen <= slow_walk_speed)then
		inertia_blend_mul = 3
	end

	--[[
	if ply.WasDucking and not ply:KeyDown(IN_DUCK) then
		ply.WasDucking = false
		ply.DuckingSlowdown = math.Approach(ply.DuckingSlowdown,5,delta_time * 5000)
	end

	ply:SetDuckSpeed(0.4 * (5 - ply.DuckingSlowdown) / 5)
	ply:SetUnDuckSpeed(0.4 * (5 - ply.DuckingSlowdown) / 5)

	ply.WasDucking = ply:KeyDown(IN_DUCK)
	ply.DuckingSlowdown = math.Approach(ply.DuckingSlowdown,0,-delta_time * 1)
	--]]

	ply.InertiaBlend = ply.InertiaBlend * inertia_blend_mul

	hook.Run("HG_MovementCalc", vel, velLen, weightmul, ply, cmd)

	local mul = {(ply.move or ply.CurrentSpeed) / ply:GetRunSpeed()}

	hook.Run("HG_MovementCalc_2", mul, ply, cmd)

	mul = mul[1]
	
	if(runnin and velLen >= 1)then
		ply.CurrentSpeed = math.Approach(ply.CurrentSpeed, ply:GetRunSpeed() * mul, delta_time * ply.SpeedGainMul)
	else
		if(ply:Crouching())then
			ply.CurrentSpeed = math.Approach(ply.CurrentSpeed, crouch_walk_speed * mul, delta_time * ply.SpeedLoseMul)
		elseif(slow_walking)then
			ply.CurrentSpeed = math.Approach(ply.CurrentSpeed, slow_walk_speed * mul, delta_time * ply.SpeedLoseMul)
		elseif(aiming)then
			ply.CurrentSpeed = math.Approach(ply.CurrentSpeed, slow_walk_speed * mul, delta_time * ply.SpeedLoseMul)
		else
			ply.CurrentSpeed = math.Approach(ply.CurrentSpeed, walk_speed * mul, delta_time * ply.SpeedLoseMul)
		end
	end
	--//

	--\\Набор скорости и её потеря
	ply.LastVelocity = ply.LastVelocity or vel
	ply.LastVelocityLen = ply.LastVelocityLen or velLen
	local vel1 = velLen
	local vel2 = ply.LastVelocityLen

	if(vel1 == 0)then
		vel1 = 1
	end

	if(vel2 == 0)then
		vel2 = 1
	end

	local change = math.abs(math.AngleDifference(calc_vector2d_angle(ply.LastVelocity), calc_vector2d_angle(vel)))
	local change_mul = math.abs(ply.CurrentSpeed - slow_walk_speed)
	ply.CurrentSpeed = math.Approach(ply.CurrentSpeed, slow_walk_speed * mul, change * change_mul * ply.SpeedSharpLoseMul)
	ply.LastVelocity = vel
	ply.LastVelocityLen = velLen
	--//

	local speed = ply.CurrentSpeed

	--\\Inertia
	local ply_angles = cmd:GetViewAngles()
	ply.MovementInertia = ply.MovementInertia or vel

	--=\\Штрафы за бег боком и спиной
	fm = fm / math.abs(fm ~= 0 and fm or 1)
	sm = sm / math.abs(sm ~= 0 and sm or 1)
	local movement_penalty = math.abs(sm * 1.1)

	if(movement_penalty == 0)then
		movement_penalty = 1
	end

	if(fm < 0)then
		movement_penalty = math.max(movement_penalty, 1.3)
	end

	if(CLIENT)then
		speed = speed / movement_penalty
	end
	--=//

	local inertia_to = calc_forward_side_moves_to_vector2d(fm, sm, ply_angles) * speed

	--=\\Штрафы за движение в воздухе и в воде
	local water_level = ply:WaterLevel()

	if((not ply:OnGround()) and (water_level < 1))then
		if(fm ~= 0 or sm ~=0)then
			local start_pos = ply:GetPos()
			local trace_data = {
				start = start_pos,
				endpos = start_pos + inertia_to / speed * 50,
				filter = ply
			}

			if(util.TraceLine(trace_data).Hit)then
				movement_penalty = 1
			else
				movement_penalty = 5
			end

			if(CLIENT)then
				speed = speed / movement_penalty
			end

			inertia_to = calc_forward_side_moves_to_vector2d(fm, sm, ply_angles) * speed
		end
	end
	--=//

	--=\\
	if(water_level > 0)then
		ply.CurrentFrictionMul = math.Approach(ply.CurrentFrictionMul, 0.2, delta_time * ply.FrictionLoseMul * water_level)
	else
		ply.CurrentFrictionMul = math.Approach(ply.CurrentFrictionMul, 1, delta_time * ply.FrictionGainMul)
	end
	--=//

	-- local new_inertia = LerpVector(0.5^(delta_time * ply.InertiaBlend), ply.MovementInertia, inertia_to)
	-- local new_inertia = LerpVector(1 - 0.5^(delta_time * ply.InertiaBlend), ply.MovementInertia, inertia_to)
	local new_inertia = approach_vector(ply.MovementInertia, inertia_to, delta_time * ply.InertiaBlend)
	ply.MovementInertia = new_inertia
	local inertia_len = math.sqrt(ply.MovementInertia.x * ply.MovementInertia.x + ply.MovementInertia.y * ply.MovementInertia.y)
	local forward_move, side_move = calc_forward_side_moves(ply.MovementInertia, ply_angles)

	if(CLIENT)then
		ply.MovementInertiaAddView = ply.MovementInertiaAddView or Angle(0,0,0)
		ply.MovementInertiaAddView.r = ply.MovementInertiaAddView.r + side_move * delta_time * inertia_len * 0.03
		ply.MovementInertiaAddView.p = ply.MovementInertiaAddView.p + math.abs(side_move) * delta_time * inertia_len * 0.01
	end
	--//

	local move = ply:GetRunSpeed()
	k = 1 * weightmul
	k = k * math.Clamp((org.stamina or 180) / 90, 0.4, 1)
	k = k * math.Clamp(15 / ((org.immobilization or 0) + 1), 0.5, 1)
	k = k * math.Clamp(20 / ((org.pain or 0) + 1), 0.5, 1)
	k = k * math.Clamp((org.blood or 0) / 5000, 0, 1)
	k = k * math.Clamp(5 / ((org.shock or 0) + 1), 0.25, 1)
	k = k * (math.min((org.adrenaline or 0) / 3, 0.3) + 1)
	k = k * 2 / (((org.lleg or 0) > 0.75 and (org.lleg - 0.75) * 8 or 0) + ((org.rleg or 0) > 0.75 and (org.rleg - 0.75) * 8 or 0) + 2)
	k = k * math.Clamp(org.pulse / 70, 0.2, 1)
	k = k * ((IsValid(ply:GetNetVar("carryent")) or IsValid(ply:GetNetVar("carryent2"))) and math.Clamp(15 / math.max(ply:GetNetVar("carrymass", 0) + ply:GetNetVar("carrymass2", 0), 1), 0.5, 1) or 1)
	k = k * (ishgweapon(wep) and not wep:IsPistolHoldType() and not wep:ReadyStance() and 0.75 or 1)
	local ent = IsValid(ply:GetNetVar("carryent")) and ply:GetNetVar("carryent") or IsValid(ply:GetNetVar("carryent2")) and ply:GetNetVar("carryent2")

	if IsValid(ent) then
		local bon = ply:GetNetVar("carrybone",0) ~= 0 and ply:GetNetVar("carrybone",0) or ply:GetNetVar("carrybone2",0)
		local bone = ent:TranslatePhysBoneToBone(bon)
		local mat = ent:GetBoneMatrix(bone)
		local pos = mat and mat:GetTranslation() or ent:GetPos()
		local lpos = ply:GetNetVar("carrypos",nil) and ent:LocalToWorld(ply:GetNetVar("carrypos",nil)) or ply:GetNetVar("carrypos2",nil) and ent:LocalToWorld(ply:GetNetVar("carrypos2",nil))
		if not ent:IsRagdoll() then
			pos = lpos
		end
		local eyetr = hg.eyeTrace(ply)
		local dist = pos:DistToSqr(eyetr.StartPos)
		local reachdist = weapons.GetStored("weapon_hands_sh").ReachDistance + 30
		if dist > reachdist*reachdist then
			local moving_to = calc_forward_side_moves_to_vector2d(fm, sm, ply_angles)
			local dot = moving_to:Dot((pos - eyetr.StartPos):GetNormalized())
			k = k * dot
		end
	end
	move = move * k
	ply.move = move
	
	if SERVER and not IsValid(ply.FakeRagdoll) then
		ply.eyeAnglesOld = ply.eyeAnglesOld or ply:EyeAngles()
		local cosine = ply:EyeAngles():Forward():Dot(ply.eyeAnglesOld:Forward())
		ply.eyeAnglesOld = ply:EyeAngles()

		if (velLen > 200 and (math.random(150) == 1 or cosine <= 0.99)) then
			local tr = {}
			tr.start = ply:GetPos()
			tr.endpos = tr.start - vector_up * 1
			tr.filter = ply
			tr = util.TraceLine(tr)

			if string.find(string.lower(tr.HitTexture),"ice") then
				local b1 = ply:TranslateBoneToPhysBone(ply:LookupBone("ValveBiped.Bip01_L_Calf"))
				local phys1 = hg.IdealMassPlayer["ValveBiped.Bip01_L_Calf"]
				local b2 = ply:TranslateBoneToPhysBone(ply:LookupBone("ValveBiped.Bip01_R_Calf"))
				local phys2 = hg.IdealMassPlayer["ValveBiped.Bip01_R_Calf"]
				local torso = ply:TranslateBoneToPhysBone(ply:LookupBone("ValveBiped.Bip01_Spine2"))
				local phystorso = hg.IdealMassPlayer["ValveBiped.Bip01_Spine2"]
				local force = vel:GetNormalized() * 150
				ply.AddForceRag = ply.AddForceRag or {}
				ply.AddForceRag[b1] = ply.AddForceRag[b1] or {}
				ply.AddForceRag[b2] = ply.AddForceRag[b2] or {}
				ply.AddForceRag[torso] = ply.AddForceRag[torso] or {}
				ply.AddForceRag[b1][2] = (ply.AddForceRag[b1][2] or vector_origin) + (force * 5 - vector_up * 2) * phys1
				ply.AddForceRag[b1][1] = CurTime() + 0.5
				ply.AddForceRag[b2][2] = (ply.AddForceRag[b2][2] or vector_origin) + (force * 5 - vector_up * 2) * phys2
				ply.AddForceRag[b2][1] = CurTime() + 0.5
				ply.AddForceRag[torso][2] = (ply.AddForceRag[b1][2] or vector_origin) - force * 5 * phystorso
				ply.AddForceRag[torso][1] = CurTime() + 0.5

				timer.Simple(0,function()
					hg.StunPlayer(ply)
				end)
			end
		end
	end

	--\\
	-- if(ply:KeyPressed(IN_JUMP))then
		-- mv:SetFinalJumpVelocity(vector_up * 200)
	-- end

	-- if mv:GetFinalJumpVelocity():LengthSqr() > 0 then ply.jumped = true end
	--//

	-- if(cmd:KeyDown(IN_ATTACK2))then
		-- print(speed, ply.CurrentSpeed, CurTime())
	-- end

	ply:SetMaxSpeed(move)
	ply:SetJumpPower(DEFAULT_JUMP_POWER * math.min(k,1.1) * (not ply:GetNWBool("TauntStopMoving", false) and 1 or 0) * (ply.organism.superfighter and 1.5 or 1) * (ply.JumpPowerMul or 1))
	
	if(CLIENT)then
		--print(math.Round(math.abs(forward_move) + math.abs(side_move),2),math.Round(inertia_len,2),math.Round((math.abs(forward_move) + math.abs(side_move)) * inertia_len,2))
		cmd:SetForwardMove(forward_move * inertia_len)
		cmd:SetSideMove(side_move * inertia_len)
	end
end)

hook.Add("PlayerStepSoundTime", "hguhuy", function(ply, type, walking)
	return (50 / math.Clamp(ply.LastVelocityLen or 0, 115, 175)) * 1000
end)

hook.Add("PlayerSpawn", "RemoveSandboxJumpBoost", function(ply)
	if (engine.ActiveGamemode() != "sandbox") then return end
	
	local PLAYER = baseclass.Get("player_sandbox")

	PLAYER.FinishMove           = nil       -- Disable boost
	PLAYER.StartMove           	= nil       -- Disable boost
	PLAYER.SlowWalkSpeed		= 100		-- How fast to move when slow-walking (+WALK)
	PLAYER.WalkSpeed			= 190		-- How fast to move when not running
	PLAYER.RunSpeed				= 320		-- How fast to move when running
	PLAYER.CrouchedWalkSpeed	= 0.4		-- Multiply move speed by this when crouching
	PLAYER.DuckSpeed			= 0.3		-- How fast to go from not ducking, to ducking
	PLAYER.UnDuckSpeed			= 0.3		-- How fast to go from ducking, to not ducking
	PLAYER.JumpPower			= 200		-- How powerful our jump should be
end)

function hg.PrecacheSoundsSWEP(self)
	if self.HolsterSnd and self.HolsterSnd[1] then util.PrecacheSound(self.HolsterSnd[1]) end
	if self.DeploySnd and self.DeploySnd[1] then util.PrecacheSound(self.DeploySnd[1]) end
	if self.Primary.Sound and self.Primary.Sound[1] then util.PrecacheSound(self.Primary.Sound[1]) end
	if self.DistSound then util.PrecacheSound(self.DistSound) end
	if self.SupressedSound and self.SupressedSound[1] then util.PrecacheSound(self.SupressedSound[1]) end
end

if CLIENT then
	hook.Add("AdjustMouseSensitivity", "AdjustRunSencivity", function(defaultSensitivity)
		if not LocalPlayer():Alive() then return end--kakoy sencivity NOOB
		local organism = LocalPlayer().organism or {}

		local isrunning = LocalPlayer():KeyDown(IN_SPEED) and LocalPlayer():GetVelocity():Length() >= 10 and not LocalPlayer():Crouching() and not IsValid(LocalPlayer():GetNWEntity("FakeRagdoll"))
		local eyeAngles = LocalPlayer():EyeAngles()
		local self = LocalPlayer():GetActiveWeapon()
		self = IsValid(self) and self
		local wepMul = self and self.IsZoom and self:IsZoom() and ((self:HasAttachment("sight","optic") or self.scopedef) and not self.viewmode1 and math.min(self.ZoomFOV / 60, 0.5) or 0.4) or 1
		eyeAngles[1] = 0
		local forwardMoving = math.max(LocalPlayer():GetVelocity():GetNormalized():Dot(eyeAngles:Forward()), 0.6)
		if isrunning and LocalPlayer():GetMoveType() ~= MOVETYPE_NOCLIP then
			return 0.3 * math.max(1 / ((organism.immobilization or 0) / 30 + 1),0.4) * wepMul
		end
		return math.max(1 / ((organism.immobilization or 0) / 30 + 1),0.4) * wepMul
	end)
end

local cheats = GetConVar( "sv_cheats" )
local timeScale = GetConVar( "host_timescale" )

local function changePitch(p)

	if ( game.GetTimeScale() ~= 1 ) then
		p = p * game.GetTimeScale()
	end
	
	if ( timeScale:GetFloat() ~= 1 and cheats:GetBool() ) then
		p = p * timeScale:GetFloat()
	end

	if ( CLIENT and engine.GetDemoPlaybackTimeScale() ~= 1 ) then
		p = math.Clamp( p * engine.GetDemoPlaybackTimeScale(), 0, 255 )
	end

	return p
end

hook.Add( "EntityEmitSound", "TimeWarpSounds", function( t )

	local p = changePitch(t.Pitch)

	if ( p ~= t.Pitch ) then
		t.Pitch = math.Clamp( p, 0, 255 )
		return true
	end
end )

if CLIENT then
	local vectorZero = Vector(0,0,0)
	oldEmitSound = oldEmitSound or EmitSound
	lply = LocalPlayer()
	local entMeta = FindMetaTable("Entity")
	function EmitSound( soundName, position, entity, channel, volume, soundLevel, soundFlags, pitch, dsp, filter )
		soundName = soundName or ""
		position = position or vectorZero
		entity = entity or 0
		volume = volume or 1
		soundLevel = soundLevel or 75
		soundFlags = soundFlags or 0
		pitch = pitch or 100
		pitch = changePitch(pitch)
		dsp = dsp or 0
		filter = filter or nil
		lply = lply or LocalPlayer()
		local Ears = lply:GetNetVar("Armor") and lply:GetNetVar("Armor")["ears"]
		local sndparms = hg.armor.ears[Ears]
		local sndBool = Ears and sndparms
		oldEmitSound(soundName, position, entity, channel, sndBool and volume > sndparms.NormalizeSnd[1] and sndparms.NormalizeSnd[2] or volume + (sndBool and sndparms.VolumeAdd or 0) , soundLevel + (sndBool and sndparms.SoundlevelAdd or 0), soundFlags, pitch, dsp, filter)
	end

	oldEntEmitSound = oldEntEmitSound or entMeta.EmitSound
	function entMeta.EmitSound(self,soundName,soundLevel,pitch,volume,channel,soundFlags,dsp,filter)
		soundName = soundName or ""
		position = position or vectorZero
		entity = entity or 0
		volume = volume or 1
		soundLevel = soundLevel or 75
		soundFlags = soundFlags or 0
		pitch = pitch or 100
		--pitch = changePitch(pitch) or 1
		dsp = dsp or 0
		filter = filter or nil
		lply = lply or LocalPlayer()
		local Ears = lply:GetNetVar("Armor",{})["ears"]
		local sndparms = hg.armor.ears[Ears] or false
		oldEntEmitSound(self, soundName, soundLevel + (sndparms and sndparms.SoundlevelAdd or 0), pitch, sndparms and volume > sndparms.NormalizeSnd[1] and sndparms.NormalizeSnd[2] or volume + (sndBool and sndparms.VolumeAdd or 0), channel, soundFlags, dsp, filter)
	end
end

function IsAiming(ply)
	local is = ply:KeyDown(IN_ATTACK2)

	return is
end

hook.Add("Move","TryingToFixShit",function(ply,mv)--помогло
	local value = mv:GetMaxSpeed()
	if ply:KeyDown(IN_FORWARD) and not ply:KeyDown(IN_LEFT) and not ply:KeyDown(IN_RIGHT) and not ply:KeyDown(IN_BACK) then
		ply.move = mv:GetForwardSpeed()
	end

	ply:SetSlowWalkSpeed(30)
	ply:SetCrouchedWalkSpeed(60)
	ply:SetRunSpeed(Lerp((ply:IsSprinting() and mv:GetForwardSpeed() > 1) and 0.05 or 1,ply:GetRunSpeed(),(ply:IsSprinting() and mv:GetForwardSpeed() > 1) and 300 or ply:GetWalkSpeed()))
	ply:SetJumpPower(170)

	if not ply:Crouching() then
		mv:SetMaxSpeed(value)
		mv:SetMaxClientSpeed(value)
	end
end)

hook.Add("PlayerFootstep", "CustomFootstep2sad", function(ply, pos, foot, sound, volume, rf)
	if CLIENT and ply == LocalPlayer() and ply:IsSprinting() then
		local vel = ply:GetVelocity()
		local funnyvel = vel:Dot(ply:EyeAngles():Forward()) / 1000

		local vellen = (vel:Length() / 250) ^ 1 * (ply.move <= 200 and (200 - ply.move) / 10 or 1)
		ViewPunch(AngleRand(Angle(vellen,0,0),Angle(vellen,0,0))+ Angle(0,0,(foot == 0 and -funnyvel or funnyvel)))
		if IsValid(ply:GetActiveWeapon()) and ishgweapon(ply:GetActiveWeapon()) then
			ViewPunch2(Angle(vel:Dot(ply:EyeAngles():Forward()) / 200,0,0))--)-vel:Dot(ply:EyeAngles():Right()) / 50,0))
		end
	end
	if CLIENT and ply == LocalPlayer() and not ply:IsSprinting() and ishgweapon(ply:GetActiveWeapon()) then
		local vel = ply:GetVelocity()
		local funnyvel = vel:Dot(ply:EyeAngles():Forward()) / 900
		ViewPunch2(Angle(funnyvel + math.abs(vel:Dot(ply:EyeAngles():Right()) / 520),vel:Dot(ply:EyeAngles():Right()) / 520 + (foot == 0 and funnyvel or -funnyvel),0))
	end
	if SERVER then
		if ply.organism then
			local org = ply.organism
			org.painadd = org.painadd + ((org.lleg or 0) > 0.75 and (org.lleg - 0.75) or 0) + ((org.rleg or 0) > 0.75 and (org.rleg - 0.75) or 0)
		end
	end

	if CLIENT then
		local vel = ply:GetVelocity()
		local sndlvl = 75
		--PrintTable(ply:GetNetVar("Armor"))
		if ply:GetNetVar("Armor",{})["torso"] then
			EmitSound("arc9_eft_shared/weapon_generic_rifle_spin"..math.random(9)..".ogg",pos,ply:EntIndex(),CHAN_AUTO,math.min(vel:Length()/100,0.89),sndlvl+5)
		end
		--print(ply)
		if not (ply:IsWalking() or ply:Crouching()) then
			EmitSound(sound,pos,ply:EntIndex(),CHAN_AUTO,(vel:Length()/600),sndlvl-5)
		end
	end

	return true
end)

hook.Add("StartCommand", "asd2345", function(ply, cmd)
	if not ply:OnGround() then --cmd:AddKey(IN_SPEED)
	end
end)

hook.Add("PlayerDeathSound", "removesound", function() return true end)

hook.Add("PlayerSwitchFlashlight", "removeflashlights", function(ply, enabled)
	local wep = ply:GetActiveWeapon()

	local flashlightwep

	if IsValid(wep) then
		local laser = wep.attachments and wep.attachments.underbarrel
		local attachmentData
		if (laser and not table.IsEmpty(laser)) or wep.laser then
			if laser and not table.IsEmpty(laser) then
				attachmentData = hg.attachments.underbarrel[laser[1]]
			else
				attachmentData = wep.laserData
			end
		end

		if attachmentData then flashlightwep = attachmentData.supportFlashlight end
	end

	if not flashlightwep then --custom flashlight
		local inv = ply:GetNetVar("Inventory",{})
		if inv and inv["Weapons"] and inv["Weapons"]["hg_flashlight"] and enabled then
			hg.GetCurrentCharacter(ply):EmitSound("items/flashlight1.wav",65)
			ply:SetNetVar("flashlight",not ply:GetNetVar("flashlight"))
			--return true
			if IsValid(ply.flashlight) then ply.flashlight:Remove() end
		else
			ply:SetNetVar("flashlight",false)
		end
		return false
	end
end)

if CLIENT then
	local flashlightPos,flashlightAng = Vector(3, -2, -1),Angle(0, 0, 0)
	local vecZero,angZero = Vector(0,0,0),Angle(0,0,0)

	local anghuy = Angle(0,0,0)
	function hg.FlashlightTransform(ply)
		local wep = ply:GetActiveWeapon()
	
		local rh,lh = ply:LookupBone("ValveBiped.Bip01_R_Hand"), ply:LookupBone("ValveBiped.Bip01_L_Hand")
		
		local ent = hg.GetCurrentCharacter(ply)
		local rhmat = ent:GetBoneMatrix(rh)
		local lhmat = ent:GetBoneMatrix(lh)
	
		local pos = lhmat:GetTranslation()
		local ang = lhmat:GetAngles()
	
		pos, ang = LocalToWorld(flashlightPos,flashlightAng,pos,ang)
	
		ply.flmodel = IsValid(ply.flmodel) and ply.flmodel or ClientsideModel("models/runaway911/props/item/flashlight.mdl")
		ply.flmodel:SetNoDraw(true)
		ply.flmodel:SetModelScale(0.75)
	
		if IsValid(ply.flmodel) then	
			ply.flmodel:SetRenderOrigin(pos)
			ply.flmodel:SetRenderAngles(ply:EyeAngles())
		end
	end

	local flpos,flang = Vector(4,-1,0),Angle(0,0,0)

	local offsetVec,offsetAng = Vector(1,0,0),Angle(100,90,0)
	local vecZero, angZero = Vector(0, 0, 0), Angle(0, 0, 0)
	local mat = Material("sprites/rollermine_shock")
	local mat2 = Material("sprites/light_glow02_add_noz")
	local mat3 = Material("effects/flashlight/soft")
	local mat4 = Material("sprites/light_ignorez", "alphatest")
	hook.Add("DrawAppearance","flashlightsrender",function(ent,ply)
		if not ply:IsPlayer() then return end

		local inv = ply:GetNetVar("Inventory",{})
		if not inv["Weapons"] or not inv["Weapons"]["hg_flashlight"] then
			if ply.flashlight then
				ply.flashlight:Remove()
				ply.flashlight = nil
			end
			if ply.flmodel then
				ply.flmodel:Remove()
				ply.flmodel = nil
			end
			return
		end

		local wep = ply:GetActiveWeapon()
		local flashlightwep

		if IsValid(wep) then
			local laser = wep.attachments and wep.attachments.underbarrel
			local attachmentData
			if (laser and not table.IsEmpty(laser)) or wep.laser then
				if laser and not table.IsEmpty(laser) then
					attachmentData = hg.attachments.underbarrel[laser[1]]
				else
					attachmentData = wep.laserData
				end
			end

			if attachmentData then flashlightwep = attachmentData.supportFlashlight end
		end

		if IsValid(ply.flmodel) then
			ply.flmodel:SetNoDraw(!(ply:GetNetVar("flashlight") and (!wep.IsPistolHoldType or wep:IsPistolHoldType())) or wep.reload or flashlightwep)
		end

		if ply:GetNetVar("flashlight") and not flashlightwep and (!wep.IsPistolHoldType or wep:IsPistolHoldType()) and not wep.reload then
			local hand = ent:LookupBone("ValveBiped.Bip01_L_Hand")
			if not hand then return end
			
			local handmat = ent:GetBoneMatrix(hand)
			if not handmat then return end

			local pos,ang = handmat:GetTranslation(),handmat:GetAngles()--ply:EyeAngles()--(ply:GetEyeTrace().HitPos - ply:EyePos()):Angle()
			local pos,ang = LocalToWorld(offsetVec,offsetAng,pos,ang)

			ply.flmodel = IsValid(ply.flmodel) and ply.flmodel or ClientsideModel("models/runaway911/props/item/flashlight.mdl")
			ply.flmodel:SetModelScale(0.75)

			if ent ~= ply then pos = handmat:GetTranslation() end

			local pos,_ = LocalToWorld(flpos,flang,pos,handmat:GetAngles())

			if IsValid(ply.flmodel) and (ply ~= LocalPlayer() or ply ~= GetViewEntity()) then
				local veclh,lang = hg.FlashlightTransform(ply)
			end

			ply.flmodel:DrawModel()

			ply.flashlight = IsValid(ply.flashlight) and ply.flashlight or ProjectedTexture()
			if ply.flashlight and ply.flashlight:IsValid() and (ply.FlashlightUpdateTime or 0) < CurTime() then
				local flash = ply.flashlight
				ply.FlashlightUpdateTime = CurTime() + 0.01
				flash:SetTexture(mat3:GetTexture("$basetexture"))
				flash:SetFarZ(1500)
				flash:SetHorizontalFOV(60)
				flash:SetVerticalFOV(60)
				flash:SetConstantAttenuation(0.1)
				flash:SetLinearAttenuation(50)
				flash:SetPos(ply.flmodel:GetPos() + ply.flmodel:GetAngles():Forward() * (ply:GetVelocity():Length() / 10+15))
				flash:SetAngles(ply.flmodel:GetAngles())
				flash:Update()
			end

			--[[ply.dlight = DynamicLight( ply:EntIndex() )
			if ( ply.dlight ) then
				ply.dlight.pos = ply.flmodel:GetPos()
				ply.dlight.r = 255
				ply.dlight.g = 255
				ply.dlight.b = 255
				ply.dlight.brightness = -3
				ply.dlight.decay = 400
				ply.dlight.size = 100
				ply.dlight.dietime = CurTime() + 0.1
			else
				ply.dlight = DynamicLight( ply:EntIndex() )
			end--]]

			local view = render.GetViewSetup(true)
			local deg = ply.flmodel:GetAngles():Forward():Dot(view.angles:Forward())
			deg = math.ease.InBack(-deg+0.05)*2
			deg = -deg
			local chekvisible = util.TraceLine({
				start = ply.flmodel:GetPos() + ply.flmodel:GetAngles():Forward() * 6,
				endpos = view.origin,
				filter = {ply, ent, ply.flmodel, LocalPlayer()},
				mask = MASK_VISIBLE
			})

			if deg < 0 and not chekvisible.Hit then
				render.SetMaterial(mat2)
				render.DrawSprite(ply.flmodel:GetPos() + ply.flmodel:GetAngles():Forward() * 5 + ply.flmodel:GetAngles():Right() * -0.5, 50 * math.min(deg, 0), 50 * math.min(deg, 0), color_white)
			end
		else
			if ply.flashlight and ply.flashlight:IsValid() then
				ply.flashlight:Remove()
				ply.flashlight = nil
			end
		end
	end)

	hook.Add("Player Death","removeflashlight",function(ply)
		if ply.flashlight and ply.flashlight:IsValid() then
			ply.flashlight:Remove()
		end
	end)
end

function hg.CanUseLeftHand(ply)
    local ent = hg.GetCurrentCharacter(ply)
    local wep = IsValid(ply:GetActiveWeapon()) and ply:GetActiveWeapon()
	--print(wep:IsPistolHoldType())
    return not (((ply:GetTable().ChatGestureWeight or 0) > 0.1 and not wep.reload) or
		ply:GetNWBool("TauntLeftHand", false) or
		IsValid(ply.flashlight) or
		--wep and wep.IsPistolHoldType and not wep:IsPistolHoldType() or
		(ent != ply and math.abs(ent:GetManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_L_Finger11"))[2]) > 5) or
		(ply:InVehicle() and not (wep and wep.reload) and ( hg.isdriveablevehicle(ply:GetVehicle()))))
end

--[[local function fuckyou(ply)
    local ent = hg.GetCurrentCharacter(ply)
    local wep = IsValid(ply:GetActiveWeapon()) and ply:GetActiveWeapon()
	
    return not (((ply:GetTable().ChatGestureWeight or 0) > 0.1 and not wep.reload) or
		ply:GetNWBool("TauntLeftHand", false) or
		IsValid(ply.flashlight) or
		(ent != ply and math.abs(ent:GetManipulateBoneAngles(ent:LookupBone("ValveBiped.Bip01_L_Finger11"))[2]) > 5) or
		(ply:InVehicle() and not (wep and wep.reload) and ( hg.isdriveablevehicle(ply:GetVehicle()))))
end
hg.fuckyou = fuckyou
fuckyou(Entity(1))--]]

function hg.earanim(ply)
	local plyTable = ply:GetTable()

	plyTable.ChatGestureWeight = plyTable.ChatGestureWeight || 0

	if ( ply:IsPlayingTaunt() ) then return end

    local wep = ply:GetActiveWeapon()
    
	if ( ply:IsTyping() ) or ( ply:GetNetVar("flashlight",false) and ( !wep.IsPistolHoldType or wep:IsPistolHoldType()) ) then
		plyTable.ChatGestureWeight = math.Approach( plyTable.ChatGestureWeight, 1, FrameTime() * 3.0 )
	else
		plyTable.ChatGestureWeight = math.Approach( plyTable.ChatGestureWeight, 0, FrameTime() * 3.0 )
	end

	if ( plyTable.ChatGestureWeight > 0 ) then

		ply:AnimRestartGesture( GESTURE_SLOT_VCD, ACT_GMOD_IN_CHAT, true )
		ply:AnimSetGestureWeight( GESTURE_SLOT_VCD, plyTable.ChatGestureWeight )

	end
end

function GAMEMODE:GrabEarAnimation(ply)
	hg.earanim(ply)
end

local surface_hardness = {
	[MAT_METAL] = 0.9,
	[MAT_COMPUTER] = 0.9,
	[MAT_VENT] = 0.9,
	[MAT_GRATE] = 0.9,
	[MAT_FLESH] = 0.5,
	[MAT_ALIENFLESH] = 0.3,
	[MAT_SAND] = 0.1,
	[MAT_DIRT] = 0.9,
	[74] = 0.1,
	[85] = 0.2,
	[MAT_WOOD] = 0.5,
	[MAT_FOLIAGE] = 0.5,
	[MAT_CONCRETE] = 0.9,
	[MAT_TILE] = 0.8,
	[MAT_SLOSH] = 0.05,
	[MAT_PLASTIC] = 0.3,
	[MAT_GLASS] = 0.6,
}

local BulletEffects
if SERVER then
	BulletEffects = function(tr, self, dmg)
		net.Start("bullet_fell")
		net.WriteTable(tr)
		net.WriteEntity(self)
		net.WriteFloat(dmg)
		net.Broadcast()
	end
end
local bulletHit
local function callbackBullet(self, tr, ply, fleshPen, bullet)
	if not bullet.penetrated then return end
	if bullet.penetrated > 5 then return end
	bullet.penetrated = self.penetrated + 1

	local dir, hitNormal, hitPos = tr.Normal, tr.HitNormal, tr.HitPos

	local hardness = surface_hardness[tr.MatType] or 0.5
	local ApproachAngle = -math.deg(math.asin(hitNormal:DotProduct(dir)))
	local MaxRicAngle = 60 * hardness
	-- all the way through
	if ApproachAngle > MaxRicAngle * 1.2 then
		local Pen = (bullet.Penetration or 5) * 1 or bullet.Damage
		local MaxDist, SearchPos, SearchDist, Penetrated = Pen / hardness * 0.15 * 5, hitPos, 5, false
		while not Penetrated and SearchDist < MaxDist do
			SearchPos = hitPos + dir * SearchDist
			local PeneTrace = util.QuickTrace(SearchPos, -dir * SearchDist)
			if not PeneTrace.StartSolid and PeneTrace.Hit then
				Penetrated = true
				bullet.Penetration = bullet.Penetration - Pen * SearchDist / MaxDist / 3
			else
				SearchDist = SearchDist + 5
			end
		end

		if Penetrated then
			self:FireLuaBullets({
				Attacker = self:GetOwner(),
				Damage = 1,
				Force = 0,
				Num = 1,
				Tracer = 0,
				TracerName = "",
				Dir = -dir,
				Spread = Vector(0, 0, 0),
				Src = SearchPos + dir,
				DisableLagComp = true,
				Filter = {},
			})

			self:FireLuaBullets({
				Attacker = self:GetOwner(),
				Damage = bullet.Damage * 0.65,
				Force = bullet.Damage / 3,
				Num = 1,
				Tracer = 0,
				TracerName = "",
				Dir = dir,
				Spread = Vector(0, 0, 0),
				Src = SearchPos + dir,
				Callback = bulletHit,
				DisableLagComp = true,
				Filter = {},
			})
		end
	elseif ApproachAngle < MaxRicAngle * .2 then
		-- ping whiiiizzzz
		sound.Play("snd_jack_hmcd_ricochet_" .. math.random(1, 2) .. ".wav", hitPos, 75, math.random(90, 100))
		local NewVec = dir:Angle()
		NewVec:RotateAroundAxis(hitNormal, 180)
		NewVec = NewVec:Forward()
		self:FireLuaBullets({
			Attacker = self:GetOwner(),
			Damage = (bullet.Damage or 1) * .85,
			Force = bullet.Damage  / 3,
			Num = 1,
			Tracer = 0,
			TracerName = "",
			Dir = -NewVec,
			Spread = Vector(0, 0, 0),
			Src = hitPos + hitNormal,
			Callback = bulletHit,
			DisableLagComp = true,
			Filter = {},
		})
	end
end

--не нахуй
bulletHit = function(ply, tr, dmgInfo, bullet)
	--if tr.HitSky then return end
	if CLIENT then return false end
	local fleshPen = false
	if tr.MatType == MAT_FLESH then
		util.Decal("Impact.Flesh", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal)
		--[[local effectdata = EffectData()
		effectdata:SetOrigin( tr.HitPos )
		util.Effect( "bloodImpact", effectdata )]]--
		fleshPen = true
	end

	local inflictor = dmgInfo:GetAttacker()
	timer.Simple(0,function()
		callbackBullet(inflictor, tr, ply, fleshPen, bullet)
	end)
end

local function PlaySnd(self, snd, server, chan)
	if SERVER and not server then return end
	local owner = self
	if CLIENT then
		local view = render.GetViewSetup(true)
		local time = owner:GetPos():Distance(view.origin) / 17836
		timer.Simple(time, function()
			local owner = IsValid(self:GetOwner().FakeRagdoll) and self:GetOwner().FakeRagdoll or self:GetOwner() or self
			owner = IsValid(owner) and owner or self
			if type(snd) == "table" then
				EmitSound(snd[1], owner:GetPos(), owner:EntIndex(), chan or CHAN_WEAPON, snd[5] or 1, snd[2] or (self.Supressor and 75 or 75), 0, math_random(snd[3] or 100, snd[4] or 100), 0, nil)
			else
				EmitSound(snd, owner:GetPos(), owner:EntIndex(), chan or CHAN_WEAPON, 1, self.Supressor and 75 or 75, 0, 100, 0, nil)
			end
		end)
	else
		local owner = IsValid(self:GetOwner().FakeRagdoll) and self:GetOwner().FakeRagdoll or self:GetOwner() or self
		owner = IsValid(owner) and owner or self
		if type(snd) == "table" then
			EmitSound(snd[1], owner:GetPos(), owner:EntIndex(), chan or CHAN_WEAPON, snd[5] or 1, snd[2] or (self.Supressor and 75 or 75), 0, math_random(snd[3] or 100, snd[4] or 100), 0, nil)
		else
			EmitSound(snd, owner:GetPos(), owner:EntIndex(), chan or CHAN_WEAPON, 1, self.Supressor and 75 or 75, 0, 100, 0, nil)
		end
	end
end

local npcs = {
	--["npc_metropolice"] = {multi = 1,force = 1},
	--["npc_combine_s"] = {multi = 1,force = 1},
	["npc_strider"] = {multi = 5,snd = "npc/strider/strider_minigun.wav",force = 2},
	["npc_combinegunship"] = {multi = 5,snd = "npc/strider/strider_minigun.wav",force = 7},
	["npc_helicopter"] = {multi = 4,force = 2},
	["lunasflightschool_ah6"] = {multi = 20}
}

hook.Add("PlayerUse","nouseinfake",function(ply,ent)
	local class = ent:GetClass()
	local ductcount = hgCheckDuctTapeObjects(ent)
	local nailscount = hgCheckBindObjects(ent)
	if (ductcount and ductcount > 0) or (nailscount and nailscount > 0) then return false end
	if class == "prop_physics" or class == "prop_physics_multiplayer" or class == "func_physbox" then
		local PhysObj = ent:GetPhysicsObject()
		if PhysObj and PhysObj.GetMass and PhysObj:GetMass() > 14 then return false end
	end

	if IsValid(ply.FakeRagdoll) then return false end
end)

hook.Add("Player Activate","SetHull",function(ply)
	ply:SetHull(-Vector(hull,hull,0),Vector(hull,hull,72))
	ply:SetHullDuck(-Vector(hull,hull,0),Vector(hull,hull,36))
	ply:SetViewOffset(Vector(0,0,64))
	ply:SetViewOffsetDucked(Vector(0,0,38))
end)

hook.Add("Player Spawn","SetHull",function(ply)
	ply:SetNWEntity("FakeRagdoll",NULL)
	ply:SetObserverMode(OBS_MODE_NONE)
end)

hook.Add("WeaponEquip","pickupHuy",function(wep,ply)
	--if not wep.init then return end
	timer.Simple(0,function()
		if wep.DontEquipInstantly then wep.DontEquipInstantly = nil return end
		if not ply.noSound and IsValid(wep) then
			local oldwep = ply:GetActiveWeapon()
			timer.Simple(0,function()
				hook.Run("PlayerSwitchWeapon",ply,oldwep,wep)
				ply:SelectWeapon(wep:GetClass())
				ply:SetActiveWeapon(wep)

				if wep.Deploy then
					wep:Deploy()
				end
			end)
		end
	end)
end)

hook.Add("AllowPlayerPickup","pickupWithWeapons",function(ply,ent)
    if ent:IsPlayerHolding() then return false end
end)

hook.Add("PlayerSwitchWeapon","switchghuy",function(ply,old,new)
	if SERVER then
		if old.dropAfterHolster then
			if not old.IsSpawned then return end
			--ply:DropWeapon(old)
		end
		--old:Holster()
	end
end)

if CLIENT then
	--local checkcd = 0
	LocalPlayerSeen = true
	hg.seenents = hg.seenents or {}
	local hg_fov = GetConVar("hg_fov")
	hook.Add("Think", "CanBeSeenOrNot", function()
		--if checkcd > CurTime() then return end
		--checkcd = CurTime() + 1
		local entities = ents.FindByClass("prop_ragdoll")
		table.Add(entities, player.GetAll())

		hg.seenents = {}

		if g_VR and g_VR.active then return end

		local view = render.GetViewSetup()

		for i=1, #entities do
			v = entities[i]

			local nochange = (v == LocalPlayer().FakeRagdoll) or (LocalPlayer():Alive() and v == LocalPlayer()) or (not LocalPlayer():Alive() and v == LocalPlayer():GetNWEntity("spect"))
			if nochange then
				v.NotSeen = false
				table.insert(hg.seenents,v)

				--continue
			end

			local min,max = v:GetModelBounds()
			local len = (max - min):Length()

			local vPos = v:GetPos()
			local _, point, _ = util.DistanceToLine(view.origin, view.origin + view.angles:Forward() * 9999, vPos)
			local vSize = (point - vPos):GetNormalized() * len

			local diff = (vPos + vSize - view.origin):GetNormalized()
			if !v.shouldTransmit or (view.angles:Forward():Dot(diff) <= math.cos(math.rad(hg_fov:GetInt()))) then
				if not nochange then v.NotSeen = true end
				if v == LocalPlayer() then LocalPlayerSeen = false end
			else
				if not nochange then v.NotSeen = false end
				if v == LocalPlayer() then LocalPlayerSeen = true end
				table.insert(hg.seenents,v)
			end
		end
	end)
end

function GAMEMODE:PlayerLoadout(ply)
		ply:Give("weapon_hands_sh")
		ply.move = 0
		ply.Stamina = 100
		ply.Otrub = false
		ply.Fake = false
		ply.Ragdoll = NULL
		ply.HasFlashLight = false 
		ply.IsBleeding = false
		ply.stamina = 100
	
		ply.organism = {
		["blood"] = 6000,
		["pain"] = 0,
		["pulse"] = 1,
		["meleespeed"] = 0.7,
		["painadd"] = 0,
		["painlosing"] = 1,
		["otrub"] = false,
		["carotartery"] = 1,
		["rartery"] = 1,
		["lartery"] = 1,
		["recoilmul"] = 1,
		["stamina"] = 100,
		["larm"] = 1,
		["rarm"] = 1,
		["brokenribs"] = 0,
		["hunger"] = 0,
		["staminamul"] = 1,
		['brain'] = 5,
		['lungs'] = 40,
		['liver'] = 10,
		['stomach'] = 30,
		['intestines'] = 30,
		['heart'] = 20,
		['spine'] = 5,
		['kidney'] = 2,
		['spleen'] = 4,
		['canmove'] = true
		}
end

if CLIENT then
	hook.Add( "HUDShouldDraw", "RemoveThatShit", function( name ) 
		if ( name == "CHudDamageIndicator" ) then 
		   return false 
		end
	end )
end

function GAMEMODE:PlayerInitialSpawn(ply)
	ply:Give("weapon_hands_sh")
	ply.move = 0
	ply.Stamina = 100
	ply.Otrub = false
	ply.Fake = false
	ply.Ragdoll = NULL
	ply.HasFlashLight = false 
	ply.IsBleeding = false
	ply.stamina = 100

	ply.organism = {
	["blood"] = 6000,
	["pain"] = 0,
	["pulse"] = 1,
	["meleespeed"] = 0.7,
	["painadd"] = 0,
	["painlosing"] = 1,
	["otrub"] = false,
	["carotartery"] = 1,
	["rartery"] = 1,
	["lartery"] = 1,
	["recoilmul"] = 1,
	["stamina"] = 100,
	["larm"] = 1,
	["rarm"] = 1,
	["brokenribs"] = 0,
	["hunger"] = 0,
	["staminamul"] = 1,
	['brain'] = 5,
	['lungs'] = 40,
	['liver'] = 10,
	['stomach'] = 30,
	['intestines'] = 30,
	['heart'] = 20,
	['spine'] = 5,
	['kidney'] = 2,
	['spleen'] = 4,
	['canmove'] = true
	}
end

hook.Add("PlayerSpawn","NoTragetDisable",function(ply)
	ply:SetNoTarget(false)
end)

local hullVec = Vector(5,5,5)
hook.Add("FindUseEntity","findhguse",function(ply,heldent)
	if IsValid(heldent) and not heldent:IsScripted() then return heldent end
	local tr = {}
	local eyetr = hg.eyeTrace(ply,100)
	tr.start = eyetr.StartPos
	tr.endpos = eyetr.HitPos
	tr.filter = ply
	tr.mins = -hullVec
	tr.maxs = hullVec
	tr.mask = MASK_SOLID + CONTENTS_DEBRIS + CONTENTS_PLAYERCLIP
	tr.ignoreworld = true

	tr = util_TraceHull(tr)
	local ent = tr.Entity

	if not IsValid(ent) then
		--tr = util.TraceHull(tr)
		ent = heldent--tr.Entity
		return false
	end

	return ent
end)

duplicator.Allow( "weapon_base" )
duplicator.Allow( "homigrad_base" )

if CLIENT then

	local meta = FindMetaTable( "Panel" )

	function meta:SlideDown( length, delay )

		local height = self:GetTall()
		self:SetVisible( true )
		self:SetTall( 0 )

		local anim = self:SizeTo( -1, height, length, delay or 0, 0.2 )

	end

	gameevent.Listen( "OnRequestFullUpdate" )
	hook.Add("OnRequestFullUpdate","SetHull",function()
		local ply = LocalPlayer()
		ply:SetHull(-Vector(hull,hull,0),Vector(hull,hull,72))
		ply:SetHullDuck(-Vector(hull,hull,0),Vector(hull,hull,36))
		ply:SetViewOffset(Vector(0,0,64))
		ply:SetViewOffsetDucked(Vector(0,0,38))
	end)

	local function UpdateVoiceDSP(listener, talker)
		if not IsValid(listener) or not IsValid(talker) or listener == talker then return end

		if not talker:Alive() then
			talker:SetVoiceVolumeScale(1)
			return
		end
		local entr = hg.GetCurrentCharacter(talker)

		local distance = listener:GetPos():Distance(talker:GetPos())

		if distance > 900000 then return end

		local trace = util.TraceLine({
			start = listener:EyePos(),
			endpos = entr:EyePos(),
			filter = function(ent)
				return ent != listener and ent != talker and (not ent:IsPlayer() or not ent:IsNPC()) and ent:GetClass() != "prop_physics"
			end
		})

		local volume = 1
		local mute = 0.5

		if distance < 200 then
			mute = math.min(0.5 * 2, 1)
		end
		if talker:WaterLevel() == 3 then
			mute = math.max(0.5 / 2, 0)
		end
		if trace.Hit or talker:WaterLevel() == 3 then
			volume = (((distance / 900000) * -1) + 1) * mute
		else
			volume = (((distance / 900000) * -1) + 1)
		end

		talker:SetVoiceVolumeScale(volume)
	end

	hook.Add("Player Think","MouthThink",function(ply)
		local ent = hg.GetCurrentCharacter(ply)
		--UpdateVoiceDSP(LocalPlayer(), ply)
		if LocalPlayer():GetPos():Distance(ent:GetPos()) > 2000 then return end
		local flexes = {
			ent:GetFlexIDByName( "jaw_drop" ),
			ent:GetFlexIDByName( "left_part" ),
			ent:GetFlexIDByName( "right_part" ),
			ent:GetFlexIDByName( "left_mouth_drop" ),
			ent:GetFlexIDByName( "right_mouth_drop" ),
			ent:GetFlexIDByName( "lower_lip" )
		}

		local weight = (ply:IsSpeaking() and math.Clamp( ply:VoiceVolume() * 3, 0, 2 )) or 0

		for k, v in pairs( flexes ) do
			ent:SetFlexWeight( v, weight )
		end

		local org = ent.organism
		if not org then return end

		if ply:IsPlayer() and ply:Alive() and not org.otrub then
			ent.Blink = ent.Blink or 0
			ent.Blink = ent.Blink + 1
			ent.LastBlinking = ent.Blinking or 0
			if ent.Blink > 150 then
				ent.Blinking = Lerp(FrameTime() * 65,ent.Blinking or 0,1)
				if ent.Blink > 151 then
					ent.Blink = 0
				end
			else
				ent.Blinking = Lerp(FrameTime() * 65,ent.Blinking or 0,0)
			end
		elseif (ent.Blinking or 0) < 0.95 then
			ent.Blinking = Lerp(FrameTime() * 5,ent.Blinking or 0,1)
		end

		if ent:IsRagdoll() and ent:GetFlexIDByName("blink") then
			ent:SetFlexWeight(ent:GetFlexIDByName("blink"),ent.Blinking or 0)
		end
	end)

	timer.Simple(0,function ()
		function GAMEMODE:MouthMoveAnimation(ply)
			local ent = hg.GetCurrentCharacter(ply)
			UpdateVoiceDSP(LocalPlayer(), ply)
			if LocalPlayer():GetPos():Distance(ent:GetPos()) > 2000 then return end
			local flexes = {
				ent:GetFlexIDByName( "jaw_drop" ),
				ent:GetFlexIDByName( "left_part" ),
				ent:GetFlexIDByName( "right_part" ),
				ent:GetFlexIDByName( "left_mouth_drop" ),
				ent:GetFlexIDByName( "right_mouth_drop" ),
				ent:GetFlexIDByName( "lower_lip" )
			}

			local weight = (ply:IsSpeaking() and math.Clamp( ply:VoiceVolume() * 3, 0, 2 )) or 0

			for k, v in pairs( flexes ) do
				ent:SetFlexWeight( v, weight )
			end

			if not ply.organism then return end

			if ply:Alive() and not ply.organism.otrub then
				ent.Blink = ent.Blink or 0
				ent.Blink = ent.Blink + 0.1
				ent.LastBlinking = ent.Blinking or 0
				if ent.Blink > 150 then
					ent.Blinking = Lerp(FrameTime() * 65,ent.Blinking or 0,1)
					if ent.Blink > 151 then
						ent.Blink = 0
					end
				else
					ent.Blinking = Lerp(FrameTime() * 65,ent.Blinking or 0,0)
				end
			elseif ply.organism.otrub and (ent.Blinking or 0) < 0.95 then
				ent.Blinking = Lerp(FrameTime() * 5,ent.Blinking or 0,1)
			end

			if ent:IsRagdoll() and ent:GetFlexIDByName("blink") then
				ent:SetFlexWeight(ent:GetFlexIDByName("blink"),ent.Blinking or 0)
			end
		end
	end)
end

hook.Add( "CalcMainActivity", "RunningAnim", function( Player, Velocity )
	if (not Player:InVehicle()) and Player:IsOnGround() and Velocity:Length() > 250 and IsValid(Player:GetActiveWeapon()) and Player:GetActiveWeapon():GetClass() == "weapon_hands_sh" then
		return ACT_HL2MP_RUN_FAST, -1
	end
end)

local sdist = CreateConVar("ssspray_range", 128, FCVAR_ARCHIVE+FCVAR_REPLICATED, "Spray distance.", 0, 1024)
local delay = GetConVar("decalfrequency")

if CLIENT then
	local decalt = {}
	file.CreateDir("sssprays")
	local function CreateSSSpray(len, ply)
		ply = net.ReadEntity()
		local norm = net.ReadNormal()
		local ent = net.ReadEntity()
		if !IsValid(ply) then return end
		local uid = ply:UserID()
		local pos = ply:EyePos()
		local ang = norm:Angle()
		local dir = ang:Right()
		if !decalt[uid] then
			local temp = ply:GetPlayerInfo().customfiles[1]
			local cfile = "user_custom/" .. string.Left(temp, 2) .. "/" .. temp .. ".dat"
			if game.SinglePlayer() then
				temp = string.Replace(GetConVar("cl_logofile"):GetString(), "materials/", "")
				cfile = string.Replace(temp, ".vtf", "")
				temp = cfile
			else
				if !file.Exists("sssprays/"..temp..".vtf", "DATA") then
				local tex = file.Read(cfile, "DOWNLOAD")
				file.Write("sssprays/"..temp..".vtf", tex)
				end
				cfile = "../../data/sssprays/"..temp
			end
			local spraymdl = CreateMaterial("ssspray/"..temp.."mdl", "VertexLitGeneric", {
				["$basetexture"] = cfile,
				["$decal"] = 1,
				["$decalscale"] = 1,
				["$vertexalpha"] = 1,
				["$decalsecondpass"] = 1,
			})
			local spray = CreateMaterial("ssspray/"..temp, "LightmappedGeneric", {
				["$basetexture"] = cfile,
				["$decal"] = 1,
				["$decalscale"] = 1,
				["$modelmaterial"] = "!ssspray/"..temp.."mdl",
				["$vertexalpha"] = 1,
				["$decalsecondpass"] = 1,
			})
			spraymdl:SetFloat("$decalscale", 32 / spraymdl:Width())
			spray:SetFloat("$decalscale", 32 / spray:Width())
			decalt[uid] = spray
		end
		local qt = util.QuickTrace(pos, ang:Forward() * sdist:GetInt(), ply)
		if !qt.Hit then return end
		if qt.HitTexture ==  "**studio**" then dir = qt.HitNormal-qt.Normal end
		util.DecalEx(decalt[uid], qt.Entity, qt.HitPos+qt.HitNormal, dir, color_white, 2, 2)
	end
	net.Receive("sssprays", CreateSSSpray)
	hook.Add("PopulateToolMenu", "SSSprays", function()
		spawnmenu.AddToolMenuOption("Options", "Chen's Addons", "SSSprays", "SSSprays", "", "", function(pnl)
			pnl:SetName("Super Spammable Sprays")
			pnl:NumSlider("Max spray distance", "ssspray_range", 32, 1024)
			pnl:NumberWang("Spray delay", "decalfrequency", 0, 600)
		end)
	end)
end

--if SERVER then return end--debil
if CLIENT then
	local function Message(Msg)
		print("[Auto Reconnect] "..Msg)
	end
	--Message("Loaded.")

	RunConsoleCommand("cl_timeout","300")

	surface.CreateFont( "ARFontTitle",{
		font = "Trebuchet",
		size = ScreenScale(9)
	})

	surface.CreateFont( "ARFontBody",{
		font = "Trebuchet",
		size = ScreenScale(10)
	})

	surface.CreateFont( "ARFontButton",{
		font = "Trebuchet",
		size = ScreenScale(11)
	})


	local blurMat = Material("pp/blurscreen")
	local Dynamic = 0

	local function BlurBackground(panel)
		if not (IsValid(panel) and panel:IsVisible()) then return end
		local layers, density, alpha = 1, 1, 155
		local x, y = panel:LocalToScreen(0, 0)
		surface.SetDrawColor(255, 255, 255, alpha)
		surface.SetMaterial(blurMat)
		local FrameRate, Num, Dark = 1 / FrameTime(), 5, 190
		for i = 1, Num do
			blurMat:SetFloat("$blur", (i / layers) * density * Dynamic)
			blurMat:Recompute()
			render.UpdateScreenEffectTexture()
			surface.DrawTexturedRect(-x, -y, ScrW(), ScrH())
		end

		surface.SetDrawColor(0, 0, 0, Dark * Dynamic)
		surface.DrawRect(0, 0, panel:GetWide(), panel:GetTall())
		Dynamic = math.Clamp(Dynamic + (1 / FrameRate) * 7, 0, 1)
	end

	local API = "http://api.steampowered.com/ISteamApps/GetServersAtAddress/v0001?addr="

	local Menu
	local WaitMsg = ""
	local Cancelled = false
	local IP = game.GetIPAddress()
	local MenuOpen = false
	local IsTimingOut = false
	local LastPing = RealTime()
	local CountDown = 30
	local LastDec = 0
	local CountDownActive = false

	//Check if the server is online, then start the countdown.
	local function PingServer()
		if Cancelled or not IsTimingOut then return end
		Message("Pinging Server")
		http.Fetch(API .. IP, function(JSON)
			//Message(JSON)
			Data = util.JSONToTable(JSON)
			local ServerCount = #Data["response"]["servers"]
			if ServerCount >= 1 then
				CountDownActive = true
				CountDown = 30
				LastDec = RealTime()
			else
				PingServer()
			end
		end, function() PingServer() end)
	end

	//Safely close the menu without error.
	local function CloseMenu()
		if MenuOpen then
			MenuOpen = false
			CountDownActive = false
			Menu:Close()
		end
	end

	//Open the menu
	local function OpenMenu()
		if MenuOpen or Cancelled then return end//Dont want to open more than 1 or when cancelled

		Message("Opening menu")
		MenuOpen = true
		WaitMsg = "Maybe not?"
		PingServer()

		Menu = vgui.Create("DFrame")
		Menu:SetSize(ScrW()/4,ScrH()/7.5)
		Menu:SetTitle("")
		Menu:CenterHorizontal(0.5)
		Menu:CenterVertical(0)
		Menu:ShowCloseButton(false)
		Menu:MakePopup()

		Menu.Paint = function(self, W, H)
			BlurBackground(self)
			draw.RoundedBox(0, 0, 0, W, H/4.8, Color(197,0,0,49))//TitleBar

			draw.SimpleText("Connection Lost D:", "ARFontTitle", W/2, 0, Color(255, 255, 255), TEXT_ALIGN_CENTER)
			draw.SimpleText(WaitMsg, "ARFontBody", W/2, H/3.3, Color(255, 255, 255), TEXT_ALIGN_CENTER)
		end

		local CancelBtn = vgui.Create("DButton")
		CancelBtn:SetParent(Menu)
		CancelBtn:SetText("")
		CancelBtn:SetSize(Menu:GetWide()/2,Menu:GetTall()/4)
		CancelBtn:SetPos(0,Menu:GetTall()-(Menu:GetTall()/4))
		CancelBtn.Paint = function( self, W, H )
			draw.RoundedBox(0, 0, 0, W, H, Color(57,0,0,66))//TitleBar
			draw.DrawText("Cancel", "ARFontButton", W/2, 2, Color(255,255,255), TEXT_ALIGN_CENTER)
		end

		local DiscBtn = vgui.Create("DButton")
		DiscBtn:SetParent(Menu)
		DiscBtn:SetText("")
		DiscBtn:SetSize(Menu:GetWide()/2,Menu:GetTall()/4)
		DiscBtn:SetPos(Menu:GetWide()/2,Menu:GetTall()-(Menu:GetTall()/4))
		DiscBtn.Paint = function( self, W, H )
			draw.RoundedBox(0, 0, 0, W, H, Color(57,0,0,66))//TitleBar
			draw.DrawText("Disconnect", "ARFontButton", W/2, 2, Color(255,255,255), TEXT_ALIGN_CENTER)
		end

		CancelBtn.DoClick = function()
			Cancelled = true
			CountDownActive = false
			CloseMenu()
		end
		DiscBtn.DoClick = function()
			RunConsoleCommand("disconnect")
		end

	end
	--OpenMenu()

	//Ticks over while the client is connected
	timer.Create("ARConnected",0.5,0,function()
		LastPing = RealTime()
		IsTimingOut = false
		Cancelled = false
		CloseMenu()
	end)

	local LastFrame = RealTime()

	hook.Add( "Think", "ARCheck1.1", function()

	if RealTime() - LastFrame > 0.5 then//check if the client locked up, MUST BE BEFORE RETRY CODE TO PREVENT RETRY
		Message("Client recovered from lockup (".. math.Round(RealTime() - LastFrame, 2) .."s). Resetting timer.")
		LastPing = RealTime()
		IsTimingOut = false
		Cancelled = false
		LastDec = RealTime()
		CloseMenu()
	end
	LastFrame = RealTime()

		local Diff = RealTime() - LastPing
		if Diff > 5 and not IsTimingOut then
			IsTimingOut = true
			OpenMenu()
		end

		if CountDownActive and RealTime() - LastDec > 1 and IsTimingOut then
			if CountDown <= 0 then
				Message("Commencing Auto Reconnect.")
				LocalPlayer():ConCommand("retry")
			end
			LastDec = RealTime()
			CountDown = CountDown - 1
			Message("Countdown: " .. CountDown)
			WaitMsg = "Auto reconnecting in " .. CountDown .. " seconds."
		end

	end)

	hook.Add("ShutDown", "ARSHUTDOWN", function()
		Message("SHUTDOWN")
	end )
	

	-- Страшные звуки падения

	local lply = LocalPlayer()
	local fallsnd = false
	local waterlevel = 0
	local oldwater = 0
	local highwater = {
		"zcity/other/enterwater_highvelocity_01.wav", "zcity/other/enterwater_highvelocity_02.wav", "zcity/other/enterwater_highvelocity_03.wav"
	}
	local normwater = {
		"zcity/other/enterwater_lowvelocity_01.wav", "zcity/other/enterwater_lowvelocity_02.wav"
	}
	local exitwater = {
		"zcity/other/exitwater_01.wav", "zcity/other/exitwater_02.wav"
	}
	local windsnd = false
	local windsndsec = false
	local DEBIL_ANGLE = Angle(0,0,0)
	hook.Add("SetupMove","hg_FallSound",function()
		local ply = lply:Alive() and lply
		if not ply then return end
		local ent = hg.GetCurrentCharacter(ply)
		if not ent then return end
		local vel = ent:GetVelocity():Length()
		if -ent:GetVelocity().z > 700 and (ent:IsRagdoll() or !ply:OnGround()) and (ent:IsRagdoll() and !ent:IsConstrained() or ply:GetMoveType() == MOVETYPE_WALK) then
			if !fallsnd then
				fallsnd = lply:StartLoopingSound("zcity/other/fallstatic.wav")
			end
			local ang = ent:IsRagdoll() and AngleRand(-(vel/100),vel/100) or AngleRand(-(1-vel/700),1-vel/700)
			--ang.r = 0
			lply:SetEyeAngles(lply:EyeAngles() + ang)
			DEBIL_ANGLE:Add(ang)
		elseif fallsnd then
			lply:StopLoopingSound(fallsnd)
			fallsnd = false
			local ang = lply:EyeAngles() - DEBIL_ANGLE
			ang[3] = 0
			lply:SetEyeAngles(ang)
			DEBIL_ANGLE:Zero()
		end

		waterlevel = ply:WaterLevel()

		--if lply:Alive() and waterlevel == 0 and vel > 500 and (ent:IsRagdoll() or !ply:OnGround()) and (ent:IsRagdoll() and !ent:IsConstrained() or ply:GetMoveType() == MOVETYPE_WALK) then
		--	if !windsndsec then
		--		--windsndsec = lply:StartLoopingSound("zcity/other/clotheswind.wav")
		--	end
		--elseif windsndsec then
		--	lply:StopLoopingSound(windsndsec)
		--	windsndsec = false
		--end

		if waterlevel == 3 and oldwater ~= 3 then
			if vel > 200 then
				lply:EmitSound(table.Random(highwater),125,100,1,CHAN_AUTO)
			else
				lply:EmitSound(table.Random(normwater),35,100,1,CHAN_AUTO)
			end
		end
		if waterlevel < 3 and oldwater == 3 then
			lply:EmitSound(table.Random(exitwater),35,100,1,CHAN_AUTO)
		end
		oldwater = waterlevel
	end)
end

timer.Simple(5,function()
	hook.Add( "ScaleNPCDamage", "AddHeadshotPuffNPC", function( npc, hitgroup, dmginfo )

	end )

	hook.Add( "ScalePlayerDamage", "AddHeadshotPuffPlayer", function( ply, hitgroup, dmginfo )

	end )

	hook.Add( "EntityTakeDamage", "AddHeadshotPuffRagdoll", function( target, dmginfo )

	end )
end)

--if SERVER then
	local ENTITY = FindMetaTable("Entity")

	function ENTITY:SetBoneMatrix2(boneID,matrix)
		--self:ManipulateBonePosition(boneID,vector_origin,false)
		--self:ManipulateBoneAngles(boneID,angle_zero,false)
		local localpos = self:GetManipulateBonePosition(boneID)
		local localang = self:GetManipulateBoneAngles(boneID)
		local newmat = Matrix()
		newmat:SetTranslation(localpos)
		newmat:SetAngles(localang)
		local inv = newmat:GetInverse()
		local oldMat = self:GetBoneMatrix(boneID) * inv
		local newMat = oldMat:GetInverse() * matrix
		local lpos,lang = newMat:GetTranslation(),newMat:GetAngles()
		--local lpos,lang = WorldToLocal(matrix:GetTranslation(),matrix:GetAngles(),oldMat:GetTranslation(),oldMat:GetAngles())
		self:ManipulateBonePosition(boneID,lpos,false)
		self:ManipulateBoneAngles(boneID,lang,false)
		--self:ManipulateBonePosition(boneID,vector_origin,false)
		--self:ManipulateBoneAngles(boneID,angle_zero,false)
	end
--end




hook.Add( "PlayerGiveSWEP", "BlockPlayerSWEPs", function( ply, class, spawninfo )
	if ( not ply:IsAdmin() and (class == "weapon_hg_rpg" or class == "weapon_ags_30_handheld" or class == "weapon_kord") ) then
		return false
	end
end )

hook.Add( "PlayerSpawnSWEP", "BlockPlayerSWEPs", function( ply, class, spawninfo )
	if ( not ply:IsAdmin() and (class == "weapon_hg_rpg" or class == "weapon_ags_30_handheld" or class == "weapon_kord") ) then
		return false
	end
end )




if CLIENT then
	hook.Add("Player Death","fuckingfuckfuck",function(ply)
		timer.Simple(0.1,function()
			local ang = ply:EyeAngles()
			ang[3] = 0
			ply:SetEyeAngles(ang)
		end)
	end)

	hg.flashes = {}
	local tab = {}

	local blackout_mat = Material("sprites/mat_jack_hmcd_narrow")

	function hg.AddFlash(eyepos, dot, pos, time, size)
		time = time or 20
		size = size or 1000--pixels
		size = size / math.max(pos:Distance(eyepos) / 32,0.01) * (dot^2)
		local taint = math.max(200 - size,0) / 200 * time * 0.9
		local scr = pos:ToScreen()

		table.insert(hg.flashes,{x = scr.x, y = scr.y, time = CurTime() + time - taint, lentime = time, size = size})
	end

	local flash
	local mat = Material("sprites/orangeflare1_gmod")
	local mat2 = Material("sprites/glow04_noz")

	local amtflashed = 0

	hook.Add("Player Death","huyhuyhuy",function(ply)
		if ply == LocalPlayer() then
			hg.flashes = {}
		end
	end)

	hook.Add("RenderScreenspaceEffects","flasheseffect",function()
		amtflashed = 0
		for i = 1,#hg.flashes do
			flash = hg.flashes[i]

			if (flash.time or 0) < CurTime() then table.remove(hg.flashes[i]) continue end

			local animpos = (flash.time - CurTime()) / flash.lentime
			local size = flash.size

			flash.animpos = animpos

			amtflashed = amtflashed + animpos * size / 5000
		end

		tab["$pp_colour_brightness"] = 0 - math.max(amtflashed-0.1,0)
		DrawColorModify(tab)

		for i = 1,#hg.flashes do
			flash = hg.flashes[i]

			local animpos = flash.animpos
			local size = flash.size

			surface.SetMaterial(mat)
			surface.SetDrawColor(255,255,255,animpos * 255)
			surface.DrawTexturedRect(flash.x - size / 2, flash.y - size / 2, size, size)
			surface.SetMaterial(mat2)
			surface.DrawTexturedRect(flash.x - size / 2, flash.y - size / 2, size, size)
		end
	end)
end


AddCSLuaFile()

hg = hg or {}

local Timestamp = os.time()
local TimeString = os.date( "*t" , Timestamp )
    --		  "cs_office",
    --        "cs_drugbust_winter",
    --        "gm_zabroshka_winter",
    --        "mu_smallotown_v2_snow",
    --        "ttt_clue_xmas",
    --        "ttt_cosy_winter",
    --        "ttt_winterplant_v4"
hg.ColdMaps = {
	["gm_wintertown"] = true,
	["cs_drugbust_winter"] = true,
	["cs_office"] = true,
	["gm_zabroshka_winter"] = true,
	["mu_smallotown_v2_snow"] = true,
	["ttt_cosy_winter"] = true,
	["ttt_winterplant_v4"] = true
}

if SERVER then
	if hg.ColdMaps[game.GetMap()] then
		hook.Add("Org Think", "ColdMaps", function(owner, org, timeValue) 
			if not owner:IsPlayer() then return end
			local ent = hg.GetCurrentCharacter(owner)
			local IsVisibleSkyBox = util.TraceLine( {
				start = ent:GetPos() + vector_up * 15,
				endpos = ent:GetPos() + vector_up * 999999,
				mask = MASK_SOLID_BRUSHONLY
			} ).HitSky
			org.temperature = org.temperature or 36.7
			if IsVisibleSkyBox then
				org.temperature = org.temperature - 0.005
				org.FreezeSndCD = org.FreezeSndCD or CurTime() + 5
				if org.FreezeSndCD < CurTime() and owner:Alive() and not org.otrub then
					org.FreezeSndCD = CurTime() + math.random(30,55)
					ent:EmitSound("zcitysnd/"..(ThatPlyIsFemale(ent) and "fe" or "").."male/freezing_"..math.random(1,8)..".mp3",65)
				end
				--print(org.temperature)
				org.FreezeDMGCd = org.FreezeDMGCd or CurTime()
				if org.temperature < 35 and org.temperature > 24 and org.FreezeDMGCd < CurTime()  then
					--[[local dmg = DamageInfo()
					dmg:SetInflictor(game.GetWorld())
					dmg:SetAttacker(game.GetWorld())
					dmg:SetDamageType(DMG_SHOCK)
					dmg:SetDamage(7)
					owner:TakeDamageInfo(dmg)--]]
					org.painadd = org.painadd + math.Rand(0,1) * ((35 - org.temperature) / 35 * 4 + 1)
					org.FreezeDMGCd = CurTime() + 0.5
				end
			else
				org.temperature = math.min(org.temperature + 0.1, 36.7)
			end
		end)
	end
end
if CLIENT then
	if hg.ColdMaps[game.GetMap()] then

		--local emit
		--local m_mats = {(Material("particle/smokesprites_0001")),(Material("particle/smokesprites_0002")),(Material("particle/smokesprites_0003"))}
--
		--local function breath(ply,size)
		--	if not ply:Alive() then return end
		--	if size <= 0 then return end
		--	if ply:WaterLevel() >= 3 then return end
		--	if not emit then
		--		emit = ParticleEmitter(LocalPlayer():GetPos(),false)
		--	else
		--		emit:SetPos(LocalPlayer():GetPos())
		--	end
		--	local mpos
		--	if GetViewEntity() ~= ply then
		--		local att = ply:LookupAttachment("mouth")
		--		if att <= 0 then return end
		--		mpos = ply:GetAttachment(att)
		--	else
		--		local ang,pos = EyeAngles(),EyePos()
		--		mpos = {Pos = pos + ang:Forward() * 3 - ang:Up() * 2,Ang = ang}
		--	end
		--	if not mpos or not mpos.Pos then return end
		--	local p = emit:Add(table.Random(m_mats),mpos.Pos)
		--		p:SetStartSize(0.1)
		--		p:SetEndSize(size)
		--		p:SetStartAlpha(3)
		--		p:SetEndAlpha(0)
		--		p:SetLifeTime(0)
		--		p:SetGravity(Vector(0,0,0.2))
		--		p:SetDieTime(3)
		--		p:SetLighting(false)
		--		p:SetRoll(math.random(360))
		--		p:SetRollDelta(math.Rand(-0.5,0.5))
		--		p:SetVelocity(mpos.Ang:Forward() * 1 + ply:GetVelocity() / 5)
		--end

		--hook.Add("PostDrawPlayerRagdoll","Huy",function(ent, self)
		--	--if self:IsPlayer() and self:Alive() then
		--	--	local ent = hg.GetCurrentCharacter(self)
		--	--	local IsVisibleSkyBox = util.TraceLine( {
		--	--		start = ent:GetPos() + vector_up * 15,
		--	--		endpos = ent:GetPos() + vector_up * 999999,
		--	--		mask = MASK_SOLID_BRUSHONLY
		--	--	} ).HitSky
		--	--	if IsVisibleSkyBox then
		--	--		self.LastColdBreath = self.LastColdBreath or CurTime() + 3
		--	--		if self.LastColdBreath < CurTime() then
		--	--			breath(self,( 10 ))
		--	--			if self.LastColdBreath + 0.5 < CurTime() then
		--	--				self.LastColdBreath = CurTime() + 3
		--	--			end
		--	--		end
		--	--	end
		--	--end
		--end)

	end
end

if SERVER then
	hook.Remove("KeyPress", "snowballs_pickup")

	if TimeString.month > 10 or TimeString.month < 2 then
		hg.XMAS = true

		print("YAY IT'S XMAS TIME!!!")
		
		hook.Add( "KeyPress", "snowballs_pickup", function( ply, key )
			ply.SnowBallPickupCD = ply.SnowBallPickupCD or 0
			if ply.SnowBallPickupCD > CurTime() then return end
			if ( key == IN_USE ) then
				local tr = hg.eyeTrace(ply, 120)
				if tr.MatType == MAT_SNOW then
					ply:EmitSound("player/footsteps/snow1.wav",65,math.Rand(90,110))
					ply.SnowBallPickupCD = CurTime() + 1 
					ply:Give("weapon_hg_snowball")
				end
			end
		end )

	end
end

if hg.XMAS then
    --Firework trails
    game.AddParticles( "particles/gf2_trails_firework_rocket_01.pcf") 
    
    PrecacheParticleSystem("gf2_firework_trail_main")
    --Firework Large Explosions
    game.AddParticles( "particles/gf2_large_rocket_01.pcf" )
    game.AddParticles( "particles/gf2_large_rocket_02.pcf" )
    game.AddParticles( "particles/gf2_large_rocket_03.pcf" )
    game.AddParticles( "particles/gf2_large_rocket_04.pcf" )
    game.AddParticles( "particles/gf2_large_rocket_05.pcf" )
    game.AddParticles( "particles/gf2_large_rocket_06.pcf" )
    
    PrecacheParticleSystem( "gf2_rocket_large_explosion_01" )
    PrecacheParticleSystem( "gf2_rocket_large_explosion_02" )
    PrecacheParticleSystem( "gf2_rocket_large_explosion_03" )
    PrecacheParticleSystem( "gf2_rocket_large_explosion_04" )
    PrecacheParticleSystem( "gf2_rocket_large_explosion_05" )
    PrecacheParticleSystem( "gf2_rocket_large_explosion_06" )
    
    --Battery stuff
    game.AddParticles( "particles/gf2_battery_generals.pcf" ) 
    game.AddParticles( "particles/gf2_battery_01_effects.pcf" )
    game.AddParticles( "particles/gf2_battery_02_effects.pcf" )
    game.AddParticles( "particles/gf2_battery_03_effects.pcf" )
    game.AddParticles( "particles/gf2_battery_mine_01_effects.pcf" )
    
    --Cakes stuff
    game.AddParticles( "particles/gf2_cake_01_effects.pcf" )
    
    
    --Firecrackers stuff
    game.AddParticles( "particles/gf2_firecracker_m80.pcf" )
    
    --Misc
    game.AddParticles( "particles/gf2_misc_neighborhater.pcf" )
    game.AddParticles( "particles/gf2_matchhead_light.pcf" )
    
    --Fountains
    
    game.AddParticles( "particles/gf2_fountain_01_effects.pcf")
    game.AddParticles( "particles/gf2_fountain_02_effects.pcf")
    game.AddParticles( "particles/gf2_fountain_03_effects.pcf")
    game.AddParticles( "particles/gf2_fountain_04_effects.pcf")
    game.AddParticles( "particles/gf2_fountain_05_effects.pcf")
    
    --Mortars
    game.AddParticles( "particles/gf2_mortar_shells_effects.pcf")
    game.AddParticles( "particles/gf2_mortar_shells_big_01.pcf")
    game.AddParticles( "particles/gf2_mortar_shells_big_02.pcf")
    game.AddParticles( "particles/gf2_mortar_shells_big_03.pcf")
    
    
    --Wheels
    
    game.AddParticles( "particles/gf2_wheel_01.pcf")
    
    -- Flares
    game.AddParticles( "particles/gf2_flare_multicoloured_effects.pcf")
    
    -- Giga rockets
    
    game.AddParticles( "particles/gf2_gigantic_rocket_01.pcf" )
    game.AddParticles( "particles/gf2_gigantic_rocket_02.pcf" )
    
    -- Roman Candles
    game.AddParticles( "particles/gf2_romancandle_01_effect.pcf" )
    game.AddParticles( "particles/gf2_romancandle_02_effect.pcf" )
    game.AddParticles( "particles/gf2_romancandle_03_effect.pcf" )
    
    --Small Fireworks
    game.AddParticles( "particles/gf2_firework_small_01.pcf" )
end

--bloody players
--if CLIENT then
--
--	local Materials = {
--		["blood1"] = Material("decals/zcity/blood_overlay1"),
--		["blood2"] = Material("decals/zcity/blood_overlay2"),
--
--		["syntblood1"] = Material("decals/zcity/synthblood_overlay1"),
--		["syntblood2"] = Material("decals/zcity/synthblood_overlay2"),
--
--		["explosion1"] = Material("decals/zcity/scorch_overlay1"),
--		["explosion2"] = Material("decals/zcity/scorch_overlay2"),
--	}
--
--	local function DrawOverlays( ent )
--		local Overlays = ent.DmgOverlays or {}
--		local keys = table.GetKeys( Overlays )
--		if not ent.Overlay then
--			ent.Overlay = ClientsideModel(ent:GetModel())
--			ent.Overlay:SetNoDraw(true)
--			ent:CallOnRemove("RemoveOverlays",function()
--				ent.Overlay:Remove()
--				ent.Overlay = nil
--			end)
--			ent.Overlay:AddEffects( EF_BONEMERGE )
--		end
--
--		if ent.Overlay:GetModel() != ent:GetModel() then
--			ent.Overlay:SetModel( ent:GetModel() )
--			for i=0, ent.Overlay:GetBoneCount()-1 do
--				ent.Overlay:ManipulateBoneScale(i,Vector(1.01,1.01,1.01))
--			end
--		end
--		render.OverrideBlend( true, BLEND_SRC_ALPHA, BLEND_ONE_MINUS_SRC_ALPHA, BLENDFUNC_ADD )
--		for	i = 1, #keys do 
--			local Overlay = Overlays[keys[i]]
--			if not Overlay then continue end
--			--render.SetBlend( Overlay[2] * 0.9 )
--			render.MaterialOverride( Materials[Overlay[1]] )
--			ent.Overlay:SetPos(ent:GetPos()+vector_up * 1)
--			ent.Overlay:SetParent(ent)
--			--ent.Overlay:SetupBones()
--			--ent.Overlay:SetModelScale(1)
--			for i=0, ent.Overlay:GetBoneCount()-1 do
--				ent.Overlay:ManipulateBoneScale(i,Vector(1.01,1.01,1.01))
--			end
--			ent.Overlay:DrawModel()
--		end
--		
--		render.OverrideBlend( false )
--		render.SetBlend(1)
--		render.MaterialOverride( nil )
--	end
--
--	hook.Add("DrawPlayerOverlay", "DrawDamageOverlays", function(ent, self)
--		--local view = render.GetViewSetup().origin
--		--if ent:GetPos():Distance(view) < 5000 and ( not ent:IsPlayer() and true or ent:Alive() ) then
--		--	DrawOverlays( ent )
--		--	--ent:DrawModel()
--		--end
--	end)
--
--	hook.Add("OnNetVarSet","DmgOverlaysVarSet",function(index, key, var)
--		if key == "DmgOverlays" then
--			timer.Simple(.1,function()
--				local ent = Entity(index)
--				if ent.DmgOverlays then
--					table.Empty( ent.DmgOverlays )
--				end
--				--print(ent.DmgOverlays)
--				ent.DmgOverlays = var
--			end)
--		end
--	end)
--
--end
--
--if SERVER then
--	local entmeta = FindMetaTable("Entity")
--
--	function entmeta:AddOverlay( matOverlay, alpha )
--		local tbl = self:GetNetVar( "DmgOverlays", {} ) or {}
--		tbl[matOverlay] = {matOverlay, alpha}
--		self:SetNetVar("DmgOverlays", tbl)
--	end
--
--	function entmeta:RemoveOverlay( matOverlay )
--		local tbl = self:GetNetVar( "DmgOverlays", {} )
--		if tbl[matOverlay] then
--			tbl[matOverlay] = nil
--		end
--		self:SetNetVar("DmgOverlays", tbl)
--	end
--
--	function entmeta:RemoveOverlays()
--		local tbl = {}
--		self:SetNetVar("DmgOverlays", tbl)
--	end
--
--end