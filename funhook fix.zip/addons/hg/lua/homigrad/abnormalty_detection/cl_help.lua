-- "addons\\homigrad\\lua\\homigrad\\abnormalty_detection\\cl_help.lua"

-- if(SERVER)then
	-- PrintMessage(HUD_PRINTTALK, "Use 'stats_help' concommand to understand the stats")
-- end

ABNORMALTIESHELP={}
ABNORMALTIESHELP.Stats={
	{
		Name = "Introduction",
		Desc = [[
Seems like you've found something strange.
This book is about commencing rituals and doing other wicked things.

1. Zones
Thaumaturgical zones are special zones, which occur in place of usage of thaumaturgical phrases.
Zones can overlap.
Zones can grow after the usage of thaumaturgical phrases within it.
Zones allow for rituals to take place within.
Zones have special attributes which you may not be able to know just by glance, so keep track of everything.
Growth of thaumaturgical zone is directly affected by the complexity of the thaumaturgical phrase being spoken.

2. Phrases
To chant something useful, you need to put meaning into words.
Every letter of alphabet corresponds to some changes in thaumaturgical table.
You need to create a phrase, that will contain only one thaumaturgical meaning in order to interact with the thaumaturgical zones. This phrase will be added to the zone you're currently standing in.

3. Letters
Thaumaturgical phrases consists of some symbols and thaumaturgical letters.
They will change after map cleanup. This can be delayed by 10 minutes every time by spelling a proper thaumaturgical phrase with these letters.

4. Chanting your first phrase
Try to chant something like "resources of the body" 10 times.
After you chanted it 10 times, some thoughts will appear in your head and point you in the direction you're going.

Example:
<...>
- ноте бено мемо ммммт
~ I'm getting somewhere...
~ sacrifice - 2
~ ritual - 5
~ But there's still something I need to exclude...

So, let's for example get rid of sacrifice
<...>
- ноте бено мемо ммммтч
~ I'm getting somewhere...
~ sacrifice - 1
~ ritual - 6
~ But there's still something I need to exclude...

See, I added letter "ч" and gained 1 ritual and lost 1 sacrifice, let's add one more then
<...>
- ноте бено мемо ммммтчч
~ I'm getting somewhere...
~ ritual - 7
~ This is it... I found it!
~ Now, it's just a matter of chanting it over and over again in one spot...

First thaumaturgical phrase done!

5. Resources
blood:
To collect blood, you need to have someone bleeding within the zone.
Additional blood will be given if you'll draw some kind of symbol.
Note, that zone's starting radius is small and it's growth is slow.

6. Rituals
Continue on the NEXT page.
]]
	},
	{
		Name = "Heal",
		Desc = [[
You will need:
sacrifice 10, help 20
blood 2500
How to activate:
Chant <help 1> 5 times in quick succession (You have 10 seconds)
What it does?:
Almost fully heals one player closest to the center of the thaumaturgical zone.
Be sure to remove other unwanted player before commencing.
Does not cure any mental abnormalties.]]
	},
	{
		Name = "Ressurection",
		Desc = [[
You will need:
sacrifice 50, help 30, ritual 10
blood 3500
How to activate:
Chant <ritual 5> 5 times in quick succession (You have 10 seconds)
What it does?:
Ressurects one body closest to the center of the thaumaturgical zone.
Be sure to remove other unwanted bodies before commencing.
Ressurection, sometimes, yield unforseen consequences.
Besides these consequences, ressurected human can have their heart stopped randomly at first.]]
	},
	{
		Name = "Harm",
		Desc = [[
You will need:
sacrifice 10, help 20
blood 2500
How to activate:
Chant <harm 1> 2 times in quick succession (You have 10 seconds)
What it does?:
]]
	},
}

function ABNORMALTIESHELP:OpenStats(Recipe)
	Recipe=Recipe or 1
	if(!ABNORMALTIESHELP.Stats[Recipe])then Recipe = 1 end
	if(IsValid(ABNORMALTIESHELP.Panel))then ABNORMALTIESHELP.Panel:Remove() end
	ABNORMALTIESHELP.Panel = vgui.Create("DFrame")
	local frame = ABNORMALTIESHELP.Panel

	local size={math.max(ScrW()/4,640),math.max(ScrH()/2.5,640)}
	
	frame:SetTitle("")
	frame:SetSize(size[1], 0)
	frame:SizeTo(size[1], size[2], 0.1)
	frame:SetPos((ScrW()-size[1])/2, (ScrH()-size[2]))
	frame:MoveTo((ScrW()-size[1])/2, (ScrH()-size[2])/2, 0.1)
	frame:MakePopup()
	frame:NoClipping(true)
	frame.Paint = function( sel, w, h )
		local fancyayy ={
			{ x = -10, y = -15 },
			{ x = w+50, y = -10 },
			{ x = w+4, y = h },
			{ x = -5, y = h+3 }
		}
		draw.NoTexture()
		surface.SetDrawColor( 150, 0, 0, 255 )
		surface.DrawPoly(fancyayy)
		local fancyayy1 ={
			{ x = 0, y = 1 },
			{ x = w+40, y = -4 },
			{ x = w, y = h-1 },		
			{ x = 0, y = h }
		}
		draw.NoTexture()
		surface.SetDrawColor( 50, 50, 50, 255 )
		surface.DrawPoly(fancyayy1)
	end
	

	
	frame.Label = Label(ABNORMALTIESHELP.Stats[Recipe].Name, frame)
	frame.Label:SetFont("CloseCaption_Bold")
	frame.Label:Dock( TOP )
	frame.Label:SetSize(size[1],32)

	frame.Desc = vgui.Create("RichText",frame)
	frame.Desc:AppendText(ABNORMALTIESHELP.Stats[Recipe].Desc)
	function frame.Desc:PerformLayout()
		self:SetVerticalScrollbarEnabled(true)
		self:SetFontInternal("CloseCaption_Normal")
	end
	frame.Desc:Dock( TOP )
	frame.Desc:SetSize(size[1]-90,size[2]-100)

	frame.Next = vgui.Create("DButton",frame)
	frame.Next:SetText("Next-->")
	frame.Next.DoClick = function()
		ABNORMALTIESHELP:OpenStats(Recipe+1)
	end
end

concommand.Add("abnormalties_help",function()
	ABNORMALTIESHELP:OpenStats()
end)