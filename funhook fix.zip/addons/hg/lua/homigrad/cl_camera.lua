-- "addons\\homigrad\\lua\\homigrad\\cl_camera.lua"

local view = render.GetViewSetup()
local whitelist = {
	weapon_physgun = true,
	gmod_tool = true,
	gmod_camera = true,
	weapon_crowbar = true,
	weapon_pistol = true,
	weapon_crossbow = true
}

local vecZero, vecFull = Vector(0.001, 0.001, 0.001), Vector(1, 1, 1)
local lply = LocalPlayer()
local CameraTransformApply
local hook_Run = hook.Run
local result
local util_TraceLine, util_TraceHull = util.TraceLine, util.TraceHull
local math_Clamp = math.Clamp
local Round, Max, abs = math.Round, math.max, math.abs
local compression = 12
local traceBuilder = {
	filter = lply,
	mins = -Vector(5, 5, 5),
	maxs = Vector(5, 5, 5),
	mask = MASK_SOLID,
	collisiongroup = COLLISION_GROUP_DEBRIS
}

local anglesYaw = Angle(0, 0, 0)
local vecVel = Vector(0, 0, 0)
local angVel = Angle(0, 0, 0)
local limit = 4
local sideMul = 5
local eyeAngL = Angle(0, 0, 0)
local hg_fov = ConVarExists("hg_fov") and GetConVar("hg_fov") or CreateClientConVar("hg_fov", "70", true, false, "changes fov to value", 75, 100)
local oldview = render.GetViewSetup()
local breathing_amount = 0
local curTime = CurTime()
local curTime2 = CurTime()
local angfuk23 = Angle(0,0,0)
local vecdiff = Vector(0, 0, 0)
angle_difference_localvec = Vector(0, 0, 0)
angle_difference = Angle(0, 0, 0)
angle_difference2 = Angle(0, 0, 0)
position_difference = Vector(0, 0, 0)
position_difference3 = Vector(0, 0, 0)

offsetView = offsetView or Angle(0, 0, 0)

camera_position_addition = Vector(0,0,0)

local swayAng = Angle(0, 0, 0)
hook.Add("Camera", "Weapon", function(ply, ...)
	local ply = ply or lply
	wep = ply:GetActiveWeapon()
	if wep.Camera then return wep:Camera(...) end
end)

hook.Add("MotionBlur", "Weapon", function(x,y,w,z)
	wep = lply:GetActiveWeapon()
	if wep.Blur then return wep:Blur(x,y,w,z) end
end)

hook.Add("GetMotionBlurValues", "MotionBlurEffect", function( x, y, w, z)
    local blur = hook_Run("MotionBlur",x,y,w,z)
	if blur then
		return blur[1],blur[2],blur[3],blur[4]
	end
end)

local TickInterval = engine.TickInterval

-- local hg.clamp = hg.hg.clamp

local lerpholdbreath = 1

local lerped_ang = Angle(0,0,0)
function HGAddView(ply, origin, angles)
	if ply:Alive() then
		local org = ply.organism or {}
		local pulse = org.pulse or 70
		local adrenaline = org.adrenaline or 0

		local wep = ply:GetActiveWeapon()
		local inSight = IsValid(wep) and wep.IsZoom and wep:IsZoom()

		breathing_amount = breathing_amount + math.Clamp((pulse / 80 - 1) / 50,0,0.02)

		camera_position_addition[1] = 0
		camera_position_addition[2] = 0
		camera_position_addition[3] = 0
		
		camera_position_addition[3] = ((math.sin(breathing_amount) + 1) / 2 - 0.5) * math.Clamp((math.max(pulse / (inSight and 100 or 80),1) - 1) / 2,0,0.5)
		
		origin:Add(camera_position_addition)

		local ang = AngleRand(-0.1, 0.1) * math.Rand(0, math.min(adrenaline, 1)) / 1
		ang[3] = 0

		lerped_ang = LerpFT(0.2,lerped_ang,ang * (inSight and 3 or 1) * math.max(org.recoilmul or 1,0.1))
		angles:Add(ang)
		ply:SetEyeAngles(ply:EyeAngles() + lerped_ang)

		if(ply.MovementInertiaAddView)then
			angles = angles + ply.MovementInertiaAddView
			ply.MovementInertiaAddView.r = Lerp(FrameTime() * 5, ply.MovementInertiaAddView.r, 0)
			ply.MovementInertiaAddView.p = Lerp(FrameTime() * 5, ply.MovementInertiaAddView.p, 0)
		end
	else
		if(ply.MovementInertiaAddView)then
			ply.MovementInertiaAddView.r = 0
			ply.MovementInertiaAddView.p = 0
		end
	end
	
	return origin, angles
end

hook.Add("ShouldDrawLocalPlayer","drawlocalplayeralways",function(ply)
	--return true
end)
local materialsWheelDirve = {
	["dirt"] = true, ["sand"] = true, ["grass"] = true
}
local calcSway = Angle(0,0,0)
local calcSway2 = Angle(0,0,0)

LookX, LookY = 0, 0
local altlook = false
local sending = false
local CoolDown = 0

local keydownattack
local keydownattack2
local keydownreload
--LocalPlayer():ChatPrint(tostring(g_VR.active))
local lerpfovadd = 0
local angZero = Angle(0,0,0)
local CalcView
local oldVechicleAng = Angle(0,0,0)
local isdead = not LocalPlayer():Alive()
CalcView = function(ply, origin, angles, fov, znear, zfar)
	if g_VR and g_VR.active then return end

	if not IsValid(ply) or not ply:Alive() then
		if not IsValid(ply) then return end
		if isdead and ply:Alive() then isdead = false end
		if isdead then return end
		local hand = ply:GetAttachment(ply:LookupAttachment("anim_attachment_rh"))
		local eye = ply:GetAttachment(ply:LookupAttachment("eyes"))
		local eyeAngs = ply:EyeAngles()
		local body = ply:LookupBone("ValveBiped.Bip01_Spine2")
		local ragdoll = ply:GetNWEntity("Ragdoll")
		local matrix = ply:GetBoneMatrix(body)
		local bodypos = matrix:GetTranslation()
		local bodyang = matrix:GetAngles()

		if not IsValid(ragdoll) then return end

		ragdoll:ManipulateBoneScale(6,Vector(1,1,1))

		local att = ragdoll:GetAttachment(ragdoll:LookupAttachment("eyes"))

		view.origin = att.Pos
		view.angles = att.Ang
		if not timer.Exists("DeathTimer") and not isdead then
			timer.Create("DeathTimer",5,1,function()
				LocalPlayer():ScreenFade( SCREENFADE.IN, Color( 0, 0, 0, 255 ), 1, 0.2 )
				isdead = true
				--timer.Remove("DeathTimer")
			end)
		end
		return view
	end
	isdead = false
	
	if not IsValid(ply) then return end

	if not ply:Alive() and not follow then
		if lply:GetNWInt("viewmode",0) == 1 then
			ply = lply:GetNWEntity("spect",NULL)
			
			if IsValid(ply) then
				angles = ply:EyeAngles()
				--lply:SetEyeAngles(ply:EyeAngles())
			end
		else
			return hook.Run("HG_CalcView",lply, origin, angles, fov, znear, zfar)
		end
	end
	
	if not IsValid(ply) or not ply.LookupBone or not ply:LookupBone("ValveBiped.Bip01_Head1") then return end
	
	if not ply.GetAimVector then return end

	local firstPerson = GetViewEntity() == lply
	ply:ManipulateBoneScale(ply:LookupBone("ValveBiped.Bip01_Head1"), firstPerson and vecZero or vecFull)
	
	if not firstPerson or IsValid(ply.FakeRagdoll) then return end
	
	ply:SetupBones()

	local tr, hullcheck, headm = hg.eyeTrace(ply)
	local eyePos = tr.StartPos
	local vehicle = ply:GetVehicle()
	local vehiclebase = ply:GetSimfphys()
	local BadSurfaceDrive = false
	
	if IsValid(vehicle) and IsValid(vehiclebase) then
		vehicle = vehiclebase
		local tr = util.TraceLine( {
			start = vehicle:GetPos(),
			endpos = vehicle:GetPos() + vector_up * -55,
			mask = MASK_SOLID_BRUSHONLY,
		} )
		local surfaces = util.GetSurfacePropName( tr.SurfaceProps )
		if materialsWheelDirve[surfaces] then
			BadSurfaceDrive = true
		end
		--local angPunch = vehicle:GetAngles()
		--angPunch:Sub(oldVechicleAng)
		--angPunch:Div(5)
		--ViewPunch2(angPunch)
		--oldVechicleAng = vehicle:GetAngles()
	end

	local vel = ( ply:InVehicle() and -vehicle:GetVelocity() or -ply:GetVelocity()) / (ply:InVehicle() and (BadSurfaceDrive and 150 or 550) or 200)
	local velLen = vel:Length()
	ViewPunch(AngleRand(-1,1) * velLen/(BadSurfaceDrive and 15 or 50))

	eyePos:Add(VectorRand() * ( (ply:InVehicle() or velLen > 2) and (velLen +( ply:InVehicle() and 0 or - 2)) / (ply:InVehicle() and 50 or 10) or 0))
	hg.clamp(vel, limit)

	angles = angles + Angle(LookY,-LookX,0)
	
	hg.cam_things(ply,view,angles)

	local pos = origin - eyePos
	if not RENDERSCENE then
		local CamControl = hook.Run("HG_CalcView",ply, origin, angles, fov, znear, zfar)
		if CamControl ~= nil then
			return CamControl
		end
	end

	lerpfovadd = Lerp(0.01,lerpfovadd,(ply:IsSprinting() and ply:GetVelocity():LengthSqr() > 1500 and 10 or 0) - ( ply.organism and (ply.organism and (((ply.organism.immobilization or 0) / 4) - (ply.organism.adrenaline or 0) * 5)) or 0) / 2 - (ply.suiciding and (ply:GetNetVar("suicide_time",CurTime()) < CurTime()) and (1 - math.max(ply:GetNetVar("suicide_time",CurTime()) + 8 - CurTime(),0) / 8) * 20 or 0))

	--local angle = tr.Normal:Angle()
	--angle[3] = angles[3]

	view.znear = 1
	view.zfar = zfar
	view.fov = math.Clamp(hg_fov:GetFloat(),75,100) + lerpfovadd
	view.drawviewer = true--not hullcheck.Hit
	view.origin = origin
	view.angles = angles
	
	result = hook_Run("Camera", ply, pos, angles, view, velLen * 200)
	--if not RENDERSCENE then
	view.origin, view.angles = HGAddView(ply, view.origin, view.angles)
	--end
	
	--[[if lply:InVehicle() then
		local FPersPos =  lply:GetAttachment(lply:LookupAttachment( "eyes" ))
		view.origin = FPersPos.Pos
		view.angles = FPersPos.Ang
		return view
	end--]]

	if angles[1] > 54 and angles[1] < 65 then
		ply:DrawModel()
	end

	if result == view then
		traceBuilder.start = origin
		traceBuilder.endpos = view.origin
		local trace = hg.hullCheck(origin,view.origin,ply)
		local pos = view.origin - trace.HitPos
		view.origin = view.origin - pos
		return view
	end
	
	if !ply:GetNWBool("Fake") then
		view.origin = origin - pos
		view.angles = angles
		else
		local hand = ply:GetAttachment(ply:LookupAttachment("anim_attachment_rh"))
		local eye = ply:GetAttachment(ply:LookupAttachment("eyes"))
		local eyeAngs = ply:EyeAngles()
		local body = ply:LookupBone("ValveBiped.Bip01_Spine2")
		local ragdoll = ply:GetNWEntity("Ragdoll")
		local matrix = ply:GetBoneMatrix(body)
		local bodypos = matrix:GetTranslation()
		local bodyang = matrix:GetAngles()
	
		if not IsValid(ragdoll) then return end
	
		ragdoll:ManipulateBoneScale(6,vecZero)
		
		local att = ragdoll:GetAttachment(ragdoll:LookupAttachment("eyes"))

		if not LerpEyeRagdoll then
			LerpEyeRagdoll = Angle(0,0,0)
		end
	
		LerpEyeRagdoll = LerpAngleFT(0.15 ,LerpEyeRagdoll,LerpAngle(0.4,eyeAngs,att.Ang))
	
		view.origin = att.Pos
		view.angles = LerpEyeRagdoll
		end

	wep = ply:GetActiveWeapon()
	if IsValid(wep) and whitelist[wep:GetClass()] then return end
	
	return view
end
local angleZero = Angle(0,0,0)
function hg.cam_things(ply,view,angles)
	local wep = ply:GetActiveWeapon()
	local eyeAngs = ply:GetAimVector():Angle()
	local oldviewa = oldview or view
	--local oldorigin = originnew or ply:EyePos()
	oldviewa = not ply:Alive() and view or oldviewa
	
	local different,_ = WorldToLocal(eyeAngs:Forward(),angle_zero,(eyeAnglesOld or eyeAngs):Forward(),angle_zero)
	different = -different / 2
	local _, localAng = WorldToLocal(vector_origin, eyeAngs, vector_origin, eyeAnglesOld or eyeAngs)
	
	local fthuy = ftlerped * 150 * game.GetTimeScale()--hg.FrameTimeClamped() * 300
	
	angle_difference_localvec = LerpVectorFT(0.1, angle_difference_localvec, different * 2 / (fthuy))
	angle_difference = LerpAngleFT(0.05, angle_difference, localAng * 2 / (fthuy))
	angle_difference2 = LerpAngleFT(0.1, angle_difference2, localAng * 2 / (fthuy))
	position_difference = LerpVectorFT(0.15, position_difference, -(hg.GetCurrentCharacter(ply):GetVelocity() / 50))

	--if hg.GetCurrentCharacter(ply) ~= ply then position_difference:Zero() end

	table.CopyFromTo(view, oldview)
	--originnew = ply:GetPos()

	position_difference3[1] = 0
	position_difference3[3] = 0
	position_difference3[2] = position_difference:Dot(eyeAngs:Right()) * (fthuy)
	
	hg.clamp(position_difference, 10)
	hg.clamp(position_difference3, 5)
	hg.clamp(angle_difference_localvec, 10)
	hg.clamp(angle_difference, 10)
	hg.clamp(angle_difference2, 10)

	offsetView[1] = math_Clamp(offsetView[1] - angle_difference2[1] / 24, -4, 4)
	offsetView[2] = math_Clamp(offsetView[2] - angle_difference2[2] / 24, -4, 4)
	offsetView = LerpFT(0.1,offsetView,angleZero)
	eyeAnglesOld = eyeAngs
	local position_differencedot = position_difference:Dot(angles:Right()) * 2
	angles[3] = angles[3] - angle_difference[2] * 0.5
	--angles[3] = angles[3] - position_differencedot
	angles[3] = angles[3] - (lean_lerp or 0) * 5
end

concommand.Add("+altlook",function()
	altlook = true
end)
concommand.Add("-altlook",function()
	altlook = false
end)

hook.Add( "HG.InputMouseApply", "FreezeTurning", function( tbl )
	if not altlook then
		LookY = LerpFT(0.1, LookY, 0)
		LookY = math.abs(LookY) > 0.01 and LookY or 0
		LookX = LerpFT(0.1, LookX, 0)
		LookX = math.abs(LookX) > 0.01 and LookX or 0
	end
	
	if altlook and LocalPlayer():Alive() then
		LookX = math.Clamp(LookX + tbl.x * 0.015, -35, 35)
    	LookY = math.Clamp(LookY + tbl.y * 0.015, -25, 25)
		
		tbl.x = 0
		tbl.y = 0
	end
end )

hg.CalcView = CalcView
hook.Add("CalcView", "homigrad-view", CalcView)

local hook_Run = hook.Run
local render_RenderView = render.RenderView
local renderView = {
	x = 0,
	y = 0,
	drawhud = true,
	drawviewmodel = true,
	dopostprocess = true,
	drawmonitors = true,
	fov = 100
}


hook.Add("RenderScene", "jopa", function(pos, angle, fov)
	RENDERSCENE = true
	local view = CalcView(lply, pos, angle, fov)
	RENDERSCENE = nil
	if not view then return end
	renderView.w = ScrW()
	renderView.h = ScrH()
	renderView.fov = fov
	renderView.origin = view.origin
	renderView.angles = view.angles
	pcall(render_RenderView,renderView)
	if not LocalPlayerSeen then LocalPlayer():DrawModel() end
	return true
end)

local vector_zero = Vector(0,0,0)
net.Receive("LookAway",function()
	local ply = net.ReadEntity()
	local LookX = net.ReadFloat()
	local LookY = net.ReadFloat()
	
	ply.LookX1 = LookX
	ply.LookY1 = LookY
	ply.LastLookSend = CurTime()
end)

local angle_use = Angle(0,0,0)
hook.Add("Bones","HeadTurnAway",function(ply)
	if ply ~= hg.GetCurrentCharacter(ply) then return end
	if (ply.head_netsendtime or 0) < CurTime() and ply == LocalPlayer() and (hg.IsChanged(LookX, "LookX") or hg.IsChanged(LookY, "LookY")) then
		ply.head_netsendtime = CurTime() + 0.1
		
		--net.Start("LookAway", true) --мда
		--net.WriteFloat(LookX)
		--net.WriteFloat(LookY)
		--net.SendToServer()
	end

	local lply = ply == LocalPlayer()

	if not lply and ((ply.LastLookSend or 0) + 1) < CurTime() then
		ply.LookX = nil
		ply.LookY = nil
	end

	ply.LookX = Lerp(0.1, ply.LookX or 0, lply and LookX or ply.LookX1 or 0)
	ply.LookY = Lerp(0.1, ply.LookY or 0, lply and LookY or ply.LookY1 or 0)

	local angle = angle_use
	angle[2] = -(ply.LookY or 0)
	angle[3] = -(ply.LookX or 0)

	hg.bone.SetAdd(ply, 2, "head", vector_origin, angle)
end)
