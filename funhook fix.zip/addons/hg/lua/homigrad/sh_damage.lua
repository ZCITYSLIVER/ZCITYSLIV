if SERVER then
util.AddNetworkString("TextOnScreen")

local armorMul,armorDur = 1,0

hook.Add("PlayerSpawn","organismSpawn",function(ply)
    if PLYSPAWN_OVERRIDE then return end

    ply.Stamina = 100
    ply.InternalBleeding=nil
    ply.InternalBleeding2=nil
    ply.InternalBleeding3=nil
    ply.InternalBleeding4=nil
    ply.InternalBleeding5=nil
    ply.arterybleeding=false
    ply.brokenSpine=false
    ply.Attacker = nil
    ply.KillReason = nil

    ply.msgLeftArm = 0
    ply.msgRightArm = 0
    ply.msgLeftLeg = 0
    ply.msgRightLeg = 0
    
    ply.LastDMGInfo = nil
    ply.LastHitPhysicsBone = nil
    ply.LastHitBoneName = nil
    ply.LastHitGroup = nil
    ply.LastAttacker = nil
end)

RagdollDamageBoneMul={		--Умножения урона при попадании по регдоллу
	[HITGROUP_LEFTLEG]=0.5,
	[HITGROUP_RIGHTLEG]=0.5,

	[HITGROUP_GENERIC]=1,

	[HITGROUP_LEFTARM]=0.5,
	[HITGROUP_RIGHTARM]=0.5,

	[HITGROUP_CHEST]=1,
	[HITGROUP_STOMACH]=1,

	[HITGROUP_HEAD]=2,
}

bonetohitgroup={ --Хитгруппы костей
    ["ValveBiped.Bip01_Head1"]=1,
    ["ValveBiped.Bip01_R_UpperArm"]=5,
    ["ValveBiped.Bip01_R_Forearm"]=5,
    ["ValveBiped.Bip01_R_Hand"]=5,
    ["ValveBiped.Bip01_L_UpperArm"]=4,
    ["ValveBiped.Bip01_L_Forearm"]=4,
    ["ValveBiped.Bip01_L_Hand"]=4,
    ["ValveBiped.Bip01_Pelvis"]=3,
    ["ValveBiped.Bip01_Spine2"]=2,
    ["ValveBiped.Bip01_L_Thigh"]=6,
    ["ValveBiped.Bip01_L_Calf"]=6,
    ["ValveBiped.Bip01_L_Foot"]=6,
    ["ValveBiped.Bip01_R_Thigh"]=7,
    ["ValveBiped.Bip01_R_Calf"]=7,
    ["ValveBiped.Bip01_R_Foot"]=7
}

local filterEnt
local function filter(ent)
    return ent == filterEnt
end

local util_TraceLine = util.TraceLine

function GetPhysicsBoneDamageInfo(ent,dmgInfo)
    local pos = dmgInfo:GetDamagePosition()
    local dir = dmgInfo:GetDamageForce():GetNormalized()

    dir:Mul(1024 * 8)

    local tr = {}
    tr.start = pos
    tr.endpos = pos + dir
    tr.filter = filter
    filterEnt = ent
    tr.ignoreworld = true

    local result = util_TraceLine(tr)
    if result.Entity ~= ent then
        tr.endpos = pos - dir

        return util_TraceLine(tr).PhysicsBone
    else
        return result.PhysicsBone
    end
end

hook.Add("PlayerUse",function(ply)
    if ply.Fake then return end
    return true
end)

hook.Add("EntityTakeDamage","ZDMG",function(ent,dmginfo)
    if ent == NULL then return end
    if IsValid(ent:GetPhysicsObject()) and dmginfo:IsDamageType(DMG_BULLET+DMG_BUCKSHOT+DMG_CLUB+DMG_GENERIC+DMG_BLAST) then ent:GetPhysicsObject():ApplyForceOffset(dmginfo:GetDamageForce():GetNormalized() * math.min(dmginfo:GetDamage() * 10,3000),dmginfo:GetDamagePosition()) end
    local ply = RagdollOwner(ent) or ent
    if dmginfo:GetDamage() > 8 then
        if ply:IsPlayer() and not ply.Fake and not ply.organism.spine == 0 then
            Faking(ply)
        end
    end
    if ent.IsArmor then
        ply = ent.Owner
        ent = ply:GetNWEntity("Ragdoll") or ply
    end

    if not ply or not ply:IsPlayer() or not ply:Alive() or ply:HasGodMode() then
        return
    end

    local rag = ply ~= ent and ent

    local entAtt = dmginfo:GetAttacker()
    local att =
    (entAtt:IsPlayer() and entAtt:Alive() and entAtt) or

    (entAtt:GetClass() == "wep" and entAtt:GetOwner())
    att = dmginfo:GetDamageType() ~= DMG_CRUSH and att or ply.LastAttacker
    
    if att then
    if rag and dmginfo:IsDamageType(DMG_CRUSH) and att and att:IsRagdoll() then
        dmginfo:SetDamage(0)

        return true
    end
    end

    local physics_bone = GetPhysicsBoneDamageInfo(ent,dmginfo)

    local hitgroup
    local isfall

    local bonename = ent:GetBoneName(ent:TranslatePhysBoneToBone(physics_bone))
    ply.LastHitBoneName = bonename

    if bonetohitgroup[bonename] then hitgroup = bonetohitgroup[bonename] end

    local mul = RagdollDamageBoneMul[hitgroup]

    if rag and mul then dmginfo:ScaleDamage(mul) end


    ply.LastAttacker = att
    ply.LastHitGroup = hitgroup

    if JMod then
        local armors = JMod.LocationalDmgHandling(ply,hitgroup,dmginfo)
        local armorMul,armorDur = 1,0
        local haveHelmet

        for armorInfo,armorData in pairs(armors) do
            local dur = armorData.dur / armorInfo.dur

            local slots = armorInfo.slots
            if dmginfo:IsDamageType(DMG_BULLET + DMG_BUCKSHOT) then
                if (slots.mouthnose or slots.head) then
                    sound.Emit(ent,"player/bhit_helmet-1.wav",90)

                    haveHelmet = true
                elseif
                    slots.leftshoulder or
                    slots.rightshoulder or
                    slots.leftforearm or
                    slots.rightforearm or
                    slots.leftthigh or
                    slots.rightthigh or
                    slots.leftcalf or
                    slots.rightcalf
                then
                    sound.Emit(ent,"snd_jack_hmcd_ricochet_"..math.random(1,2)..".wav",90)
                else
                    sound.Emit(ent,"player/kevlar" .. math.random(1,6) .. ".wav",90)
                end
            end

            if dur >= 0.25 then
                armorDur = (armorData.dur / 100) * dur

                armorMul = math.max(1 - armorDur,0.25)

                break
            end
        end
    else
        armorMul = 0.2
        armorDur = 0
        haveHelmet = false
    end

    dmginfo:SetDamage(dmginfo:GetDamage())
    local dmginf = DamageInfo()
    dmginf:SetAttacker(dmginfo:GetAttacker())
    dmginf:SetDamage(dmginfo:GetDamage())
    dmginf:SetDamageType(dmginfo:GetDamageType())
    dmginf:SetDamagePosition(dmginfo:GetDamagePosition())
    dmginf:SetDamageForce(dmginfo:GetDamageForce())

    ply.LastDMGInfo = dmginf
    
    if rag then
        if dmginfo:GetDamageType() == DMG_CRUSH then
            dmginfo:ScaleDamage(1 / 15)
            hook.Run("ZCityorganism",ply,hitgroup,dmginfo,rag,armorMul,armorDur,haveHelmet)
        else
            if dmginfo:IsDamageType(DMG_BULLET+DMG_BUCKSHOT) then
                dmginfo:ScaleDamage(1) 
                hook.Run("ZCityorganism",ply,hitgroup,dmginfo,rag,armorMul,armorDur,haveHelmet)
                dmginfo:ScaleDamage(1)
                elseif dmginfo:IsDamageType(DMG_CLUB+DMG_GENERIC+DMG_SLASH) then
                dmginfo:ScaleDamage(0.35)
                hook.Run("ZCityorganism",ply,hitgroup,dmginfo,rag,armorMul,armorDur,haveHelmet)
                dmginfo:ScaleDamage(0.32)
                else
                dmginfo:ScaleDamage(1)
                hook.Run("ZCityorganism",ply,hitgroup,dmginfo,rag,armorMul,armorDur,haveHelmet)
                dmginfo:ScaleDamage(1)
            end
        end

        ply:SetHealth(ply:Health() - dmginfo:GetDamage())

        if ply:Health() <= 0 then ply:Kill() end
    else
        if dmginfo:GetDamage() > 25 then
            Faking(ply)
        end
        if dmginfo:IsDamageType(DMG_BULLET+DMG_BUCKSHOT) then
        dmginfo:ScaleDamage(.25) 
        hook.Run("ZCityorganism",ply,hitgroup,dmginfo,rag,armorMul,armorDur,haveHelmet)
        dmginfo:ScaleDamage(.15)
        elseif dmginfo:IsDamageType(DMG_CLUB+DMG_GENERIC+DMG_SLASH) then
        dmginfo:ScaleDamage(0.35)
        hook.Run("ZCityorganism",ply,hitgroup,dmginfo,rag,armorMul,armorDur,haveHelmet)
        dmginfo:ScaleDamage(0.15)
        else
        dmginfo:ScaleDamage(1)
        hook.Run("ZCityorganism",ply,hitgroup,dmginfo,rag,armorMul,armorDur,haveHelmet)
        dmginfo:ScaleDamage(1)
        end
    end

    hook.Run("ZCityorganism",ply,hitgroup,dmginfo,rag,armorMul,armorDur,haveHelmet)
end)

hook.Add("ZCityorganism","Customorganism",function(ply,hitgroup,dmginfo,rag,armorMul,armorDur,haveHelmet)
    local ent = rag or ply

    ply:SetHealth(ply:Health() - dmginfo:GetDamage())

    local dmgpos = dmginfo:GetDamagePosition()
    local penetration = dmginfo:GetDamageForce()

    local dmg = dmginfo:GetDamage()

    --Neck
    if hitgroup == HITGROUP_HEAD then
        dmginfo:ScaleDamage(3)
        if not haveHelmet and dmginfo:IsDamageType(DMG_BULLET + DMG_BUCKSHOT) then

            ply.organism.pain = ply.organism.pain + 50 * ply.organism.brokenribs + 1
            
            ply:SetDSP(37)

        end
        if
            dmginfo:IsDamageType(DMG_BULLET + DMG_BUCKSHOT + DMG_CLUB + DMG_SLASH) and
            dmginfo:GetDamage() >= 46
        then
            net.Start("TextOnScreen")
            net.WriteString("Your skull was broken.")
            net.Send(ply)
            ent:EmitSound("homigrad/player/neck_snap_01.wav",100,80,1,CHAN_ITEM)
            ply:Kill()

            return
        end
        if
            dmginfo:GetDamageType() == DMG_CRUSH and
            dmginfo:GetDamage() >= 6 and
            ent:GetVelocity():Length() > 450
        then
            net.Start("TextOnScreen")
            net.WriteString("Your neck was broken.")
            net.Send(ply)
            ent:EmitSound("homigrad/player/neck_snap_01.wav",70,100,1,CHAN_ITEM)
            ply:Kill()

            return
        end
    end

    --Legs|Arms
    if dmginfo:GetDamage() >= 30 or (dmginfo:GetDamageType() == DMG_CRUSH and dmginfo:GetDamage() >= 6 and ent:GetVelocity():Length() > 500) then
        local brokenLeftLeg = hitgroup == HITGROUP_LEFTLEG
        local brokenRightLeg = hitgroup == HITGROUP_RIGHTLEG
        local brokenLeftArm = hitgroup == HITGROUP_LEFTARM
        local brokenRightArm = hitgroup == HITGROUP_RIGHTARM

        local sub = dmginfo:GetDamage() / 100 * armorMul

        dmginfo:ScaleDamage(6)

        if brokenLeftArm then
            ply.LeftArm = 0.2
            if ply.msgLeftArm < CurTime() then
                ply.msgLeftArm = CurTime() + 1
                net.Start("TextOnScreen")
                net.WriteString("Your right arm was broken.")
                net.Send(ply)
                ent:EmitSound("homigrad/player/neck_snap_01.wav",70,120,1,CHAN_ITEM)
            end
        end

        if brokenRightArm then
            ply.RightArm = 0.2
            if ply.msgRightArm < CurTime() then
                ply.msgRightArm = CurTime() + 1
                net.Start("TextOnScreen")
                net.WriteString("Your left arm was broken.")
                net.Send(ply)
                ent:EmitSound("homigrad/player/neck_snap_01.wav",70,120,1,CHAN_ITEM)
            end
        end

        if brokenLeftLeg then
            ply.LeftLeg = 0.6
            if ply.msgLeftLeg < CurTime() then
                ply.msgLeftLeg = CurTime() + 1
                net.Start("TextOnScreen")
                net.WriteString("Your left leg was broken.")
                net.Send(ply)
                ent:EmitSound("homigrad/player/neck_snap_01.wav",70,120,1,CHAN_ITEM)
            end
        end

        if brokenRightLeg then
            ply.RightLeg = 0.6
            if ply.msgRightLeg < CurTime() then
                ply.msgRightLeg = CurTime() + 1
                net.Start("TextOnScreen")
                net.WriteString("Your right leg was broken.")
                net.Send(ply)
                ent:EmitSound("homigrad/player/neck_snap_01.wav",70,120,1,CHAN_ITEM)
            end
        end
    end

    --if dmginfo:GetDamageType() != (DMG_BULLET+DMG_BUCKSHOT+DMG_SLASH+DMG_BLAST+DMG_CLUB) then return end

    dmginfo:ScaleDamage(2.3)

    --Heart
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Spine2'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * 1.3 + ang:Right() * 0 + ang:Up() * 0, ang, Vector(-0.2, 0, -0.2), Vector(5, 6, 5))
    
    if huy then
        if ply.organism['heart']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
            ply.organism['heart']=math.max(ply.organism['heart']-dmg,0)
            net.Start("TextOnScreen")
            net.WriteString("You feel a sharp pain in your Heart.")
            net.Send(ply)
        elseif ply.organism['heart']==0 and !dmginfo:IsDamageType(DMG_CLUB) then
            net.Start("TextOnScreen")
            net.WriteString("Your Heart stopped.")
            net.Send(ply)
        end
    end

    --Lungs
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Spine2'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * -4.5, ang, Vector(-0.2, 0, -0.2), Vector(10, 4, 10))
    
    if huy then
        if ply.organism['lungs'] ~= 0 then
            ply.organism['lungs'] = math.max(ply.organism['lungs'] - dmg,0)
            if ply.organism['lungs'] == 0 then
                timer.Simple(3,function()
                    if ply:Alive() then 
                    net.Start("TextOnScreen")
                    net.WriteString("Your Lungs was damaged.")
                    net.Send(ply)
                    end
                end)
            end
        end
    end

    --Ribs
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Spine2'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * -4.5, ang, Vector(-0.2, 0, -0.2), Vector(10, 4, 10))
    
    if huy then
        if ply:Alive() then 
        ply.organism.brokenribs = ply.organism.brokenribs + math.random(1,2)
        net.Start("TextOnScreen")
        net.WriteString(ply.organism.brokenribs.." Ribs was broken.")
        net.Send(ply)
        end
    end

    --Spine
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Spine2'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * -10 + ang:Right() * 2 + ang:Up() * -1, ang, Vector(0, 0, 0), Vector(19, 1, 2))

    if huy then
        net.Start("TextOnScreen")
            net.WriteString("You were hit in the Spine.")
            net.Send(ply)
            if ply.organism['spine']!=0 then
                ply.organism['spine']=math.Clamp(ply.organism['spine']-dmg,0,1)
                if ply.organism['spine']==0 then
                    timer.Simple(0.01,function()
                        if ply:IsPlayer() then
                            Faking(ply)
                        end
                    end)
                    ply.brokenSpine=true 
                    net.Start("TextOnScreen")
                    net.WriteString("Your Spine was broken.")
                    net.Send(ply)
                    ent:EmitSound("homigrad/player/neck_snap_01.wav",70,80,1,CHAN_ITEM)
                end
            end
    end

    --Liver
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Spine2'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * -2 + ang:Right() * 0 + ang:Up() * -4.5, ang, Vector(-0.2, 0, -0.2), Vector(3, 6, 5))

    if huy then
        net.Start("TextOnScreen")
        net.WriteString("You were hit in the Liver.")
        net.Send(ply)
        if ply.organism['liver']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
            ply.organism['liver']=math.max(ply.organism['liver']-dmg,0)
            net.Start("TextOnScreen")
            net.WriteString("Your Liver was destroyed")
            net.Send(ply)
        end
    end

    --Intestines
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Spine'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * -5 + ang:Right() * 0 + ang:Up() * -4.5, ang, Vector(-0.2, 0, -0.2), Vector(9, 7, 10))
    
    if huy then
        net.Start("TextOnScreen")
        net.WriteString("Your were hit in the Intestines.")
        net.Send(ply)
        if ply.organism['intestines']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
            ply.organism['intestines']=math.max(ply.organism['intestines']-dmg,0)
            net.Start("TextOnScreen")
            net.WriteString("Your Intestines were destroyed.")
            net.Send(ply)
        end
    end

    --Stomach
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Spine'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * 2.5 + ang:Right() * -1 + ang:Up() * -4.5, ang, Vector(-0.2, 0, -0.2), Vector(3, 5, 10))
    
    if huy then
        net.Start("TextOnScreen")
        net.WriteString("Your were hit in the Stomach.")
        net.Send(ply)
        if ply.organism['stomach']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
            ply.organism['stomach']=math.max(ply.organism['stomach']-dmg,0)
            net.Start("TextOnScreen")
            net.WriteString("Your Stomach were destroyed.")
            net.Send(ply)
        end
    end

    --Kidney1
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Spine'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * -4 + ang:Right() * 0.5 + ang:Up() * -3.5, ang, Vector(0, 0, 0), Vector(5.5, 2, 3))
    
    if huy then
        net.Start("TextOnScreen")
        net.WriteString("Your were hit in the Kidney.")
        net.Send(ply)
        if ply:IsPlayer() and not ply.Fake then
        Faking(ply)
        end
        if ply.organism['kidney']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
            ply.organism['kidney']=ply.organism['kidney']-1
            net.Start("TextOnScreen")
            net.WriteString("Your Kidney were destroyed.")
            net.Send(ply)
        elseif ply.organism['kidney']==0 and !dmginfo:IsDamageType(DMG_CLUB) then
            ply:Kill()
        end
    end

    --Spleen
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Spine'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * -4 + ang:Right() * 0.5 + ang:Up() * 1, ang, Vector(0, 0, 0), Vector(5.5, 2, 3))
    
    if huy then
        net.Start("TextOnScreen")
        net.WriteString("Your were hit in the Spleen.")
        net.Send(ply)
        if ply.organism['Spleen']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
            ply.organism['Spleen']=math.max(ply.organism['Spleen']-dmg,0)
            net.Start("TextOnScreen")
            net.WriteString("Your Spleen were destroyed.")
            net.Send(ply)
        end
    end

    --Kidney2
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Spine'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * -4 + ang:Right() * 0.5 + ang:Up() * 1, ang, Vector(0, 0, 0), Vector(5.5, 2, 3))
    
    if huy then
        net.Start("TextOnScreen")
        net.WriteString("Your were hit in the Kidney.")
        net.Send(ply)
        if ply:IsPlayer() and not ply.Fake then
        Faking(ply)
        end
        if ply.organism['kidney']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
            ply.organism['kidney']=ply.organism['kidney']-1
            net.Start("TextOnScreen")
            net.WriteString("Your Kidney were destroyed.")
            net.Send(ply)
        elseif ply.organism['kidney']==0 and !dmginfo:IsDamageType(DMG_CLUB) then
            ply:Kill()
        end
    end

    --Brain
    local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Head1'))
    local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * 3 + ang:Right() * 4 + ang:Up() * -2.4, ang, Vector(0, 0, 0), Vector(3, 6, 4.5))

    if huy then
        if ply.organism.brain!=0 and dmginfo:IsDamageType(DMG_BULLET) then
            ply.organism.brain=math.max(ply.organism.brain-dmg,0)
            if ply.organism.brain == 0 then
                net.Start("TextOnScreen")
                net.WriteString("Your Brain was destroyed.")
                net.Send(ply)
                ply:Kill()
                
                return
            end
        end
    end

    if dmginfo:GetDamageType() == (DMG_BULLET+DMG_BUCKSHOT+DMG_SLASH) then
        --Artery1
        local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Head1'))
        local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * -4.5 + ang:Right() * 2 + ang:Up() * -1.5, ang, Vector(0, 0, 0), Vector(4, 1, 1))

        if huy then
            net.Start("TextOnScreen")
            net.WriteString("You were hit in the artery.")
            net.Send(ply)
            if ply.organism['CarotArtery']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
                ply.organism['CarotArtery']=math.max(ply.organism['CarotArtery']-dmg,0)
                net.Start("TextOnScreen")
                net.WriteString("Your artery's been punctured")
                net.Send(ply)
            end
        end

        --Artery2
        local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_Head1'))
        local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * -4.5 + ang:Right() * 2 + ang:Up() * 0.5, ang, Vector(0, 0, 0), Vector(4, 1, 1))

        if huy then
            net.Start("TextOnScreen")
            net.WriteString("You were hit in the artery.")
            net.Send(ply)
            if ply.organism['CarotArtery']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
                ply.organism['CarotArtery']=math.max(ply.organism['CarotArtery']-dmg,0)
                net.Start("TextOnScreen")
                net.WriteString("Your artery's been punctured")
                net.Send(ply)
            end
        end

        --Artery3
        local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_UpperArm'))
        local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * 0, ang, Vector(0, 0, 0), Vector(13, 0.2, 0.2))

        if huy then
            net.Start("TextOnScreen")
            net.WriteString("You were hit in the right arm artery.")
            net.Send(ply)
            if ply.organism['RArtery']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
                ply.organism['RArtery']=math.max(ply.organism['RArtery']-dmg,0)
                net.Start("TextOnScreen")
                net.WriteString("Your right arm artery's been punctured")
                net.Send(ply)
            end
        end

        --Artery4
        local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_ForeArm'))
        local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * 0, ang, Vector(0, 0, 0), Vector(13, 0.2, 0.2))

        if huy then
            net.Start("TextOnScreen")
            net.WriteString("You were hit in the right arm artery.")
            net.Send(ply)
            if ply.organism['RArtery']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
                ply.organism['RArtery']=math.max(ply.organism['RArtery']-dmg,0)
                net.Start("TextOnScreen")
                net.WriteString("Your right arm artery's been punctured")
                net.Send(ply)
            end
        end

        --Artery5
        local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_L_Clavicle'))
        local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * 0, ang, Vector(0, 0, 0), Vector(13, 0.2, 0.2))

        if huy then
            net.Start("TextOnScreen")
            net.WriteString("You were hit in the left arm artery.")
            net.Send(ply)
            if ply.organism['LArtery']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
                ply.organism['LArtery']=math.max(ply.organism['LArtery']-dmg,0)
                net.Start("TextOnScreen")
                net.WriteString("Your left arm artery's been punctured")
                net.Send(ply)
            end
        end

        --Artery6
        local pos,ang = ent:GetBonePosition(ent:LookupBone('ValveBiped.Bip01_R_Clavicle'))
        local huy = util.IntersectRayWithOBB(dmgpos,penetration,pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * 0, ang, Vector(0, 0, 0), Vector(5, 0.2, 0.2))

        if huy then
            net.Start("TextOnScreen")
            net.WriteString("You were hit in the right arm artery.")
            net.Send(ply)
            if ply.organism['RArtery']!=0 and !dmginfo:IsDamageType(DMG_CLUB) then
                ply.organism['RArtery']=math.max(ply.organism['RArtery']-dmg,0)
                net.Start("TextOnScreen")
                net.WriteString("Your right arm artery's been punctured")
                net.Send(ply)
            end
        end
    end
end)
hook.Add("VCityDMG","BurnDamage",function(ply,hitgroup,dmginfo) 
    if dmginfo:IsDamageType( DMG_BURN ) then
        dmginfo:ScaleDamage( 5 )
    end
end)

else

    surface.CreateFont("HomigradFont",{
        font = "Roboto",
        size = 18,
        weight = 1100,
        outline = false
    })
    
    net.Receive("HeadShot", function()
        sound.PlayFile("sound/headshot.wav", "", function(station)
            if IsValid(station) then
                station:SetVolume(2.5)
                station:Play()
            end
        end)
    end)
    
    surface.CreateFont( "MersText1" , {
        font = "Tahoma",
        size = 36,
        weight = 1000,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersText2" , {
        font = "coolvetica",
        size = 46,
        weight = 1000,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersHead1" , {
        font = "coolvetica",
        size = 74,
        weight = 500,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersRadial" , {
        font = "coolvetica",
        size = math.ceil(ScrW() / 34),
        weight = 500,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersRadial_QM" , {
        font = "coolvetica",
        size = math.ceil(ScrW() / 38),
        weight = 500,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersRadialS" , {
        font = "coolvetica",
        size = math.ceil(ScrW() / 45),
        weight = 400,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersRadialSemiSuperS" , {
        font = "coolvetica",
        size = math.ceil(ScrW() / 55),
        weight = 125,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersRadialSuperS" , {
        font = "coolvetica",
        size = math.ceil(ScrW() / 80),
        weight = 100,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersRadialBig" , {
        font = "coolvetica",
        size = math.ceil(ScrW() / 24),
        weight = 500,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersRadialSmall" , {
        font = "coolvetica",
        size = math.ceil(ScrW() / 60),
        weight = 100,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersRadialMedium" , {
        font = "coolvetica",
        size = math.ceil(ScrW() / 42),
        weight = 100,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersRadialSmall_QM" , {
        font = "coolvetica",
        size = math.ceil(ScrW() / 80),
        weight = 100,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont( "MersDeathBig" , {
        font = "coolvetica",
        size = math.ceil(ScrW() / 18),
        weight = 500,
        antialias = true,
        italic = false
    })
    
    surface.CreateFont("HomigradFontBig",{
        font = "Roboto",
        size = 25,
        weight = 1100,
        outline = false,
        shadow = true
    })
    
    surface.CreateFont("HomigradFontInv",{
        font = "Roboto",
        size = 15,
        weight = 1100,
        outline = false,
        shadow = true
    })
    
    surface.CreateFont("HomigradFontInvSmall",{
        font = "Roboto",
        size = 12,
        weight = 1100,
        outline = false,
        shadow = true
    })
    
    surface.CreateFont("HomigradFontInvSmallest",{
        font = "Roboto",
        size = 9,
        weight = 1100,
        outline = false,
        shadow = true
    })
    
    surface.CreateFont("HomigradFontLarge",{
        font = "Roboto",
        size = ScreenScale(30),
        weight = 1100,
        outline = false
    })
    
    surface.CreateFont("HomigradFontSmall",{
        font = "Roboto",
        size = ScreenScale(10),
        weight = 1100,
        outline = false
    })

net.Receive("TextOnScreen", function()
        local text = net.ReadString()
        local displayTime = 4
        local startTime = CurTime()
    
        hook.Add("HUDpaint", "TextScreen", function()
            local elapsedTime = CurTime() - startTime
            if elapsedTime > displayTime then
                hook.Remove("HUDpaint", "TextScreen")
                return
            end
    
            local alpha = 255 * math.Clamp(1 - (elapsedTime / displayTime), 0, 1)
            draw.SimpleText(text, "MersRadialSmall", ScrW() / 2, ScrH() / 1.06, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end)
end)

local debug = false

hook.Add("HUDpaint", "organismDebug", function()
    if not debug then return end
    --Heart
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Spine2")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * 3 + ang:Right() * 0 + ang:Up() * -1, ang, Vector(-0.2, 0, -0.2), Vector(5, 6, 5), Color(255, 0, 0, 255))
    cam.End3D()

    --Lungs
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Spine2")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * -4.5, ang, Vector(-0.2, 0, -0.2), Vector(10, 4, 10), Color(255, 0, 0, 255))
    cam.End3D()

    --Spine
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Spine2")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * -10 + ang:Right() * 2 + ang:Up() * -1, ang, Vector(0, 0, 0), Vector(19, 1, 2), Color(255, 0, 0, 255))
    cam.End3D()

    --Liver
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Spine2")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * -2 + ang:Right() * 0 + ang:Up() * -4.5, ang, Vector(-0.2, 0, -0.2), Vector(3, 6, 5), Color(255, 0, 0, 255))
    cam.End3D()

    --Kidney1
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Spine2")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * -4 + ang:Right() * 0.5 + ang:Up() * -3.5, ang, Vector(0, 0, 0), Vector(5.5, 2, 3), Color(255, 0, 0, 255))
    cam.End3D()

    --Kidney2
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Spine2")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * -4 + ang:Right() * 0.5 + ang:Up() * 1, ang, Vector(0, 0, 0), Vector(5.5, 2, 3), Color(255, 0, 0, 255))
    cam.End3D() 

    --Intestines
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Spine")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * -5 + ang:Right() * 0 + ang:Up() * -4.5, ang, Vector(-0.2, 0, -0.2), Vector(9, 7, 10), Color(255, 0, 0, 255))
    cam.End3D()

    --Stomach
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Spine")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * 2.5 + ang:Right() * -1 + ang:Up() * -4.5, ang, Vector(-0.2, 0, -0.2), Vector(3, 5, 8), Color(255, 0, 0, 255))
    cam.End3D()

    --Spleen
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Spine")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * 3 + ang:Right() * -1 + ang:Up() * 3, ang, Vector(-0.2, 0, -0.2), Vector(4, 5, 2), Color(255, 0, 0, 255))
    cam.End3D()

    --Brain
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Head1")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * 3 + ang:Right() * 4 + ang:Up() * -2.4, ang, Vector(0, 0, 0), Vector(3, 6, 4.5), Color(255, 0, 0, 255))
    cam.End3D()

    --Artery1
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Head1")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * -4.5 + ang:Right() * 2 + ang:Up() * -1.5, ang, Vector(0, 0, 0), Vector(4, 1, 1), Color(255, 0, 0, 255))
    cam.End3D()

    --Artery2
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_Head1")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * -4.5 + ang:Right() * 2 + ang:Up() * 0.5, ang, Vector(0, 0, 0), Vector(4, 1, 1), Color(255, 0, 0, 255))
    cam.End3D()

    --Artery3
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_R_UpperArm")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * 0, ang, Vector(0, 0, 0), Vector(13, 0.2, 0.2), Color(255, 0, 0, 255))
    cam.End3D()

    --Artery4
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_R_ForeArm")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * 0, ang, Vector(0, 0, 0), Vector(13, 0.2, 0.2), Color(255, 0, 0, 255))
    cam.End3D()

    --Artery5
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_L_Clavicle")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * 0, ang, Vector(0, 0, 0), Vector(6, 0.2, 0.2), Color(255, 0, 0, 255))
    cam.End3D()

    --Artery6
    local boneIndex = LocalPlayer():LookupBone("ValveBiped.Bip01_R_Clavicle")
    if not boneIndex then return end

    local pos, ang = LocalPlayer():GetBonePosition(boneIndex)
    if not pos or not ang then return end

    cam.Start3D()
        render.SetMaterial(Material("models/wireframe"))
        render.DrawBox(pos + ang:Forward() * 0 + ang:Right() * 0 + ang:Up() * 0, ang, Vector(0, 0, 0), Vector(5, 0.2, 0.2), Color(255, 0, 0, 255))
    cam.End3D()
end)
end