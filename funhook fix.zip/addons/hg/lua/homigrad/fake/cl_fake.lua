-- "addons\\homigrad\\lua\\homigrad\\fake\\cl_fake.lua"

local lply = LocalPlayer()
local att, ent, oldEntView
follow = follow or nil
local vecZero, vecFull, angZero = Vector(0, 0, 0), Vector(1, 1, 1), Angle(0, 0, 0)
local vecPochtiZero = Vector(0.1, 0.1, 0.1)
local view = {}
local math_Clamp = math.Clamp
local ang
local att_Ang, ot
local angEye = Angle(0, 0, 0)
local firstPerson

local deathLocalAng = Angle(0, 0, 0)

local angle

hook.Add("InputMouseApply", "asdasd2", function(cmd, x, y, angle)
	local tbl = {}

	tbl.cmd = cmd
	tbl.x = x
	tbl.y = y
	tbl.angle = angle

	hook.Run("HG.InputMouseApply", tbl)
	
	cmd = tbl.cmd
	x = tbl.x
	y = tbl.y
	angle = tbl.angle

	if not tbl.override_angle then
		angle.pitch = math.Clamp(angle.pitch + y / 50, -89, 89)
		angle.yaw = angle.yaw - x / 50
	end

	cmd:SetViewAngles(angle)
	
	return true
end)

local turned = false
hook.Add("HG.InputMouseApply", "asdasd2", function(tbl)
	local cmd = tbl.cmd
	local x = tbl.x
	local y = tbl.y
	local angle = tbl.angle

	if not IsValid(LocalPlayer()) or not LocalPlayer():Alive() then return end
	if not IsValid(follow) then
		if turned then
			local ang = LocalPlayer():EyeAngles()
			ang.yaw = ang.yaw + 180
			ang.roll = 0
			cmd:SetViewAngles(ang)
			turned = false
			return true
		end
		return
	end
	
	local att = follow:GetAttachment(follow:LookupAttachment("eyes"))
	if not att or not istable(att) then return end
	local att_Ang = att.Ang

	local attang = LocalPlayer():EyeAngles()
	local view = render.GetViewSetup(true)
	local anglea = view.angles
	local angRad = math.rad(angle[3])
	local newX = x * math.cos(angRad) - y * math.sin(angRad)
	local newY = x * math.sin(angRad) + y * math.cos(angRad)
	--angle.pitch = math.Clamp( angle.pitch + newY / 50, -89, 89 )
	--angle.yaw = angle.yaw - newX / 50

	angle.pitch = math.Clamp(angle.pitch + newY / 50, -180, 180)
	angle.yaw = angle.yaw - newX / 50
	if math.abs(angle.pitch) > 89 then
		turned = not turned
		angle.roll = angle.roll + 180
		angle.yaw = angle.yaw + 180
		angle.pitch = 89 * (angle.pitch / math.abs(angle.pitch))
	end

	if math.abs(math.AngleDifference(angle[1],att_Ang[1])) > 45 then
		--angle[1] = att_Ang[1] - math.Clamp(math.AngleDifference(att_Ang[1],angle[1]),-45,45)
	end

	if math.abs(math.AngleDifference(angle[2],att_Ang[2])) > 45 then
		--angle[2] = att_Ang[2] - math.Clamp(math.AngleDifference(att_Ang[2],angle[2]),-45,45)
	end

	tbl.override_angle = true
	tbl.angle = angle
end)

fakeTimer = fakeTimer or nil
local hg_cshs_fake = ConVarExists("hg_cshs_fake") and GetConVar("hg_cshs_fake") or CreateConVar("hg_cshs_fake", 0, FCVAR_NONE, "fake from cshs", 0, 1)
local hg_firstperson_death = ConVarExists("hg_firstperson_death") and GetConVar("hg_firstperson_death") or CreateConVar("hg_firstperson_death", 0, FCVAR_NONE, "first person death", 0, 1)

local k = 0
local wepPosLerp = Vector(0,0,0)
local CalcView
local angleZero = Angle(0,0,0)

local deathlerp = 0
local tblfollow = {}

CalcView = function(ply, origin, angles, fov, znear, zfar)
	lply = LocalPlayer()

	if not lply:Alive() and follow and ((not fakeTimer or fakeTimer < CurTime()) or lply:KeyPressed(IN_RELOAD)) then
		fakeTimer = nil
		follow = nil
		if IsValid(lply.FakeRagdoll) then
			lply.FakeRagdoll.ply = nil
			lply.FakeRagdoll = nil
		end
		lply:BoneScaleChange()
		return
	end

	if not lply:Alive() and not follow then
		return hook.Run("HG_CalcView", ply, origin, angles, fov, znear, zfar)
	end
	
	--[[if follow and hg.IsChanged(follow,1,tblfollow) then
		if IsValid(tblfollow[1]) then
			print(tblfollow[1])
			tblfollow[1]:ManipulateBoneScale(tblfollow[1]:LookupBone("ValveBiped.Bip01_Head1"),vecFull)
		elseif IsValid(follow) then
			follow:ManipulateBoneScale(follow:LookupBone("ValveBiped.Bip01_Head1"),firstPerson and vecPochtiZero or vecFull)
		end
		tblfollow[1] = follow
		--ply:BoneScaleChange()
	end--]]
	
	if not lply:Alive() and hg.DeathCam and hg.DeathCamAvailable(ply) then return hg.DeathCam(ply,origin,angles,fov,znear,zfar) end

	if not IsValid(ply) then return end
	if not IsValid(follow) then return end
	if not follow:LookupBone("ValveBiped.Bip01_Head1") then return end
	
	view.fov = GetConVar("hg_fov"):GetInt()
	ent = GetViewEntity()
	firstPerson = ent == lply
	if ply:Alive() then
		if not follow:GetManipulateBoneScale(follow:LookupBone("ValveBiped.Bip01_Head1")):IsEqualTol(vecPochtiZero,0.001) then
			follow:ManipulateBoneScale(follow:LookupBone("ValveBiped.Bip01_Head1"), firstPerson and vecPochtiZero or vecFull )
		end
	end
	
	if not firstPerson then return end

	att = follow:GetAttachment(follow:LookupAttachment("eyes"))
	if not att or not istable(att) then return end
	ang = lply:EyeAngles()
	ang:Normalize()
	
	att_Ang = att.Ang
	att_Ang:Normalize()
	
	local _,ot = WorldToLocal(vector_origin,ang,vector_origin,att_Ang)
	ot:Normalize()

	ot[2] = math.Clamp(ot[2], -45, 45)
	ot[1] = math.Clamp(ot[1], -45, 45)
	
	local _,angEye = LocalToWorld(vector_origin,ot,vector_origin,att_Ang)
	angEye:Normalize()
	--att_Ang[1] = angEye[1]
	angEye[3] = ang[3]--ang[3]
	
	if hg_cshs_fake:GetBool() then
		view.angles = att_Ang--angEye
	else
		view.angles = angEye
	end
	
	if ply:Alive() then
		deathLocalAng:Set(view.angles)
	end

	hg.cam_things(ply,view,angleZero)
	
	local pos = hg.eyeTrace(ply, 10, follow).StartPos

	if fakeTimer and fakeTimer > CurTime() then
		
		if hg_firstperson_death:GetBool() then
			deathlerp = LerpFT(0.05,deathlerp,1)
			local angdeath = LerpAngle(deathlerp,deathLocalAng,att_Ang)

			view.origin = pos
			view.angles = angdeath
		else
			if follow:GetManipulateBoneScale(follow:LookupBone("ValveBiped.Bip01_Head1")):IsEqualTol(vecPochtiZero,0.001) then
				follow:ManipulateBoneScale(follow:LookupBone("ValveBiped.Bip01_Head1"),vecFull)
			end

			local ang = ply:EyeAngles()
			local tr = {}
			tr.start = pos
			tr.endpos = pos - ang:Forward() * 60
			tr.filter = {ply,follow}
			tr.mask = MASK_SOLID

			view.origin = util.TraceLine(tr).HitPos + ang:Forward() * 5
			view.angles = ang
		end
	else
		view.origin = pos
	end

	view.angles:Add(ply:GetViewPunchAngles())
	view.origin, view.angles = HGAddView(lply, view.origin, view.angles)
	view.znear = 1

	view = hook.Run("Camera", ply, vector_origin, view.angles, view, vector_origin) or view

	local wep = ply:GetActiveWeapon()
	k = Lerp(0.1,k,ply:KeyDown(IN_JUMP) and 1 or 0)
	if wep.GetMuzzleAtt then
		wep:WorldModel_Transform()
		wep:DrawAttachments()
	end
	
	return view
end

hook.Add("CalcView", "zzFake", CalcView)

local render_RenderView = render.RenderView
local renderView = {
	x = 0,
	y = 0,
	drawhud = true,
	drawviewmodel = true,
	dopostprocess = true,
	drawmonitors = true,
	fov = 100
}

hook.Add("RenderScene", "jopa2", function(pos, angle, fov)
	if true then return end
	RENDERSCENE = true
	local view = CalcView(lply, pos, angle, fov)
	RENDERSCENE = nil
	if not view then return end
	renderView.w = ScrW()
	renderView.h = ScrH()
	renderView.fov = fov
	renderView.origin = view.origin
	renderView.angles = view.angle
	pcall(render_RenderView,renderView)
	return true
end)

local MAX_EDICT_BITS = 13

function net.ReadEntity2()

	local i = net.ReadUInt( MAX_EDICT_BITS )
	if ( !i ) then return end

	return Entity( i ), i

end

--hook.Add("EntityNetworkedVarChanged","huhuhuasd",function()
	
--end)

local hook_Run = hook.Run
local indexes = {}
net.Receive("Player Ragdoll", function()
	--local ply, ragdoll_index = net.ReadEntity(), net.ReadInt(32) --,net_ReadTable()
	local ply, ragdoll, ragdoll_index = net.ReadEntity(), net.ReadEntity2() --,net_ReadTable()
	if not ragdoll_index then return end
	local ragdoll = IsValid(ragdoll) and ragdoll
	
	if IsValid(ragdoll) or ragdoll_index == 0 or ragdoll_index == -1 then
		--hook.Run("RagdollEntityCreated",ply, ragdoll, ragdoll_index)
	else
		ply.ragdoll_index = ragdoll_index
	end
end)

hook.Add("Player Think","find_ragdoll",function(ply)
	if not ply.ragdoll_index then return end
	local ragdoll = Entity(ply.ragdoll_index)
	if IsValid(ragdoll) or ply.ragdoll_index == 0 or ply.ragdoll_index == -1 then
		--hook.Run("RagdollEntityCreated",ply,ragdoll)
		ply.ragdoll_index = nil
	end
end)

local getuptimer = 0.5

hook.Add("RagdollEntityCreated", "RagdollFinder", function(ply, ent)
	if not IsValid(ply) then return end
	
	local oldrag = ply.FakeRagdoll

	ply.FakeRagdoll = ent
	--ply:SetNWEntity("FakeRagdoll", ent)
	--if not IsValid(oldrag) then oldrag = ent end
	hook.Run("ServerRagdollTransferDecals", ply, ent)

	lply = LocalPlayer()

	local ragdoll = ply.FakeRagdoll
	
	ragdoll = IsValid(ragdoll) and ragdoll
	
	if lply == ply then
		local ang = lply:EyeAngles()
		ang[3] = 0
		lply:SetEyeAngles(ang)
	end
	
	if ply == lply then
		follow = ragdoll

		if follow and hg.IsChanged(follow,1,tblfollow) then
			if IsValid(tblfollow[1]) then
				tblfollow[1]:ManipulateBoneScale(tblfollow[1]:LookupBone("ValveBiped.Bip01_Head1"),vecFull)
			elseif IsValid(follow) and not follow:GetManipulateBoneScale(follow:LookupBone("ValveBiped.Bip01_Head1")):IsEqualTol(vecPochtiZero,0.001) then
				follow:ManipulateBoneScale(follow:LookupBone("ValveBiped.Bip01_Head1"),vecPochtiZero)
			end

			tblfollow[1] = follow
			--ply:BoneScaleChange()
		end
	end

	if ragdoll then
		--ragdoll:SetPredictable(true)--causes ragdoll to shake bruh lol
		ragdoll.ply = ply

		ragdoll.organism = ply.organism
		
		local hull = Vector(10,10,10)
		--[[if IsValid(ply) then
			ply:SetHull(-hull,hull)
			ply:SetHullDuck(-hull,hull)
			ply:SetViewOffset(Vector(0,0,0))
			ply:SetViewOffsetDucked(Vector(0,0,0))
		end--]]

		ragdoll:CallOnRemove("RagdollRemove",function()
			hook.Run("RagdollRemove",ply,ragdoll)
		end)

		ply.FakeRagdoll = ragdoll

		ragdoll.RenderOverride = function(self)
			self:SetupBones()
			local ply = (IsValid(ply) and ply:IsPlayer() and ply:Alive() and hg.GetCurrentCharacter(ply) == self) and ply or self
			hook.Run("PreDrawPlayerRagdoll",self,ply)
			hook.Run("DrawPlayerRagdoll",self,ply)
			hook.Run("PostDrawPlayerRagdoll",self,ply)
			self:DrawModel()
			hook.Run("DrawAppearance",self,ply)
		end
		hook_Run("Fake", ply, ragdoll)
	else
		--if IsValid(oldrag) then ply:SetRenderMode(RENDERMODE_NONE) end
		if IsValid(ply) then ply:SetNoDraw(false) end
		ply:SetRenderMode(RENDERMODE_NORMAL)
		
		--[[if ((ply ~= lply) or not ply.matrixes) and ply.ragdoll_index ~= -1 then
			if IsValid(oldrag) then
				local matrixes = {}
				for bon = 0,oldrag:GetBoneCount() do
					local mat = oldrag:GetBoneMatrix(bon)
					if not bon then continue end
					matrixes[bon] = mat
				end
				ply.matrixes = matrixes
			end
		end--]]
		ply.FakeRagdollOld = oldrag
		ply.getuptime = CurTime() + getuptimer
		ply.FakeRagdoll = nil
		hook_Run("FakeUp", ply, ragdoll)
	end
	
	if IsValid(ply) and ply.BoneScaleChange then ply:BoneScaleChange() end

	ply.ragdollindex = nil
end)

concommand.Add("fake", function(ply)
	if not ply:Alive() then return end
	net.Start("fake")
	net.SendToServer()
	local oldrag = ply.FakeRagdoll
	if not IsValid(oldrag) then return end
	--[[local matrixes = {}
	for bon = 0,oldrag:GetBoneCount() do
		local mat = oldrag:GetBoneMatrix(bon)
		if not bon then continue end
		matrixes[bon] = mat
	end
	ply.matrixes = matrixes--]]
	ply.FakeRagdollOld = oldrag
end)

local vec1 = Vector(1,1,1)
local vec2 = Vector(0.1,0.1,0.1)
hook.Add("PreDrawPlayerRagdoll", "ragdollprikol", function(ent, ply)
	if not (ent == ply and ply:IsPlayer()) then
        ply.lastmatrixes = nil
        ply.getuptime = nil
        ply.headmat = nil
        ply.FakeRagdollOld = nil
        return
    end
	
    if not ply.getuptime then
        ply.headmat = nil
        return
    end

    local lerping = math.ease.OutSine(math.Clamp(1 - (ply.getuptime - CurTime() + 1) / getuptimer, 0, 1))
	
    if lerping == 1 then
        ply.lastmatrixes = nil
        ply.getuptime = nil
        ply.headmat = nil
        ply.FakeRagdollOld = nil
		ply:SetNoDraw(false)
		ply:SetRenderMode(RENDERMODE_NORMAL)
		ply:DrawShadow(true)
        return
    end
	
    ply.lastmatrixes = ply.lastmatrixes or {}

	if IsValid(ply.FakeRagdollOld) then
		ply.FakeRagdollOld:SetupBones()
		ply:DrawShadow(false)
	end

    for bon = 0, ply:GetBoneCount() - 1 do
        local newmat = ply:GetBoneMatrix(bon)
        local mat = IsValid(ply.FakeRagdollOld) and ply.FakeRagdollOld:GetBoneMatrix(bon) or ply.lastmatrixes[bon]
        ply.lastmatrixes[bon] = mat
		
        if not bon or not newmat or not mat then continue end

        local lerpedmat = mat + (newmat - mat) * Matrix({
            {lerping, 0, 0, 0},
            {0, lerping, 0, 0},
            {0, 0, lerping, 0},
            {0, 0, 0, lerping},
        })

        if not (ply == GetViewEntity() and bon == ply:LookupBone("ValveBiped.Bip01_Head1")) then
            lerpedmat:SetScale(vec1)
        else
            lerpedmat:SetScale(vec2)
        end

        if bon == ply:LookupBone("ValveBiped.Bip01_Head1") then
            ply.headmat = lerpedmat
        end

        ply:SetBoneMatrix(bon, lerpedmat)
    end
end)

hook.Add("DrawPlayerRagdoll","ragdollprikol2",function(ent,ply)
	--[[if ent~=ply then
		ply:SetupBones()
		local mat = ply:GetBoneMatrix(0)
		--mat:SetAngles(ent:GetBoneMatrix(0):GetAngles())
		hg.bone_apply_matrix(ent,0,mat)
	end--]]
end)

local vec123 = Vector(0,0,0)
local entityMeta = FindMetaTable("Entity")

function entityMeta:GetPlayerColor()
	return self:GetNWVector("PlayerColor",vec123)
end

function entityMeta:GetPlayerName()
	return self:GetNWString("PlayerName","")
end

local playerMeta = FindMetaTable("Player")

function playerMeta:GetPlayerViewEntity()
	return (IsValid(self:GetNWEntity("spect")) and self:GetNWEntity("spect")) or (IsValid(self.FakeRagdoll) and self.FakeRagdoll) or self
end

function playerMeta:GetPlayerName()
	return self:GetNWString("PlayerName","")
end

function playerMeta:IsFirstPerson()
	if IsValid(self:GetNWEntity("spect",NULL)) then
		return self:GetNWInt("viewmode",viewmode or 1) == 1
	else
		return (GetViewEntity() == self)
	end
end

local ents_FindByClass = ents.FindByClass
local player_GetAll = player.GetAll
function playerMeta:BoneScaleChange()
	local firstPerson = LocalPlayer():IsFirstPerson()
	local viewEnt = LocalPlayer():GetPlayerViewEntity()
	
	for i,ent in ipairs(ents_FindByClass("prop_ragdoll")) do
		if not ent:LookupBone("ValveBiped.Bip01_Head1") then continue end
		if ent:GetManipulateBoneScale(ent:LookupBone("ValveBiped.Bip01_Head1")) == vecZero then continue end
		--if not hg.RagdollOwner(ent) then continue end
		if ent == viewEnt then
			ent:ManipulateBoneScale(ent:LookupBone("ValveBiped.Bip01_Head1"),firstPerson and vecPochtiZero or vecFull)
		else
			ent:ManipulateBoneScale(ent:LookupBone("ValveBiped.Bip01_Head1"),vecFull)
		end
	end

	for i,ent in ipairs(player_GetAll()) do
		if not ent:LookupBone("ValveBiped.Bip01_Head1") then continue end
		if ent:GetManipulateBoneScale(ent:LookupBone("ValveBiped.Bip01_Head1")) == vecZero then continue end
		if ent == viewEnt then
			ent:ManipulateBoneScale(ent:LookupBone("ValveBiped.Bip01_Head1"),firstPerson and vecPochtiZero or vecFull)
		else
			ent:ManipulateBoneScale(ent:LookupBone("ValveBiped.Bip01_Head1"),vecFull)
		end
	end
end

hook.Add("PostCleanupMap","wtfdude",function()
	LocalPlayer():BoneScaleChange()
end)

hook.Add("Player Getup", "Fake", function(ply)
	if ply == lply then
		--if IsValid(follow) and (follow:GetManipulateBoneScale() == vecPochtiZero) then follow:ManipulateBoneScale(follow:LookupBone("ValveBiped.Bip01_Head1"), vecFull) end
		follow = nil
		fakeTimer = nil

		timer.Simple(0.1 * math.max(ply:Ping() / 50,1),function()
			--ply:BoneScaleChange()
		end)
	end
	
	ply:SetNWVarProxy("FakeRagdoll", function(ply, name, oldval, ragdoll)
		if ply.onetime then return end
		ply.onetime = true
		hook.Run("RagdollEntityCreated", ply, ragdoll)
		ply.onetime = false
	end)

	if IsValid(ply.FakeRagdoll) then
		ply.FakeRagdoll.ply = nil
		ply.FakeRagdoll = nil
	end
end)

function hg.RagdollOwner(ragdoll)
	if not IsValid(ragdoll) then return end
	local ply = ragdoll:GetNWEntity("ply")
	return IsValid(ply) and ply:GetNWEntity("FakeRagdoll") == ragdoll and ply
end

hook.Add("Player Death", "Fake", function(ply)	
	hook_Run("FakeDeath", ply, ply.FakeRagdoll)
	
	if ply != lply then return end
	
	fakeTimer = CurTime() + 4

	hg.override[ply] = nil

	timer.Simple(0.5 * math.max(ply:Ping() / 30,1),function()
		ply:BoneScaleChange()
	end)
end)

local left = Material("vgui/gradient-l")
local white2 = Color(150, 150, 150)
local w, h
local math_Clamp = math.Clamp
local math_max, math_min = math.max, math.min
local k1, k2, k3, k4
local hg_show_hitposragdolleyes = ConVarExists("hg_show_hitposragdolleyes") and GetConVar("hg_show_hitposragdolleyes") or CreateClientConVar("hg_show_hitposragdolleyes", "0", false, false, "enables crosshair in ragdoll, only for admins")
local sv_cheats = GetConVar("sv_cheats")
local tr = {
	filter = {lply}
}

local util_TraceLine = util.TraceLine
local vecUp = Vector(1, 0, 0)
hook.Add("RenderScreenspaceEffects", "gg", function()
	if IsValid(follow) and hg_show_hitposragdolleyes:GetBool() and (sv_cheats:GetBool() or lply:IsAdmin() or lply:IsSuperAdmin()) then
		local att = follow:GetAttachment(follow:LookupAttachment("eyes"))
		tr.start = att.Pos
		local dir = vecZero
		dir:Set(vecUp)
		dir:Rotate(lply:EyeAngles())
		tr.endpos = att.Pos + dir * 8000
		tr.filter[2] = follow
		local pos = util_TraceLine(tr).HitPos:ToScreen()
		draw.RoundedBox(0, pos.x - 2, pos.y - 2, 4, 4, white2)
	end

	if not firstPerson or not IsValid(follow) then return end
	if true then return end
	ot = angEye - lply:EyeAngles()
	ot:Normalize()
	k1 = math_Clamp(ot[2] / -30, 0, 1)
	k2 = math_Clamp(ot[2] / 30, 0, 1)
	k1 = math_min(math_max(k1 - 0.2, 0) / 0.8 * 2, 1)
	k2 = math_min(math_max(k2 - 0.2, 0) / 0.8 * 2, 1)
	k3 = math_Clamp(ot[1] / 30, 0, 1)
	k4 = math_Clamp(ot[1] / -30, 0, 1)
	k3 = math_min(math_max(k3 - 0.2, 0) / 0.8 * 2, 1)
	k4 = math_min(math_max(k4 - 0.2, 0) / 0.8 * 2, 1)
	w, h = ScrW(), ScrH()
	--[[white.a = (k1 + k2) * 128
	s = h / 2 * (k1 + k2)

	draw.RoundedBox(s,w / 2 + k1 * -w / 2 + k2 * w / 2 - s / 2,h / 2 - s / 2,s,s,white)]]
	--
	surface.SetMaterial(left)
	surface.SetDrawColor(0, 0, 0, 255 * k1)
	surface.DrawTexturedRect(0, 0, w * 0.5, h)
	surface.SetDrawColor(0, 0, 0, 255 * k2)
	surface.DrawTexturedRectRotated(w - w * 0.5 / 2 + 1, h * 0.5, w * 0.5, h, 180)
	surface.SetDrawColor(0, 0, 0, 255 * k3)
	surface.DrawTexturedRectRotated(w * 0.5, h * 0.25 - 1, w * 0.5, h * 2, -90)
	surface.SetDrawColor(0, 0, 0, 255 * k4)
	surface.DrawTexturedRectRotated(w * 0.5, h * 0.75 + 1, w * 0.5, h * 2, 90)
end)

function hg.GetCurrentCharacter(ply)
	if not IsValid(ply) then return end
	local rag = ply:GetNWEntity("FakeRagdoll", NULL)
	ply.FakeRagdoll = rag
	rag = IsValid(rag) and rag

	return (IsValid(rag) and rag) or ply
end

hook.Add("Player Spawn", "fuckingremoveragdoll", function(ply)
	local ragdoll = ply:GetNWEntity("FakeRagdoll")
	
	if IsValid(ragdoll) then
		ragdoll:SetNWEntity("ply", NULL)
	end
	--FUCKING SHIT
	if IsValid(ply.FakeRagdoll) then
		ply.FakeRagdoll.ply = nil
		ply.FakeRagdoll = nil
	end
	
	ply:SetNWEntity("FakeRagdoll",NULL)
end)

local override = {}
hg.override = override
net.Receive("Override Spawn", function() override[net.ReadEntity()] = true end)
hook.Add("Player Spawn", "!Override", function(ply)
	if override[ply] then
		override[ply] = nil
		return false
	end
end)

hook.Add("Player Spawn", "zOverride", function(ply)
	if override[ply] then
		override[ply] = nil
		return false
	end
end)

hook.Add("PlayerFootstep", "CustomFootstep", function(ply) if IsValid(ply.FakeRagdoll) then return true end end)

hook.Add("ServerRagdollTransferDecals","raghuy", function(ent,rag)
    if IsValid(ent) && IsValid(rag) && !rag.DecalTransferDone then
        rag:SnatchModelInstance( ent )
        rag.DecalTransferDone = true
    end
end)


hook.Add("OnEntityCreated", "TryCopyAppearanceNow", function( ent )
	--if not ent:IsRagdoll() then return end
	--for k,ply in ipairs(ents.FindInSphere(ent:GetPos(),15)) do
	--	if ply:IsPlayer() then
	--		ent:SetPlayerColor(ply:GetPlayerColor())
	--		local copy = duplicator.CopyEntTable(ply)
	--		duplicator.DoGeneric(ent,copy)
--
	--		ent:SetNWString("PlayerName",ply:Name())
	--		--ent:SetNWVector("PlayerColor",ply:GetPlayerColor())
	--		ent:SetNetVar("Armor", ply:GetNetVar("Armor",{}))
	--		ent:SetNetVar("Accessories", ply:GetNetVar("Accessories","none"))
	--	end
	--end
end)