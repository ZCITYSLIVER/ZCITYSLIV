-- "addons\\homigrad\\lua\\homigrad\\cl_comunication.lua"

// v7 privet

hook.Add( "OnPlayerChat", "HelloCommand", function( ply, strText, bTeam, bDead ) 
	if ( ply:Alive() ) then -- if the player typed /hello then
		chat.AddText( ply:GetPlayerColor():ToColor(), ply:GetPlayerName(), color_white, ": "..strText ) -- print Hello world to the console
		return true -- this suppresses the message from being shown
	end
end )