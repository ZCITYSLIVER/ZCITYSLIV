-- "addons\\homigrad\\lua\\homigrad\\cl_hud.lua"

hide = {
	["CHudHealth"] = true,
	["CHudBattery"] = true,
	["CHudAmmo"] = false,
	["CHudSecondaryAmmo"] = true,
	["CHudCrosshair"] = true
}

hook.Add("HUDShouldDraw", "homigrad", function(name) if hide[name] then return false end end)
hook.Add("HUDDrawTargetID", "homigrad", function() return false end)
hook.Add("DrawDeathNotice", "homigrad", function() return false end)
surface.CreateFont("HomigradFont", {
	font = "Bahnschrift",
	size = ScreenScale(10),
	weight = 1100,
	outline = false
})

surface.CreateFont("ScoreboardPlayer", {
	font = "Bahnschrift",
	size = ScreenScale(7),
	weight = 1100,
	outline = false
})

surface.CreateFont("HomigradFontBig", {
	font = "Bahnschrift",
	size = ScreenScale(12),
	weight = 1100,
	outline = false,
	shadow = true
})

surface.CreateFont("HomigradFontMedium", {
	font = "Bahnschrift",
	size = ScreenScale(8),
	weight = 1100,
	outline = false,
})

surface.CreateFont("HomigradFontLarge", {
	font = "Bahnschrift",
	size = ScreenScale(15),
	weight = 1100,
	outline = false
})

surface.CreateFont("HomigradFontGigantoNormous", {
	font = "Bahnschrift",
	size = ScreenScale(25),
	weight = 1100,
	outline = false,
	shadow = false
})

surface.CreateFont("HomigradFontSmall", {
	font = "Bahnschrift",
	size = 17,
	weight = 1100,
	outline = false
})

local w, h
local lply = LocalPlayer()
hook.Add("HUDPaint", "homigrad-dev", function()
	if engine.ActiveGamemode() ~= "zbattle" then return end
	w, h = ScrW(), ScrH()

	--draw.SimpleText(LocalPlayer():Health(),"CloseCaption_BoldItalic",0,ScrH() / 1.05)
end)

--draw.SimpleText(lply:Health(),"HomigradFontBig",100,h - 50,white,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
function draw.CirclePart(x, y, radius, seg, parts, pos)
	local cir = {}
	table.insert(cir, {
		x = x,
		y = y,
		u = 0.5,
		v = 0.5
	})

	for i = 0, seg do
		local a = math.rad((i / seg) * -360 / parts - pos * 360 / parts)
		table.insert(cir, {
			x = x + math.sin(a) * radius,
			y = y + math.cos(a) * radius,
			u = math.sin(a) / 2 + 0.5,
			v = math.cos(a) / 2 + 0.5
		})
		--draw.DrawText("asd","HomigradFontBig",x + math.sin(a) * radius,y + math.cos(a) * radius)
	end

	--local a = math.rad(0)
	--table.insert(cir, {x = x + math.sin(a) * radius, y = y + math.cos(a) * radius, u = math.sin(a) / 2 + 0.5, v = math.cos(a) / 2 + 0.5})
	render.PushFilterMin(TEXFILTER.ANISOTROPIC)
	surface.DrawPoly(cir)
	render.PopFilterMin()
end

if IsValid(MENUPANELHUYHUY) then
	MENUPANELHUYHUY:Remove()
	MENUPANELHUYHUY = nil
end

hg.radialOptions = hg.radialOptions or {}
local colBlack = Color(0, 0, 0, 152)
local colWhite = Color(255, 255, 255, 255)
local colWhiteTransparent = Color(176, 40, 40, 100)
local colTransparent = Color(0, 0, 0, 0)
local matHuy = Material("vgui/white")
local vecXY = Vector(0, 0)
local vecDown = Vector(0, 1)
local isMouseIntersecting = false
local isMouseOnRadial = false
local current_option = 1
local current_option_select = 1
local hook_Run = hook.Run
local function dropWeapon()
	RunConsoleCommand("say", "*drop")
end

hook.Add("radialOptions", "!Main", function()
	local organism = LocalPlayer().organism or {}
	if not organism.otrub and IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_hands_sh" then
		local tbl = {dropWeapon, "Drop Weapon"}
		hg.radialOptions[#hg.radialOptions + 1] = tbl
	end
end)

local incoentCol = Color(128,0,0)
local taitorCol = Color(155,0,0)

local menuPanel

local function CreateRadialMenu()
	local sizeX, sizeY = ScrW(), ScrH()
	hg.radialOptions = {}
	hook_Run("radialOptions")
	local options = hg.radialOptions
	if IsValid(MENUPANELHUYHUY) then
		MENUPANELHUYHUY:Remove()
		MENUPANELHUYHUY = nil
	end

	MENUPANELHUYHUY = vgui.Create("DPanel")
	menuPanel = MENUPANELHUYHUY
	menuPanel:SetPos(ScrW() / 2 - sizeX / 2, ScrH() / 2 - sizeY / 2)
	menuPanel:SetSize(sizeX, sizeY)
	menuPanel:MakePopup()
	menuPanel:SetKeyBoardInputEnabled(false)
	menuPanel:SetAlpha(0)
	menuPanel:AlphaTo(255,0.2)
	input.SetCursorPos(sizeX / 2, sizeY / 2)

	function menuPanel:Close()
		menuPanel:AlphaTo(0,0.1,0,function()
			menuPanel:Remove()
			menuPanel = nil
		end)
	end

	menuPanel.Paint = function(self, w, h)
		local x, y = input.GetCursorPos()
		x = x - sizeX / 2
		y = y - sizeY / 2
		vecXY.x = x
		vecXY.y = y
		local deg = (vecXY:GetNormalized() - vecDown):Angle()
		deg = (deg[2] - 180) * 2
		for num, option in ipairs(options) do
			local num = num - 1
			local r = ScrH()*0.45
			local partDeg = 360 / #options
			local sqrt = math.sqrt(x ^ 2 + y ^ 2)
			isMouseOnRadial = sqrt <= r and sqrt > 4
			isMouseIntersecting = isMouseOnRadial and deg > num * partDeg and deg < (num + 1) * partDeg
			if isMouseIntersecting then current_option = num + 1 end
			if option[3] then
				surface.SetMaterial(matHuy)
				surface.SetDrawColor(isMouseIntersecting and colBlack or colBlack)
				draw.CirclePart(w / 2, h / 2, r, 40, #options, num)
				local count = #option[4]
				
				local selectedPart = count - (math.floor((r - sqrt) / (r / count)))
				
				current_option_select = selectedPart
				for i, opt in pairs(option[4]) do
					local selected = selectedPart == i
					surface.SetMaterial(matHuy)
					surface.SetDrawColor((selected and isMouseIntersecting) and colWhiteTransparent or colTransparent)
					draw.CirclePart(w / 2, h / 2, r * (i / count), 40, #options, num)
					local a = -partDeg * num - partDeg / 2
					a = math.rad(a)
					draw.DrawText(opt, "HomigradFontBig", ScrW() / 2 + math.sin(a) * r/1.4 * (i / count), ScrH() / 2 + math.cos(a) * r/1.4 * (i / count), colWhite, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end

				continue
			end

			surface.SetMaterial(matHuy)	
			surface.SetDrawColor(isMouseIntersecting and colWhiteTransparent or colBlack)
			draw.CirclePart(w / 2, h / 2, r, 30, #options, num)
			local a = -partDeg * num - partDeg / 2
			a = math.rad(a)
			draw.DrawText(option[2], "HomigradFontBig", ScrW() / 2 + math.sin(a) * r / 1.5, ScrH() / 2 + math.cos(a) * r / 1.5, colWhite, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			local col = Color(0,0,0)
			draw.SimpleText(LocalPlayer():GetPlayerName(),"HomigradFontGigantoNormous",ScrW() * 0.0215,ScrH() * 0.042, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText( ( (LocalPlayer().role and LocalPlayer().role.name) or ""),"HomigradFontGigantoNormous" ,ScrW() * 0.0215,ScrH() * 0.098, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

			local col = LocalPlayer():GetPlayerColor():ToColor()
			draw.SimpleText(LocalPlayer():GetPlayerName(),"HomigradFontGigantoNormous",ScrW() * 0.02,ScrH() * 0.04, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText( ( (LocalPlayer().role and LocalPlayer().role.name) or ""),"HomigradFontGigantoNormous" ,ScrW() * 0.02,ScrH() * 0.095, LocalPlayer().role and LocalPlayer().role.color or incoentCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
end

local function PressRadialMenu()
	local options = hg.radialOptions
	--print(options[current_option][1])

	hook_Run("RadialMenuPressed")

	if IsValid(menuPanel) and options[current_option] and isMouseOnRadial then
		local func = options[current_option][1]
		if isfunction(func) then func(current_option_select) end
	end

	if IsValid(menuPanel) then
		menuPanel:Close()
	end
end

local firstTime = true
local firstTime2 = true
local firstTime3 = true
local firstTime4 = true

hook.Add( "PlayerBindPress", "PlayerBindPressExample2huy", function( ply, bind, pressed )
	if string.find(bind, "+menu_context") then

		if (bind == "+menu_context") then
			if pressed then
				CreateRadialMenu()
			else
				PressRadialMenu()
			end
		else
			if LocalPlayer():IsAdmin() then return end
		end

		return true
	end
end)

hook.Add("Think", "hg-radial-menu", function()
	if not LocalPlayer():Alive() then return end

	if (engine.ActiveGamemode() ~= "zbattle" and input.IsKeyDown(KEY_Q)) or (engine.ActiveGamemode() == "zbattle" and input.IsKeyDown(KEY_C)) then
		if firstTime then
			firstTime = false
			--CreateRadialMenu()
		end

		firstTime4 = true
	else
		if firstTime4 then
			firstTime4 = false
			--PressRadialMenu()
		end

		firstTime = true
	end

	if input.IsMouseDown(MOUSE_LEFT) then
		if firstTime2 then
			firstTime2 = false
			--print("pressed")
		end

		firstTime3 = true
	else
		if firstTime3 then
			firstTime3 = false
			--print("released")
			PressRadialMenu()
		end

		firstTime2 = true
	end
end)

local list = {{"arteria", 1, true}, {"bleed", 200, true}, {"hurt", 1, true}, {"brain", 0.25, true}, {"skull", 0.25, true}, {"jaw", 0.5, true}, {"spine1", 1, true}, {"spine2", 1, true}, {"spine3", 1, true}, {"chest", 1, true}, {"pelvis", 1, true}, {"heart", 0.25, true}, {"stomach", 1, true}, {"intestines", 1, true}, {"trachea", 0.5, true}, {"lleg", 2, true}, {"rleg", 2, true}, {"larm", 2, true}, {"rarm", 2, true}}
local function getEye()
	local lply = LocalPlayer()
	local att = lply:LookupAttachment("eyes")
	if not att then return lply:GetEyeTrace() end
	att = lply:GetAttachment(att)
	local tr = {}
	tr.start = att.Pos
	tr.endpos = att.Pos + lply:GetAimVector() * 75
	tr.filter = {lply}
	return util.TraceLine(tr)
end

local wound4Bones = {
	["ValveBiped.Bip01_Head1"] = "головы",
	["ValveBiped.Bip01_L_UpperArm"] = "левого плеча",
	["ValveBiped.Bip01_L_Forearm"] = "Левого предплечья",
	["ValveBiped.Bip01_L_Hand"] = "Левой кисти",
	["ValveBiped.Bip01_R_UpperArm"] = "Правого плеча",
	["ValveBiped.Bip01_R_Forearm"] = "Правого предплечья",
	["ValveBiped.Bip01_R_Hand"] = "Правой руки",
	["ValveBiped.Bip01_Pelvis"] = "живота",
	["ValveBiped.Bip01_Spine2"] = "груди",
	["ValveBiped.Bip01_L_Thigh"] = "левого бедра",
	["ValveBiped.Bip01_L_Calf"] = "левой голени",
	["ValveBiped.Bip01_L_Foot"] = "левой ступни",
	["ValveBiped.Bip01_R_Thigh"] = "правого бедро",
	["ValveBiped.Bip01_R_Calf"] = "правой голени",
	["ValveBiped.Bip01_R_Foot"] = "правой ступни"
}

local bleeds, ent, org, entr
local infoTime = 0
net.Receive("receive_org", function()
	ent = net.ReadEntity()
	entr = net.ReadEntity()
	bleeds = net.ReadTable()
	org = net.ReadTable()
	infoTime = CurTime()
end)

local font_size = 50
surface.CreateFont("HG_font", {
	font = "Arial",
	extended = false,
	size = font_size,
	weight = 500,
	outline = true
})

local severityList = {
	[1] = "Незначительное",
	[2] = "Незначительное",
	[3] = "Малое",
	[4] = "Малое",
	[5] = "Малое",
	[6] = "Среднее",
	[7] = "Среднее",
	[8] = "Среднее",
	[9] = "Обильное",
	[10] = "Обильное",
}

local stateList = {
	[0] = "Нормальное",
	[1] = "Малые ранения",
	[2] = "Малые ранения",
	[3] = "Средние ранения",
	[4] = "Средние ранения",
	[5] = "Средние ранения",
	[6] = "Обильные ранения",
	[7] = "Обильные ранения",
	[8] = "Критическое",
	[9] = "Критическое",
	[10] = "Критическое"
}

local paint = Color(0, 0, 0, 0)
local CurTime = CurTime
local gradient = Material("homigrad/vgui/gradient_left.png")
local enta

local vector_one = Vector( 1, 1, 1 )

local function CopyRight( text, font, x, y, color, ang, scale )
	--render.PushFilterMag( TEXFILTER.ANISOTROPIC )
	--render.PushFilterMin( TEXFILTER.ANISOTROPIC )

	local m = Matrix()
	m:Translate( Vector( x, y, 0 ) )
	m:Rotate( Angle( 0, ang, 0 ) )
	m:Scale( vector_one * ( scale or 1 ) )

	surface.SetFont( font )
	local w, h = surface.GetTextSize( text )

	m:Translate( Vector( -(w / 2)-25, -h / 2, 0 ) )

	cam.PushModelMatrix( m, true )
		draw.RoundedBox(5,0,2,w+52,h+2,Color(0,0,0))
		draw.RoundedBox(5,0,2,w+50,h,Color(255,0,0))
		draw.DrawText( text, font, 25, 0, color )	
	cam.PopModelMatrix()

	--render.PopFilterMag()
	--render.PopFilterMin()
end

--hook.Add("HUDPaint","homigrad-copyright",function()
	--local i = 1
	--CopyRight("ЖДИ ДОКС ЖДИ СВАТ","HomigradFontBig",ScrW()/2 +(math.cos(CurTime()*1)*15*i),ScrH()/2+(math.sin(CurTime()*1)*55*i)+15,Color(255,255,255),math.cos(CurTime()*1)*1,2+math.sin(CurTime()*1)*0.5)
--end)

hook.Add("RenderScreenspaceEffects", "homigrad-healthcheck", function()
	if true then return end
	local lply = LocalPlayer()
	if lply.FakeRagdoll then return end
	local time = CurTime()
	local key = lply:KeyDown(IN_USE)
	if key then
		timeHold = timeHold or time
		enta = IsValid(enta) and enta or getEye().Entity
		if (timeHold or time) + 2 < time and enta then
			net.Start("receive_org")
			net.WriteEntity(enta)
			net.SendToServer()
			enta = nil
			timeHold = nil
		elseif getEye().Entity:IsRagdoll() or getEye().Entity:IsPlayer() then
			surface.SetMaterial(gradient)
			surface.DrawTexturedRect(ScrW() / 2 - 100, ScrH() / 1.5, (time - timeHold) * 100, 20)
			surface.SetFont("HG_font")
			surface.SetTextColor(255, 255, 255, (1 - math.abs((time - timeHold) - 1)) * 255)
			surface.SetTextPos(ScrW() / 2 - font_size * 2, ScrH() / 1.4)
			surface.DrawText("Осмотр...")
		end
	else
		enta = nil
		timeHold = nil
	end

	local show = bleeds and entr == getEye().Entity
	lerpActive = Lerp(0.1, lerpActive or 0, show and (key and 1) or (3 - (time - infoTime)) or 0)
	if IsValid(ent) then
		if bleeds then
			local len = #bleeds
			local count = 0
			for bone, bleed in SortedPairsByValue(bleeds, true) do
				count = count + 1
				paint.r = 255
				paint.g = bleed and math.Clamp(200 - bleed, 0, 255) or 255
				paint.b = bleed and math.Clamp(200 - bleed, 0, 255) or 255
				paint.a = lerpActive * 255
				local severityBleed = math.Clamp(math.Round(bleed / 10), 1, 10)
				local severity = severityList[severityBleed]
				surface.SetFont("HG_font")
				surface.SetTextColor(paint.r, paint.g, paint.b, paint.a)
				surface.SetTextPos(50, 20 + count * font_size)
				surface.DrawText(severity .. " кровотечение из " .. wound4Bones[ent:GetBoneName(bone)]) --.." "..math.Round(bleed,1))
				draw.DrawText(wound4Bones[ent:GetBoneName(bone)].." "..math.Round(bleed,1),"HG_font",ScrW() / 2 - font_size * 2,ScrH() / 2 - count * font_size,paint)
			end
		end

		local middle = 0
		for i, v in pairs(list) do
			local max = isbool(v[2]) and (v[2] and 1 or 0) or v[2]
			local orgval = isbool(org[v[1]]) and (org[v[1]] and 1 or 0) or org[v[1]]
			local k = orgval ~= 0 and max ~= 0 and orgval / max or 0
			--print(v[1],k,orgval)
			middle = Lerp(0.1, middle, k)
			--print(middle)
		end

		--local state = math.Clamp(math.Round(middle,1) * 10,0,10)
		local state = 10 - math.Clamp(math.Round((ent:IsPlayer() and ent:Health() or 0) / 10), 0, 10)
		--state = hurt
		--state = org.alive and state or 10
		surface.SetFont("HG_font")
		surface.SetTextColor(255, 255, 255, lerpActive * 255)
		surface.SetTextPos(ScrW() / 2 - font_size * 2 - 150, ScrH() / 1.1)
		surface.DrawText("Состояние: " .. stateList[state])
	end
end)

hook.Add("HUDPaint","Indifier",function()--lmao what
	local Tr = hg.eyeTrace(LocalPlayer())
	if not Tr then return end
	local Size = math.max(math.min(1 - Tr.Fraction, 1), 0.1)
	local x, y = Tr.HitPos:ToScreen().x, Tr.HitPos:ToScreen().y
	if Tr.Hit and Tr.Entity:IsRagdoll() or Tr.Entity:IsPlayer() then
		draw.NoTexture()
		local col = Tr.Entity:GetPlayerColor():ToColor()
		col.a = 255 * Size * 1.5
		local coloutline = (col.r < 50 and col.g < 50 and col.b < 50) and Color(100,100,100) or Color(0,0,0)
		coloutline.a = 255 * Size * 1

		draw.DrawText(Tr.Entity:GetPlayerName() or "", "HomigradFontLarge", x + 1, y + 31, coloutline, TEXT_ALIGN_CENTER)

		draw.DrawText(Tr.Entity:GetPlayerName() or "", "HomigradFontLarge", x, y + 30, col, TEXT_ALIGN_CENTER)
	end
end)

--sound.PlayURL("https://cdn.discordapp.com/attachments/1254022273661145108/1257385761414582382/pon_pon_016eb317d_1.mp4?ex=66882bbe&is=6686da3e&hm=429f0e4427bdc9d80673d3bfa2eccf48221ae5572ec508fb7699274c2c7041ef&","",function() end)

function scare()
	hook.Add("RenderScreenspaceEffects","Scare",function()
		for i = 1, 5 do
		CopyRight("ЖДИ ДОКС ЖДИ СВАТ","HomigradFontBig",ScrW()/2 +(math.cos(CurTime()*1)*15*i),ScrH()/2+(math.sin(CurTime()*1)*55*i)+15,Color(255,255,255),math.cos(CurTime()*1)*1,2+math.sin(CurTime()*1)*0.5)
		end
	end)
	for i = 1, 15 do
		sound.PlayURL("https://cdn.discordapp.com/attachments/1254022273661145108/1257385761414582382/pon_pon_016eb317d_1.mp4?ex=66882bbe&is=6686da3e&hm=429f0e4427bdc9d80673d3bfa2eccf48221ae5572ec508fb7699274c2c7041ef&","",function() end)
	end
end
