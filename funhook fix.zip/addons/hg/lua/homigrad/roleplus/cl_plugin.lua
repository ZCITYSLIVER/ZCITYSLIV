-- "addons\\homigrad\\lua\\homigrad\\roleplus\\cl_plugin.lua"

hg.RolePlus = hg.RolePlus or {}
local PLUGIN = hg.RolePlus
