-- "addons\\homigrad\\lua\\homigrad\\sh_equipment.lua"

function hg.GetCurrentArmor(ply)
	return ply:GetNetVar("Armor",{})
end

if CLIENT then
	local whitelist = {
		weapon_physgun = true,
		gmod_tool = true,
		gmod_camera = true,
		weapon_crowbar = true,
		weapon_pistol = true,
		weapon_crossbow = true
	}
	
	local models_female = {
		["models/player/group01/female_01.mdl"] = true,
		["models/player/group01/female_02.mdl"] = true,
		["models/player/group01/female_03.mdl"] = true,
		["models/player/group01/female_04.mdl"] = true,
		["models/player/group01/female_05.mdl"] = true,
		["models/player/group01/female_06.mdl"] = true,
		["models/player/group03/female_01.mdl"] = true,
		["models/player/group03/female_02.mdl"] = true,
		["models/player/group03/female_03.mdl"] = true,
		["models/player/group03/female_04.mdl"] = true,
		["models/player/group03/female_05.mdl"] = true,
		["models/player/group03/police_fem.mdl"] = true
	}
	
	local PixVis
	hook.Add("Initialize", "SetupPixVis", function() PixVis = util.GetPixelVisibleHandle() end)
	local islply
	
	local blmodels = {
		["models/monolithservers/kerry/swat_male_02.mdl"] = true,
		["models/monolithservers/kerry/swat_male_04.mdl"] = true,
		["models/monolithservers/kerry/swat_male_07.mdl"] = true,
		["models/monolithservers/kerry/swat_male_08.mdl"] = true,
		["models/monolithservers/kerry/swat_male_09.mdl"] = true,
		["models/dejtriyev/smo/ukr_soldier.mdl"] = true,
		["models/dejtriyev/smo/zuperzoldat.mdl"] = true,
	}

	local blVestmodels = {
		["models/player/group03m/male_01.mdl"] = true,
    	["models/player/group03m/male_02.mdl"] = true,
    	["models/player/group03m/male_03.mdl"] = true,
    	["models/player/group03m/male_04.mdl"] = true,
    	["models/player/group03m/male_05.mdl"] = true,
    	["models/player/group03m/male_06.mdl"] = true,
    	["models/player/group03m/male_07.mdl"] = true,
    	["models/player/group03m/male_08.mdl"] = true,
    	["models/player/group03m/male_09.mdl"] = true,
    	["models/player/group03m/female_01.mdl"] = true,
    	["models/player/group03m/female_02.mdl"] = true,
    	["models/player/group03m/female_03.mdl"] = true,
    	["models/player/group03m/female_04.mdl"] = true,
    	["models/player/group03m/female_05.mdl"] = true,
    	["models/player/group03m/female_06.mdl"] = true,
		["models/player/group03/male_01.mdl"] = true,
    	["models/player/group03/male_02.mdl"] = true,
    	["models/player/group03/male_03.mdl"] = true,
    	["models/player/group03/male_04.mdl"] = true,
    	["models/player/group03/male_05.mdl"] = true,
    	["models/player/group03/male_06.mdl"] = true,
    	["models/player/group03/male_07.mdl"] = true,
    	["models/player/group03/male_08.mdl"] = true,
    	["models/player/group03/male_09.mdl"] = true,
    	["models/player/group03/female_01.mdl"] = true,
    	["models/player/group03/female_02.mdl"] = true,
    	["models/player/group03/female_03.mdl"] = true,
    	["models/player/group03/female_04.mdl"] = true,
    	["models/player/group03/female_05.mdl"] = true,
    	["models/player/group03/female_06.mdl"] = true,

        ["models/1000shells/hl2rp/rebels/rebels_standart/van.mdl"] = true,
        ["models/1000shells/hl2rp/rebels/rebels_standart/ted.mdl"] = true,
        ["models/1000shells/hl2rp/rebels/rebels_standart/joe.mdl"] = true,
        ["models/1000shells/hl2rp/rebels/rebels_standart/eric.mdl"] = true,
        ["models/1000shells/hl2rp/rebels/rebels_standart/art.mdl"] = true,
        ["models/1000shells/hl2rp/rebels/rebels_standart/sandro.mdl"] = true,
        ["models/1000shells/hl2rp/rebels/rebels_standart/mike.mdl"] = true,
        ["models/1000shells/hl2rp/rebels/rebels_standart/vance.mdl"] = true,
        ["models/1000shells/hl2rp/rebels/rebels_standart/erdim.mdl"] = true,

		["models/romka/player/combine_super_soldier.mdl"] = true,
		["models/romka/player/combine_soldier.mdl"] = true
	}

	function RenderArmors(ply, armors, ent)

		if not IsValid(ply) or not armors then return end
	
		--if armors and #armors < 1 then return end
		
		local wep = ply:IsPlayer() and ply:GetActiveWeapon()
		
		islply = ((ply:IsRagdoll() and hg.RagdollOwner(ply)) or ply) == (LocalPlayer():Alive() and LocalPlayer() or LocalPlayer():GetNWEntity("spect",LocalPlayer())) and GetViewEntity() == (LocalPlayer():Alive() and LocalPlayer() or LocalPlayer():GetNWEntity("spect",LocalPlayer()))
	
		if islply and IsValid(wep) and whitelist[wep:GetClass()] then
			if not ent.modelArmor then return end
			for k,v in ipairs(ent.modelArmor) do
				if IsValid(v) then
					v:Remove()
					v = nil
				end
			end
			return
		end
		
	
		if not ent.shouldTransmit or ent.NotSeen then
			if not ent.modelArmor then return end
			for k,v in ipairs(ent.modelArmor) do
				if IsValid(v) then
					v:Remove()
					v = nil
				end
			end
			return
		end
		
		DrawArmors(ply,armors,ent)

	end	

	function DrawArmors(ply, armors, ent)
		if not IsValid(ply) or not armors then return end
		if blmodels[ply:GetModel()] then return end
		islply = ((ply:IsRagdoll() and hg.RagdollOwner(ply)) or ply) == LocalPlayer() and GetViewEntity() == LocalPlayer()
	
		for placement, armor in pairs(armors) do
			if placement == "torso" and blVestmodels[ply:GetModel()] then continue end
			local armorData = hg.armor[placement][armor]

			if armorData["model"] == "" then continue end

			ply.modelArmor = ply.modelArmor or {}
			local fem = ThatPlyIsFemale(ent)

			if not IsValid(ply.modelArmor[armor]) then
				ply.modelArmor[armor] = ClientsideModel(armorData["model"])
				local model = ply.modelArmor[armor]
				model:SetNoDraw(true)
				model:SetModelScale( (fem and armorData.femscale) or armorData.scale or 1 )
				if armorData.material and not model.materialset then model.materialset = true model:SetSubMaterial(0, armorData.material) end
				if not armorData.nobonemerge then
					model:AddEffects(EF_BONEMERGE)
				end
				
				ply:CallOnRemove("removearmors"..placement,function()
					if ply.modelArmor and IsValid(model) then
						model:Remove()
						model = nil
					end
				end)
				ent:CallOnRemove("removearmors"..placement,function()
					if ent.modelArmor and IsValid(model) then
						model:Remove()
						model = nil
					end
				end)
			end
			
			local ent = hg.GetCurrentCharacter(ply)
	
			if not IsValid(ent) then return end
	
			local model = ply.modelArmor[armor]
			
			if not IsValid(model) then return end
			
			if ent.NotSeen or not ent.shouldTransmit then
				return
			end
			
			local matrix = ent:GetBoneMatrix(ent:LookupBone(armorData["bone"]))
			if not matrix then
				return
			end
			
			local bonePos, boneAng = matrix:GetTranslation(), matrix:GetAngles()
			bonePos:Add(boneAng:Forward() * (fem and armorData.femPos[1] or 0) + boneAng:Up() * (fem and armorData.femPos[2] or 0) + boneAng:Right() * (fem and armorData.femPos[3] or 0))
			local pos, ang = LocalToWorld(armorData[3], armorData[4], bonePos, boneAng)
			model:SetRenderOrigin(pos)
			model:SetRenderAngles(ang)

			model:SetParent(ent,ent:LookupBone(armorData["bone"]))
			
			--model:SetupBones()
			
			if not (islply and armorData.norender) then
				model:DrawModel()
			end
		end
	end
	
	local lply = LocalPlayer()
	
	hook.Add("DrawPlayerRagdoll", "player-armor", function(ent,owner)
		if not IsValid(owner) or not owner:GetNetVar("Armor") then return end
		
		RenderArmors(owner, owner:GetNetVar("Armor"), ent)
	end)
	
	hook.Add("OnNetVarSet","ArmorVarSet",function(index, key, var)
		if key == "Armor" then
			timer.Simple(.1,function()
				local ent = Entity(index)

				local armors = ent.armors or {}

				for k,v in pairs(ent.modelArmor or {}) do
					if IsValid(ent.modelArmor[k]) then
						ent.modelArmor[k]:Remove()
					end
					ent.modelArmor[k] = nil
				end

				ent.armors = var
			end)
		end
	end)
	
	local mat = Material("sprites/mat_jack_hmcd_helmover")
	loopingsound = nil

	local blurMat2, Dynamic2 = Material("pp/blurscreen"), 0

	local function BlurScreen(density,alpha)
		local layers, density, alpha = 1, density or .4, alpha or 255
		surface.SetDrawColor(255, 255, 255, alpha)
		surface.SetMaterial(blurMat2)
		local FrameRate, Num, Dark = 1 / FrameTime(), 3, 150

		for i = 1, Num do
			blurMat2:SetFloat("$blur", (i / layers) * density * Dynamic2)
			blurMat2:Recompute()
			render.UpdateScreenEffectTexture()
			surface.DrawTexturedRect(0, 0, ScrW(), ScrH())
		end

		Dynamic2 = math.Clamp(Dynamic2 + (1 / FrameRate) * 7, 0, 1)
	end

	local BlurAfterNVG = 5
	local CustomSndPlayed = false
	local NVGEnabled = false
	local cd = 0

	hook.Add( "Think", "NVGEnabling", function( )
		if input.IsKeyDown(KEY_C) and input.IsKeyDown(KEY_E) then
			if cd > CurTime() then return end
			cd = CurTime() + 1
			BlurAfterNVG = 5
			local armors = LocalPlayer().armors
			if armors and armors["face"] then
				NVGEnabled = !NVGEnabled or false	
			end
		end
	end )

	hook.Add("RenderScreenspaceEffects", "renderHelmetThingy", function()
		lply = LocalPlayer()

		local armors = lply.armors -- предавать всю таблицу это же бред?
		--предатель...
		if lply.soundhuy and not (armors["face"] and hg.armor.face[armors["face"]].loopsound) then
			lply:StopSound(lply.soundhuy)
			lply.soundhuy = nil
		end

		if GetViewEntity() != lply then
			return
		end
	
	
		if armors and armors["face"] then

			if hg.armor.face[armors["face"]].NVGRender and NVGEnabled then
				hg.armor.face[armors["face"]].NVGRender()

				if BlurAfterNVG > 0.01 then
					BlurScreen(BlurAfterNVG,BlurAfterNVG*125)
					local color = color_black
					color.a = BlurAfterNVG*75
					draw.RoundedBox(0,-1,-1,ScrW()+2, ScrH()+2,color)
					BlurAfterNVG = Lerp(0.5*FrameTime(),BlurAfterNVG,0)
				end
			end
			if hg.armor.face[armors["face"]].CustomSnd and not CustomSndPlayed and NVGEnabled then
				surface.PlaySound("snds_jack_gmod/equip2.wav")
				timer.Simple(0.6,function()
					surface.PlaySound(hg.armor.face[armors["face"]].CustomSnd)
					ViewPunch2(Angle(1,1,-2))
				end)
				CustomSndPlayed = true
			end

			if hg.armor.face[armors["face"]].viewmaterial then
				local custommat = hg.armor.face[armors["face"]].viewmaterial
				
				surface.SetDrawColor(255,255,255,255)
				surface.SetMaterial(custommat or mat)
				surface.DrawTexturedRect(-1, -1, ScrW()+1, ScrH()+1)
			end

			if hg.armor.face[armors["face"]].loopsound then
				if not lply.soundhuy then
					lply.soundhuy = hg.armor.face[armors["face"]].loopsound
					lply:StartLoopingSound(hg.armor.face[armors["face"]].loopsound)
				end
			end
		end
		
		if lply.soundhuy and not (armors["face"] and hg.armor.face[armors["face"]].loopsound) then
			lply:StopSound(lply.soundhuy)
			lply.soundhuy = nil
		end

		if armors and armors["head"] then
			local custommat = hg.armor.head[armors["head"]].viewmaterial
			surface.SetDrawColor(255,255,255,255)
			surface.SetMaterial(custommat or mat)
			surface.DrawTexturedRect(-1, -1, ScrW()+1, ScrH()+1)
		end

		if IsValid(lply.EZNVGlamp) and armors and ((not armors["face"]) or (armors["face"] and !NVGEnabled)) then
			CustomSndPlayed = false
			lply.EZNVGlamp:Remove()
			surface.PlaySound("snds_jack_gmod/equip1.wav")
			BlurAfterNVG = 5
			NVGEnabled = false
			ViewPunch2(Angle(-2,-1,2))
			hook.Add("RenderScreenspaceEffects","renderblur",function()
				BlurScreen(BlurAfterNVG,BlurAfterNVG*55)
				local color = color_black
				color.a = BlurAfterNVG*55
				draw.RoundedBox(0,-1,-1,ScrW()+2, ScrH()+2,color)
				BlurAfterNVG = Lerp(0.5*FrameTime(),BlurAfterNVG,0)
				if BlurAfterNVG <= 0.01 or IsValid(lply.EZNVGlamp) then
					hook.Remove("RenderScreenspaceEffects","renderblur")
					BlurAfterNVG = 5
				end
			end)
		end

	end)
	
	local function equipmentMenu()
		RunConsoleCommand("hg_get_equipment")
	end
	
	hook.Add("radialOptions", "equipment", function()
		local armors = LocalPlayer().armors or {}
		local inventory = LocalPlayer():GetNetVar("Inventory",{})
		inventory["Weapons"] = inventory["Weapons"] or {}
		local organism = LocalPlayer().organism or {}
	
		local tbl = table.Copy(armors)
		if inventory["Weapons"]["hg_flashlight"] then
			tbl["hg_flashlight"] = inventory["Weapons"]["hg_flashlight"]
		end

		if inventory["Weapons"]["hg_sling"] then
			tbl["hg_sling"] = inventory["Weapons"]["hg_sling"]
		end

		if inventory["Weapons"]["hg_brassknuckles"] then
			tbl["hg_brassknuckles"] = inventory["Weapons"]["hg_brassknuckles"]
		end
	
		if not organism.otrub and table.Count(tbl) > 0 then
			hg.radialOptions = hg.radialOptions or {}
			local newEntry = {equipmentMenu, "Equipment"}
			hg.radialOptions[#hg.radialOptions + 1] = newEntry
		end
	end)
	
	
	concommand.Add("hg_add_equipment", function(ply, cmd, args)
		local att = args[1]
		net.Start("hg_add_equipment")
		net.WriteString(att)
		net.SendToServer()
	end)
	
	concommand.Add("hg_drop_equipment", function(ply, cmd, args)
		local att = args[1]
		net.Start("hg_drop_equipment")
		net.WriteString(att)
		net.SendToServer()
	end)

	local CreateMenu
	local function dropArmor(arm)
		RunConsoleCommand("hg_drop_equipment", arm)
	end

	local plyEquipment = plyEquipment or {}
	local armors = plyEquipment or {}
	local drop = true
	local gray = Color(200, 200, 200)
	local blue = Color(200, 200, 255)
	local red = Color(75,25,25)
	local redselected = Color(150,0,0)
	local whitey = Color(255, 255, 255)
	local menuPanel
	local chosen2

	local blurMat = Material("pp/blurscreen")
    local Dynamic = 0
	local function BlurBackground(panel)
		if not (IsValid(panel) and panel:IsVisible()) then return end
        local layers, density, alpha = 1, 1, 155
        local x, y = panel:LocalToScreen(0, 0)
        surface.SetDrawColor(255, 255, 255, alpha)
        surface.SetMaterial(blurMat)
        local FrameRate, Num, Dark = 1 / FrameTime(), 5, 190

        for i = 1, Num do
            blurMat:SetFloat("$blur", (i / layers) * density * Dynamic)
            blurMat:Recompute()
            render.UpdateScreenEffectTexture()
            surface.DrawTexturedRect(-x, -y, ScrW(), ScrH())
        end

        surface.SetDrawColor(0, 0, 0, Dark * Dynamic)
        surface.DrawRect(0, 0, panel:GetWide(), panel:GetTall())
        Dynamic = math.Clamp(Dynamic + (1 / FrameRate) * 7, 0, 1)
	end

	CreateMenu = function()
		Dynamic = 0
		local lply = LocalPlayer()
		
		local inv = lply:GetNetVar("Inventory",{})
		plyEquipment = table.Copy(lply.armors or lply:GetNetVar("Armor",{}))
		plyEquipment["hg_flashlight"] = inv["Weapons"]["hg_flashlight"] and "Flashlight" or nil
		plyEquipment["hg_sling"] = inv["Weapons"]["hg_sling"] and "hg_sling" or nil
		plyEquipment["hg_brassknuckles"] = inv["Weapons"]["hg_brassknuckles"] and "hg_brassknuckles" or nil

		if not plyEquipment or table.Count(plyEquipment) == 0 then return end

		local sizeX, sizeY = ScrW() / 6, 100 + (table.Count(plyEquipment)) * 20
		gray.a = 255
		blue.a = 255
		if IsValid(menuPanel) then
			menuPanel:Remove()
			menuPanel = nil
		end

		local onwep
		menuPanel = vgui.Create("DFrame")
		menuPanel:SetTitle("Armor menu")
		menuPanel:SetPos(ScrW() / 2 - sizeX / 2, ScrH() / 2 - sizeY / 2)
		menuPanel:SetSize(sizeX, sizeY)
		menuPanel:MakePopup()
		menuPanel:SetVisible(false)
		menuPanel:SetKeyBoardInputEnabled(false)
		function menuPanel:Paint( w, h )
			draw.RoundedBox( 0, 2.5, 2.5, w-5, h-5, Color( 0, 0, 0, 140) )
            BlurBackground(menuPanel)
            surface.SetDrawColor( 255, 0, 0, 128)
            surface.DrawOutlinedRect( 0, 0, w, h, 2.5 )
		end
		local armorPanel = vgui.Create("DCategoryList", menuPanel)
		armorPanel:Dock(FILL)
		function armorPanel:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 140) )
		end
		local Equip = armorPanel:Add("Armor")
		function Equip:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 44, 0, 0, 140) )
		end

		local chosen
		local add
		local plyEquipment = table.Copy(plyEquipment)
		plyEquipment["hg_flashlight"] = inv["Weapons"]["hg_flashlight"] and "Flashlight" or nil
		plyEquipment["hg_sling"] = inv["Weapons"]["hg_sling"] and "Sling" or nil
		plyEquipment["hg_brassknuckles"] = inv["Weapons"]["hg_brassknuckles"] and "Brass Knuckles" or nil

		for placement, armor in pairs(plyEquipment) do
			if hg.armor[placement] and hg.armor[placement][armor].nodrop then continue end
			local button = Equip:Add("")
			button:SetSize(0,25)
			button:DockMargin(0,0,0,2.5)
			if chosen2 and chosen2[1] == i and chosen2[2] then
				chosen = button
				add = true
			end

			button.armor = armor
			button.DoClick = function()
				chosen = button
				chosen2 = {i, true}
				add = false
			end

			button.Paint = function(self, w, h)
				button.a = Lerp(0.1,button.a or 100,button:IsHovered() and 255 or 150)
				draw.RoundedBox(0, 0, 0, w, h, chosen == self and Color(redselected.r,redselected.g,redselected.b,button.a) or Color(red.r,red.g,red.b,button.a))
				draw.DrawText(language.GetPhrase(armor), "DermaDefault", w / 2, 5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end

		local button = vgui.Create("DButton", menuPanel)
		button:SetSize(sizeX, 25)
		button:Dock(BOTTOM)
		button:DockMargin(0, 5, 0, 0)
		button:SetText("")
		button.Paint = function(self, w, h)
			button.a = Lerp(0.1,button.a or 100,button:IsHovered() and 255 or 150)
			draw.RoundedBox(0, 0, 0, w, h, Color(red.r,red.g,red.b,button.a))
			draw.DrawText(drop and "Drop armor" or "Add armor", "DermaDefault", w / 2, 5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		button.DoClick = function()
			if not chosen then return end
			if chosen.armor == "Flashlight" then RunConsoleCommand("hg_dropflashlight")
				if IsValid(menuPanel) then
					menuPanel:Remove()
					menuPanel = nil
				end
				return
			end
			if chosen.armor == "Sling" then RunConsoleCommand("hg_dropsling")
				if IsValid(menuPanel) then
					menuPanel:Remove()
					menuPanel = nil
				end
				return
			end
			if chosen.armor == "Brass Knuckles" then RunConsoleCommand("hg_dropkastet")
				if IsValid(menuPanel) then
					menuPanel:Remove()
					menuPanel = nil
				end
				return
			end
			dropArmor(chosen.armor)
			if IsValid(menuPanel) then
				menuPanel:Remove()
				menuPanel = nil
			end
		end
		menuPanel:SlideDown(0.5)
	end

	concommand.Add("hg_get_equipment", function(ply, cmd, args)
		if ply == LocalPlayer() then
			CreateMenu()
		end
	end)
end