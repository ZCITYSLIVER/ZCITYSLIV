-- НИКОГДА В ЖИЗНИ НЕ ДОДЕЛАЮ УВЕРЯЮ ВАС
--hg.Appearance = hg.Appearance or {}
--
--hg.PointShop = hg.PointShop or {}
--
--local PLUGIN = hg.PointShop
--
--PLUGIN.Items = PLUGIN.Items or {}
--
--local allowed = {
--    ' ',
--    'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я',
--    'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я',
--    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
--    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
--}
--
--local function IsInvalidName(name)
--    local trimmedName = string.Trim(name)
--    
--    if trimmedName == "" then
--        return true
--    end
--
--    if #trimmedName < 2 then
--        return true
--    end
--    
--    local symblos = utf8.len( name )
--
--    for k=1, symblos do
--        if !table.HasValue(allowed, utf8.GetChar(name,k) ) then return true end
--    end
--
--    return false
--end
--
--hg.Appearance.IsInvalidName = IsInvalidName
--
--local RandomNames = {
--    [1] = { -- MaleNames
--        "Mike",
--        "Dave",
--        "Michel",
--        "John",
--        "Fred",
--        "Michiel",
--        "Steven",
--        "Sergio",
--        "Joel",
--        "Samuel",
--        "Larry",
--        "Sean",
--        "Thomas",
--        "Jose",
--        "Bobby",
--        "Richard",
--        "David"
--    },
--    [2] = { -- FemaleNames
--        "Denise",
--        "Joyce",
--        "Jane",
--        "Sara",
--        "Emily",
--        "Charlotte",
--        "Cathy",
--        "Ruth",
--        "Julia",
--        "Tanya",
--        "Wanda",
--        "Elizabeth",
--        "Nicole",
--        "Stacey",
--        "Mary",
--        "Anna",
--        "Diana"
--    }
--}
--
--hg.Appearance.RandomNames = RandomNames
--
--local function GenerateRandomName(ply)
--    local sex = math.random(1, 2) 
--    local randomName = hg.Appearance.RandomNames[sex][math.random(1, #hg.Appearance.RandomNames[sex])]
--    return randomName
--end
--
--hg.Appearance.GenerateRandomName = GenerateRandomName
--
--local PlayerModels = {
--    [1] = {},
--    [2] = {}
--}
--for i = 1, 9 do
--    PlayerModels[1]["Male 0"..i] = {mdl = "models/player/zcity/male_0"..i..".mdl", submaterials = {pants = 5, top = 4, boots = 6} }
--end
--for i = 1, 6 do
--    PlayerModels[2]["Female 0"..i] = {mdl = "models/player/zcity/female_0"..i..".mdl", submaterials = {pants = 5, top = 4, boots = 6} }
--end
--
--hg.Appearance.PlayerModels = PlayerModels
--
--hg.Appearance.Clothes = {}
--
--local function checkError( name, ... )
--    local err = false
--    for k, v in ... do
--        if not v then ErrorNoHalt( "[".. name .."] Invalid "..k ) err = true end
--    end
--    return err
--end
--
--hg.Appearance.Clothes[1] = {}
----for i = 1, 31 do --TEST
----    hg.Appearance.Clothes.Male["Sheet 01"] = "models/humans/modern/male/sheet_"..( i < 10 and "0" or "" ) .. i
----end
--
--hg.Appearance.Clothes[2] = {}
----for i = 1, 15 do --TEST
----    hg.Appearance.Clothes.Female["Sheet 01"] = "models/humans/modern/female/sheet_"..( i < 10 and "0" or "" ) .. i
----end
--
--function hg.Appearance.Clothes:AddClothing( iSex, strName, strMaterial, bFree, bDonate, iCost ) 
--    if checkError( "HG.Appearance.Clothes:AddClothing", iSex, strName, strMaterial ) then return end
--    bDonate = bDonate or false
--    hg.Appearance.Clothes[ iSex ][ strName ] = { MTL = strMaterial, Free = bFree, Donate = bDonate }
--
--    --PLUGIN:CreateItem( uid, strName, strModel, strBodyGroups, iSkin, vecPos, intPrice, bIsDPoints, tData, fCallback )
--    if bFree then return end--   C57TVYI*5B6

---- DUMPED WITH GMODLUAINJECTOR MADE BY GAZTOOF FOR UNKNOWNCHEATS :)
--    PLUGIN:CreateItem( 
--        strMaterial, 
--        string.NiceName( strName ), 
--        sex == 2 and "models/player/zcity/female_01.mdl" or "models/player/zcity/male_07.mdl" , 
--        "00000", 
--        0, 
--        Vector(0,0,0), 
--        iCost, 
--        bDonate,
--        {4 = strMaterial, 5 = strMaterial, 6 = strMaterial} 
--    )
--end
--
--for i = 1, 31 do --TEST
--    local int = ( i < 10 and "0" or "" ) .. i
--    hg.Appearance.Clothes:AddClothing(1, "Sheet ".. int, "models/humans/modern/male/sheet_".. int, true, false, 0)
--end
--hg.Appearance.Clothes:AddClothing(1, "Sheet 14", "models/humans/modern/male/sheet_14", false, true, 1000) -- Rayn Gosling
--hg.Appearance.Clothes:AddClothing(1, "Sheet 02", "models/humans/modern/male/sheet_02", false, true, 500) -- Hren dla yltra pravoy shkolotu
--hg.Appearance.Clothes:AddClothing(1, "Sheet 10", "models/humans/modern/male/sheet_10", false, true, 700) -- Dobrograd Shootfire
--hg.Appearance.Clothes:AddClothing(1, "Sheet 13", "models/humans/modern/male/sheet_13", false, true, 800) -- Dora
--hg.Appearance.Clothes:AddClothing(1, "Sheet 08", "models/humans/modern/male/sheet_08", false, true, 500) -- XRay
--hg.Appearance.Clothes:AddClothing(1, "Sheet 24", "models/humans/modern/male/sheet_24", false, true, 600) -- Cool Suit
--hg.Appearance.Clothes:AddClothing(1, "Sheet 04", "models/humans/modern/male/sheet_04", false, true, 1000) -- Bebra
--
--
--for i = 1, 15 do --TEST
--    local int = ( i < 10 and "0" or "" ) .. i
--    hg.Appearance.Clothes:AddClothing(2, "Sheet ".. int, "models/humans/modern/female/sheet_".. int, true, false, 0)
--end
--
--hg.Appearance.Clothes:AddClothing(1, "Sheet 04", "models/humans/modern/male/sheet_04", false, true, 1000) -- Bebra

--hg.Appearance.Clothes:AddClothing()
