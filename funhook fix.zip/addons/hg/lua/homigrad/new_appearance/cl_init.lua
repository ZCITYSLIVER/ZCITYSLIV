--

--local whitelist = {
--	weapon_physgun = true,
--	gmod_tool = true,
--	gmod_camera = true,
--	weapon_crowbar = true,
--	weapon_pistol = true,
--	weapon_crossbow = true
--}
--
--local islply
--
--function RenderAccessories(ply, accessories)
--	if not IsValid(ply) or not accessories then return end
--
--	if accessories == "none" then return end
--
--	local wep = ply:IsPlayer() and ply:GetActiveWeapon()
--
--	local ent = IsValid(ply.FakeRagdoll) and ply.FakeRagdoll or ply
--	
--	islply = ((ply:IsRagdoll() and hg.RagdollOwner(ply)) or ply) == (LocalPlayer():Alive() and LocalPlayer() or LocalPlayer():GetNWEntity("spect",LocalPlayer())) and GetViewEntity() == (LocalPlayer():Alive() and LocalPlayer() or LocalPlayer():GetNWEntity("spect",LocalPlayer()))
--
--	if islply and IsValid(wep) and whitelist[wep:GetClass()] then
--		if not ent.modelAccess then return end
--		for k,v in ipairs(ent.modelAccess) do
--			if IsValid(v) then
--				v:Remove()
--				v = nil
--			end
--		end
--		return
--	end
--	
--	if not ent.shouldTransmit or ent.NotSeen then
--		if not ent.modelAccess then return end
--		for k,v in ipairs(ent.modelAccess) do
--			if IsValid(v) then
--				v:Remove()
--				v = nil
--			end
--		end
--		return
--	end
--	
--	if istable(accessories) then
--		for k = 1, #accessories do
--			local accessoriess = accessories[k]
--			local accessData = hg.Accessories[accessoriess]
--			if not accessData then continue end
--			
--			DrawAccesories(ply,ent,accessoriess,accessData,islply)
--		end
--	else
--		local accessData = hg.Accessories[accessories]
--		if not accessData then return end
--		
--		DrawAccesories(ply,ent,accessories,accessData,islply)
--	end
--end
--
--local huy_addvec = Vector(0.4,0,0.4)
--
--function DrawAccesories(ply,ent,accessories,accessData,islply,force)
--	if not accessories then return end
--	if not accessData then return end
--	
--	ply.modelAccess = ply.modelAccess or {}
--	local fem = ThatPlyIsFemale(ent)
--	--print(fem)
--	if not IsValid(ply.modelAccess[accessories]) then
--		if not accessData["model"] then return end
--		ply.modelAccess[accessories] = ClientsideModel(fem and accessData["femmodel"] or accessData["model"], RENDERGROUP_BOTH)
--		
--		local model = ply.modelAccess[accessories]
--		model:SetNoDraw(true)
--		model:SetModelScale( accessData[fem and "fempos" or "malepos"][3] )
--		model:SetSkin( accessData["skin"] )
--		model:SetBodyGroups( accessData["bodygroups"] or "" )
--		model:SetParent(ent,ent:LookupBone(accessData["bone"]))
--		model:AddEffects(EF_BONEMERGE)
--		if accessData["bSetColor"] then
--			if ply.GetPlayerColor then 
--				model:SetColor(ply:GetPlayerColor():ToColor())
--			else
--				model:SetColor(ply:GetNWVector("PlayerColor",Vector(1,1,1)):ToColor())
--			end
--		end
--
--		ply:CallOnRemove("RemoveAccessories"..accessories,function() 
--			if ply.modelAccess and IsValid(model) then
--				model:Remove()
--				model = nil
--			end
--		end)
--		ent:CallOnRemove("RemoveAccessories2"..accessories,function() 
--			if ply.modelAccess and IsValid(model) then
--				model:Remove()
--				model = nil
--			end
--		end)
--	end
--	
--	local model = ply.modelAccess[accessories]
--	
--	local mdl = string.Split(string.sub(ent:GetModel(),1,-5),"/")[#string.Split(string.sub(ent:GetModel(),1,-5),"/")]
--	if mdl and model:GetFlexIDByName(mdl) then
--		model:SetFlexWeight(model:GetFlexIDByName(mdl),1)
--	end
--	
--	if not IsValid(model) then ply.modelAccess[accessories] = nil return end
--	
--	if ply.armors and accessData["placement"] and ply.armors[accessData["placement"]] then
--
--		return
--	end
--	
--	if not force and ((ent.NotSeen or not ent.shouldTransmit) or (ply:IsPlayer() and not ply:Alive())) then
--
--		return
--	end
--	
--	local bone = ent:LookupBone(accessData["bone"])
--	if not bone then return end
--	if ent:GetManipulateBoneScale(bone):LengthSqr() < 0.1 then return end
--	local matrix = ent:GetBoneMatrix(bone)
--	if not matrix then return end
--	
--	local bonePos, boneAng = matrix:GetTranslation(), matrix:GetAngles()
--	
--	local addvec = ((ent:GetModel() == "models/player/group01/male_06.mdl") and ((accessData.placement == "head") or (accessData.placement == "face"))) and huy_addvec or vector_origin
--	
--	local pos, ang = LocalToWorld(accessData[fem and "fempos" or "malepos"][1], accessData[fem and "fempos" or "malepos"][2], bonePos, boneAng)
--	local pos = LocalToWorld(addvec,angle_zero,pos,ang)
--	model:SetRenderOrigin(pos)--   C57TVYI*5B6

--	model:SetRenderAngles(ang)
--	if model:GetParent() != ent then model:SetParent(ent, bone) end
--	--print(CurTime(), ent)
--	if not (islply and accessData.norender) then
--		if accessData["bSetColor"] then
--			local colorDraw = ply.GetPlayerColor and ply:GetPlayerColor() or ply:GetNWVector("PlayerColor",Vector(1,1,1))
--			render.SetColorModulation( colorDraw[1],colorDraw[2],colorDraw[3] )
--		end
--		
--		model:DrawModel()
--
--		if accessData["bSetColor"] then
--			render.SetColorModulation( 1,1,1 )
--		end
--	end
--end
--
--local flpos,flang = Vector(4,-1,0),Angle(0,0,0)
--
--local offsetVec,offsetAng = Vector(1,0,0),Angle(100,90,0)
--local vecZero, angZero = Vector(0, 0, 0), Angle(0, 0, 0)
--local mat = Material("sprites/rollermine_shock")
--local mat2 = Material("sprites/light_glow02_add_noz")
--local mat3 = Material("effects/flashlight/soft")
--local mat4 = Material("sprites/light_ignorez", "alphatest")
--
--function DrawAppearance(ent, ply)
--	if IsValid(ent) and ent:GetNetVar("Accessories") then
--		RenderAccessories(ent, ent:GetNetVar("Accessories", "none"))
--	end
--
--	if not ply:IsPlayer() then return end
--
--	local inv = ply:GetNetVar("Inventory",{})
--	if not inv["Weapons"] or not inv["Weapons"]["hg_flashlight"] then
--		if ply.flashlight then
--			ply.flashlight:Remove()
--			ply.flashlight = nil
--		end
--		if ply.flmodel then
--			ply.flmodel:Remove()
--			ply.flmodel = nil
--		end
--		return
--	end
--
--	local wep = ply:GetActiveWeapon()
--	local flashlightwep
--
--	if IsValid(wep) then
--		local laser = wep.attachments and wep.attachments.underbarrel
--		local attachmentData
--		if (laser and not table.IsEmpty(laser)) or wep.laser then
--			if laser and not table.IsEmpty(laser) then
--				attachmentData = hg.attachments.underbarrel[laser[1]]
--			else
--				attachmentData = wep.laserData
--			end
--		end
--
--		if attachmentData then flashlightwep = attachmentData.supportFlashlight end
--	end
--
--	if IsValid(ply.flmodel) then
--		ply.flmodel:SetNoDraw(!(ply:GetNetVar("flashlight") and (!wep.IsPistolHoldType or wep:IsPistolHoldType())) or wep.reload or flashlightwep)
--	end
--
--	if ply:GetNetVar("flashlight") and not flashlightwep and (!wep.IsPistolHoldType or wep:IsPistolHoldType()) and not wep.reload then
--		local hand = ent:LookupBone("ValveBiped.Bip01_L_Hand")
--		if not hand then return end
--		
--		local handmat = ent:GetBoneMatrix(hand)
--		if not handmat then return end
--
--		local pos,ang = handmat:GetTranslation(),handmat:GetAngles()--ply:EyeAngles()--(ply:GetEyeTrace().HitPos - ply:EyePos()):Angle()
--		local pos,ang = LocalToWorld(offsetVec,offsetAng,pos,ang)
--
--		ply.flmodel = IsValid(ply.flmodel) and ply.flmodel or ClientsideModel("models/runaway911/props/item/flashlight.mdl")
--		ply.flmodel:SetModelScale(0.75)
--
--		if ent ~= ply then pos = handmat:GetTranslation() end
--
--		local pos,_ = LocalToWorld(flpos,flang,pos,handmat:GetAngles())
--
--		if IsValid(ply.flmodel) and (ply ~= LocalPlayer() or ply ~= GetViewEntity()) then
--			local veclh,lang = hg.FlashlightTransform(ply)
--		end
--
--		ply.flmodel:DrawModel()
--
--		ply.flashlight = IsValid(ply.flashlight) and ply.flashlight or ProjectedTexture()
--		if ply.flashlight and ply.flashlight:IsValid() and (ply.FlashlightUpdateTime or 0) < CurTime() then
--			local flash = ply.flashlight
--			ply.FlashlightUpdateTime = CurTime() + 0.01
--			flash:SetTexture(mat3:GetTexture("$basetexture"))
--			flash:SetFarZ(1500)
--			flash:SetHorizontalFOV(60)
--			flash:SetVerticalFOV(60)
--			flash:SetConstantAttenuation(0.1)
--			flash:SetLinearAttenuation(50)
--			flash:SetPos(ply.flmodel:GetPos() + ply.flmodel:GetAngles():Forward() * (ply:GetVelocity():Length() / 10+15))
--			flash:SetAngles(ply.flmodel:GetAngles())
--			flash:Update()
--		end
--
--		--[[ply.dlight = DynamicLight( ply:EntIndex() )
--		if ( ply.dlight ) then
--			ply.dlight.pos = ply.flmodel:GetPos()
--			ply.dlight.r = 255
--			ply.dlight.g = 255
--			ply.dlight.b = 255
--			ply.dlight.brightness = -3
--			ply.dlight.decay = 400
--			ply.dlight.size = 100
--			ply.dlight.dietime = CurTime() + 0.1
--		else
--			ply.dlight = DynamicLight( ply:EntIndex() )
--		end--]]
--
--		local view = render.GetViewSetup(true)
--		local deg = ply.flmodel:GetAngles():Forward():Dot(view.angles:Forward())
--		deg = math.ease.InBack(-deg+0.05)*2
--		deg = -deg
--		local chekvisible = util.TraceLine({
--			start = ply.flmodel:GetPos() + ply.flmodel:GetAngles():Forward() * 6,
--			endpos = view.origin,
--			filter = {ply, ent, ply.flmodel, LocalPlayer()},
--			mask = MASK_VISIBLE
--		})
---- DUMPED WITH GMODLUAINJECTOR MADE BY GAZTOOF FOR UNKNOWNCHEATS :)
--		if deg < 0 and not chekvisible.Hit then
--			render.SetMaterial(mat2)
--			render.DrawSprite(ply.flmodel:GetPos() + ply.flmodel:GetAngles():Forward() * 5 + ply.flmodel:GetAngles():Right() * -0.5, 50 * math.min(deg, 0), 50 * math.min(deg, 0), color_white)
--		end
--	else
--		if ply.flashlight and ply.flashlight:IsValid() then
--			ply.flashlight:Remove()
--			ply.flashlight = nil
--		end
--	end
--end
--
--hook.Add("OnNetVarSet","AccessoriesVarSet",function(index, key, var)
--    if key == "Accessories" then
--        timer.Simple(.1,function()
--            local ent = Entity(index)
--			if ent.modelAccess then
--				for i,model in pairs(ent.modelAccess) do
--					if IsValid(model) then
--						model:Remove()
--						ent.modelAccess[i] = nil
--					end
--				end
--			end
--            ent.accessories = var
--        end)
--    end
--end)
--
--hook.Add("RenderScreenspaceEffects","AppearanceShitty",function()
--	if (not LocalPlayer():Alive()) or LocalPlayer():GetViewEntity() ~= LocalPlayer() then return end
--	local ply = LocalPlayer()
--	local acsses = ply:GetNetVar("Accessories", "none")
--
--	if istable(acsses) then
--		for k,accessoriess in ipairs(acsses) do
--			local accessData = hg.Accessories[accessoriess]
--			if not accessData then continue end
--			if ply.armors and accessData["placement"] and ply.armors[accessData["placement"]] then continue end
--			if accessData.ScreenSpaceEffects then
--				accessData.ScreenSpaceEffects()
--			end
--		end
--	elseif acsses then
--		local accessData = hg.Accessories[acsses]
--		if not accessData then return end
--		if ply.armors and accessData["placement"] and ply.armors[accessData["placement"]] then return end
--		if accessData.ScreenSpaceEffects then
--			accessData.ScreenSpaceEffects()
--		end
--	end
--end)
