﻿att.PrintName = "EZ Tactical Laser"
att.Icon = Material("entities/acwatt_tac_pointer.png")
att.Description = "y r u gae"
att.Desc_Pros = {}

att.Desc_Cons = {"- Visible beam"}

att.AutoStats = true
att.Slot = "ez_tac_rail"
att.Model = "models/weapons/arccw/atts/laser_pointer.mdl"
att.Laser = true
att.LaserStrength = .75
att.LaserBone = "laser"

att.ColorOptionsTable = {Color(255, 50, 50)}

att.Mult_HipDispersion = 0.5
att.Mult_MoveDispersion = 0.5
att.Mult_SightTime = 1
