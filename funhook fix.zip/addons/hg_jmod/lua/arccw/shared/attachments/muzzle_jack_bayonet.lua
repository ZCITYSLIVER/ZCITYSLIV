﻿att.PrintName = "Bayonet"
att.Icon = Material("entities/acwatt_muzz_breacher.png")
att.Description = "doesnt really do anything useful until arctic gets his shit together"
att.Desc_Pros = {} --
att.Desc_Cons = {} --
att.AutoStats = true
att.Slot = "ez_muzzle"
att.Model = "models/jmod_oldbayonet.mdl"
--[[ -- nah
att.Mult_MeleeDamage=1.5

att.Mult_SpeedMult=0.97

att.Add_BarrelLength=3

att.Mult_MeleeTime=0.9

att.Add_MeleeRange=4
--]]
